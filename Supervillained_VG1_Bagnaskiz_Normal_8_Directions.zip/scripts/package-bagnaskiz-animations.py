#!/usr/bin/env python3
"""Render Bagnaskiz previews and make complete delivery ZIPs under the requested cap.

Requires Pillow. Runtime images and native 40px action sheets remain unchanged.
If a combined ZIP is too large, normal and armoured costumes are split. Only if a
split ZIP still exceeds the cap are optional preview GIFs omitted and, as a final
size reduction, the editable 128px sheets converted to a documented 256-colour
palette inside the archive. Raw generated sheets are never included.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
BASE_COMMIT = '8a53d02bcdb8da3c1bb79ecbc8812018db64bd61'
VARIANTS = ('normal', 'armoured')
STEMS = {'normal': 'bagnaskiz', 'armoured': 'bagnaskizArmoured'}
KEYS = {'normal': 'bagnaskiz', 'armoured': 'bagnaskizEmperor'}
DIRECTIONS = ('N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW')
ACTIONS = ('idle', 'walk', 'run', 'sniff', 'pee', 'poop', 'eat', 'bark', 'fetch', 'hurt', 'sit', 'tired')
COUNTS = dict(zip(ACTIONS, (8, 8, 8, 2, 8, 8, 8, 2, 4, 2, 8, 2)))
HOLDS = {
    'idle': [100, 110, 120, 110, 100, 110, 120, 110],
    'walk': [90, 80, 90, 110, 90, 80, 90, 110],
    'run': [50, 60, 60, 50, 60, 50, 50, 50],
    'sniff': [200, 200],
    'pee': [120, 100, 130, 250, 360, 280, 140, 180],
    'poop': [120, 130, 150, 220, 360, 220, 140, 180],
    'eat': [110, 100, 100, 90, 180, 90, 90, 120],
    'bark': [100, 100],
    'fetch': [1000 / 13] * 4,
    'hurt': [100, 100],
    'sit': [120, 120, 150, 120, 120, 120, 150, 120],
    'tired': [250, 250],
}
ONE_SHOTS = {'pee', 'poop', 'bark'}
SHARED_FILES = (
    'INSTALL_BAGNASKIZ_8_DIRECTIONS.md',
    'src/assets/manifest.ts',
    'tests/sprites.test.ts',
    'tests/bagnaskizAnimations.test.ts',
    'scripts/build-bagnaskiz-animations.py',
    'scripts/reassemble-bagnaskiz-atlases.py',
    'scripts/package-bagnaskiz-animations.py',
)
PATCH_FILES = ('src/assets/manifest.ts', 'tests/sprites.test.ts', 'tests/bagnaskizAnimations.test.ts')
PREFIX = 'Supervillained_VG1_Bagnaskiz'


def font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    try:
        return ImageFont.truetype('DejaVuSans.ttf', size)
    except OSError:
        return ImageFont.load_default()


def png_bytes(image: Image.Image) -> bytes:
    output = io.BytesIO()
    image.save(output, format='PNG', optimize=True, compress_level=9)
    return output.getvalue()


def frame_at(action: str, milliseconds: int) -> int:
    holds = HOLDS[action]
    duration = sum(holds)
    time = min(milliseconds, duration - 0.001) if action in ONE_SHOTS else milliseconds % duration
    for frame, hold in enumerate(holds):
        if time < hold:
            return frame
        time -= hold
    return len(holds) - 1


class Costume:
    def __init__(self, variant: str, source_root: Path):
        self.variant = variant
        self.source_root = source_root
        self.main_path = ROOT / 'public/sprites' / f'{STEMS[variant]}.png'
        self.tired_path = ROOT / 'public/sprites' / f'{STEMS[variant]}-tired.png'
        self.main = Image.open(self.main_path).convert('RGBA')
        self.tired = Image.open(self.tired_path).convert('RGBA')
        if self.main.size != (320, 3520) or self.tired.size != (80, 320):
            raise ValueError(f'{variant}: runtime atlas sizes do not match the twelve-action layout')
        self.packing = json.loads((source_root / variant / 'packing.json').read_text())
        self.clean: dict[str, Path] = {}
        self.native: dict[str, Path] = {}
        self.prompts: dict[str, Path] = {}
        for action in ACTIONS:
            self.clean[action] = source_root / 'packed' / variant / f'{action}.png'
            self.native[action] = source_root / 'packed/native' / variant / f'{action}.png'
            self.prompts[action] = source_root / variant / f'{action}.prompt.txt'
            for path in (self.clean[action], self.native[action], self.prompts[action]):
                if not path.is_file():
                    raise FileNotFoundError(path)
            if Image.open(self.clean[action]).size != (1024, 1024):
                raise ValueError(f'{action}: clean editable sheet must be 1024×1024')
            if Image.open(self.native[action]).size != (320, 320):
                raise ValueError(f'{action}: native sheet must be 320×320')

    def cell(self, action: str, direction_index: int, frame: int) -> Image.Image:
        image = self.tired if action == 'tired' else self.main
        row = direction_index if action == 'tired' else ACTIONS.index(action) * 8 + direction_index
        return image.crop((frame * 40, row * 40, (frame + 1) * 40, (row + 1) * 40))

    def verify_native_roundtrip(self) -> None:
        for action in ACTIONS:
            source = Image.open(self.native[action]).convert('RGBA')
            chosen = self.packing['actions'][action]['source_frames']
            if len(chosen) != COUNTS[action]:
                raise ValueError(f'{action}: wrong number of selected runtime frames')
            for direction_index, direction in enumerate(DIRECTIONS):
                for runtime_frame, authored_frame in enumerate(chosen):
                    native = source.crop((authored_frame * 40, direction_index * 40,
                                          (authored_frame + 1) * 40, (direction_index + 1) * 40))
                    if native.tobytes() != self.cell(action, direction_index, runtime_frame).tobytes():
                        raise ValueError(f'{self.variant} {action} {direction}: native sheet differs from runtime')

    def animations(self) -> dict:
        return {
            'character': 'Bagnaskiz', 'costume': self.variant, 'game_key': KEYS[self.variant],
            'runtime': {'main': f'public/sprites/{STEMS[self.variant]}.png',
                        'tired': f'public/sprites/{STEMS[self.variant]}-tired.png',
                        'cell_size': [40, 40], 'anchor': [20, 36], 'directions': list(DIRECTIONS),
                        'main_action_order': list(ACTIONS[:-1])},
            'editable': {'native_cell_size': [40, 40], 'native_anchor': [20, 36],
                         'clean_cell_size': [128, 128], 'clean_anchor': [64, 116],
                         'frames_per_direction': 8, 'directions': list(DIRECTIONS)},
            'actions': {action: {
                'runtime_frames': COUNTS[action], 'runtime_holds_ms': HOLDS[action],
                'loop': action not in ONE_SHOTS,
                'runtime_source_frames': self.packing['actions'][action]['source_frames'],
                'native_sheet': f'assets/8-directions/bagnaskiz/packed/native/{self.variant}/{action}.png',
                'editable_128_sheet': f'assets/8-directions/bagnaskiz/packed/{self.variant}/{action}.png',
            } for action in ACTIONS},
        }


def render_contact(costume: Costume, output: Path) -> Path:
    image = Image.new('RGB', (812, 1040), '#343d4d')
    draw = ImageDraw.Draw(image)
    draw.text((8, 6), f'BAGNASKIZ - {costume.variant.upper()} - ALL 12 ACTIONS', font=font(15), fill='white')
    for col, direction in enumerate(DIRECTIONS):
        draw.text((104 + col * 87, 29), direction, font=font(12), fill='#ffe15a')
    for row, action in enumerate(ACTIONS):
        y = 50 + row * 81
        draw.text((7, y + 34), action.upper(), font=font(11), fill='white')
        for col in range(8):
            cell = costume.cell(action, col, 0).resize((80, 80), Image.Resampling.NEAREST)
            image.paste(cell, (94 + col * 87, y), cell)
    path = output / f'bagnaskiz-{costume.variant}-contact.png'
    image.save(path, optimize=True)
    return path


def render_motion(costumes: dict[str, Costume], output: Path) -> Path:
    frames = []
    for tick in range(40):
        image = Image.new('RGB', (904, 650), '#303744')
        draw = ImageDraw.Draw(image)
        draw.text((8, 7), 'BAGNASKIZ - NORMAL AND BYZANTINE ARMOUR - EIGHT DIRECTIONS', font=font(14), fill='white')
        for col, direction in enumerate(DIRECTIONS):
            draw.text((116 + col * 98, 34), direction, font=font(13), fill='#ffe15a')
        for variant_index, variant in enumerate(VARIANTS):
            for row, action in enumerate(('idle', 'walk', 'run')):
                y = 58 + (variant_index * 3 + row) * 96
                if row == 0:
                    draw.text((7, y + 24), variant.upper(), font=font(12), fill='white')
                draw.text((7, y + 47), action.upper(), font=font(12), fill='#c5d9df')
                selected = frame_at(action, tick * 50)
                for col in range(8):
                    cell = costumes[variant].cell(action, col, selected).resize((80, 80), Image.Resampling.NEAREST)
                    image.paste(cell, (116 + col * 98, y), cell)
        frames.append(image)
    path = output / 'bagnaskiz-normal-armoured-eight-directions.gif'
    save_gif(frames, path)
    return path


def render_full_motion(costume: Costume, output: Path) -> Path:
    frames = []
    for tick in range(40):
        image = Image.new('RGB', (480, 642), '#303744')
        draw = ImageDraw.Draw(image)
        draw.text((7, 6), f'BAGNASKIZ - {costume.variant.upper()} - ALL ACTIONS', font=font(11), fill='white')
        for col, direction in enumerate(DIRECTIONS):
            draw.text((102 + col * 46, 26), direction, font=font(10), fill='#ffe15a')
        for row, action in enumerate(ACTIONS):
            y = 46 + row * 49
            draw.text((7, y + 17), action.upper(), font=font(10), fill='white')
            selected = frame_at(action, tick * 50)
            for col in range(8):
                cell = costume.cell(action, col, selected)
                image.paste(cell, (96 + col * 46, y), cell)
        frames.append(image)
    path = output / f'bagnaskiz-{costume.variant}-all-actions.gif'
    save_gif(frames, path)
    return path


def render_gait(costume: Costume, output: Path) -> Path:
    """Keep a compact animated preview in every archive, including size-limited splits."""
    frames = []
    for tick in range(40):
        image = Image.new('RGB', (480, 215), '#303744')
        draw = ImageDraw.Draw(image)
        draw.text((7, 6), f'BAGNASKIZ - {costume.variant.upper()} - IDLE / WALK / RUN',
                  font=font(11), fill='white')
        for col, direction in enumerate(DIRECTIONS):
            draw.text((102 + col * 46, 26), direction, font=font(10), fill='#ffe15a')
        for row, action in enumerate(('idle', 'walk', 'run')):
            y = 46 + row * 49
            draw.text((7, y + 17), action.upper(), font=font(10), fill='white')
            selected = frame_at(action, tick * 50)
            for col in range(8):
                cell = costume.cell(action, col, selected)
                image.paste(cell, (96 + col * 46, y), cell)
        frames.append(image)
    path = output / f'bagnaskiz-{costume.variant}-gait.gif'
    save_gif(frames, path)
    return path


def save_gif(frames: list[Image.Image], path: Path) -> None:
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=50, loop=0,
                   disposal=2, optimize=False)
    with Image.open(path) as image:
        if image.n_frames < 2 or image.info.get('loop') != 0:
            raise ValueError(f'{path}: invalid animated preview')


def portraits(costume: Costume, output: Path) -> list[Path]:
    image = Image.open(costume.clean['sit']).convert('RGBA')
    paths = []
    for name, row in (('front', 4), ('rear', 0)):
        portrait = image.crop((0, row * 128, 128, (row + 1) * 128))
        path = output / f'bagnaskiz-{costume.variant}-{name}-pixel.png'
        portrait.save(path, optimize=True)
        paths.append(path)
    return paths


def integration_patch() -> bytes:
    result = []
    for path in PATCH_FILES:
        command = subprocess.run(['git', 'show', f'{BASE_COMMIT}:{path}'], cwd=ROOT,
                                 capture_output=True, text=True, check=False)
        before = command.stdout if command.returncode == 0 else ''
        after = (ROOT / path).read_text()
        if before == after:
            continue
        result.append(f'diff --git a/{path} b/{path}\n')
        if command.returncode != 0:
            result.append('new file mode 100644\n')
        result.extend(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                         fromfile=f'a/{path}' if command.returncode == 0 else '/dev/null',
                                         tofile=f'b/{path}'))
    return ''.join(result).encode()


EDITING = '''# Editing the Bagnaskiz delivery

The compact game atlases in public/sprites are the authoritative installed images.
The native action sheets under assets/8-directions/bagnaskiz/packed/native contain
all eight authored frames at the original forty-pixel game size. Each sheet is an
8-column × 8-row grid: columns are frames, rows are N NE E SE S SW W NW.

Edit native cells in a pixel editor, keeping the transparent border and anchor
(20, 36). Reassemble them without resampling:

    python3 scripts/reassemble-bagnaskiz-atlases.py

The cleaned 128-pixel sheets under packed/normal and packed/armoured are larger
editable references with anchor (64, 116). They retain all eight authored frames
per direction. Runtime sniff/bark/hurt/tired use two selected frames; fetch uses
four. The selections and timing are recorded in animations.json and packing.json.

The original generated images have drifting cell positions and alpha processing
residue, so they are not shipped in these compact archives. The build script is
kept for workflows that retain those original generated sources. Use the native
reassembler above for an exact pixel-preserving rebuild from this delivery.

If two archives were delivered, extract both before running integration tests.
Shared code files are identical in both archives. The supplied integration patch
is based on commit 8a53d02bcdb8da3c1bb79ecbc8812018db64bd61; review it before
overwriting a manifest that has newer changes.
'''


def archive_entries(variants: tuple[str, ...], costumes: dict[str, Costume], args: argparse.Namespace,
                    previews: dict, *, include_main: bool, include_full: bool,
                    quantize_clean: bool) -> dict[str, bytes]:
    entries = {path: (ROOT / path).read_bytes() for path in SHARED_FILES}
    entries['BAGNASKIZ_INTEGRATION.patch'] = integration_patch()
    entries['EDITING_BAGNASKIZ.md'] = EDITING.encode()
    if quantize_clean:
        entries['EDITING_BAGNASKIZ.md'] += (
            '\nFor this archive only, the larger 128-pixel editable sheets were reduced to a '
            '256-colour palette to satisfy the 22 MB cap. Runtime and native40 PNG pixels '
            'remain unchanged.\n').encode()
    if include_main:
        path = previews['main']
        entries[f'previews/{path.name}'] = path.read_bytes()
    for variant in variants:
        costume = costumes[variant]
        for path in (costume.main_path, costume.tired_path):
            entries[path.relative_to(ROOT).as_posix()] = path.read_bytes()
        prefix = f'assets/8-directions/bagnaskiz/{variant}'
        entries[f'{prefix}/packing.json'] = json.dumps(costume.packing, indent=2).encode() + b'\n'
        entries[f'{prefix}/animations.json'] = json.dumps(costume.animations(), indent=2).encode() + b'\n'
        for action in ACTIONS:
            clean_path = f'assets/8-directions/bagnaskiz/packed/{variant}/{action}.png'
            if quantize_clean:
                clean = Image.open(costume.clean[action]).convert('RGBA')
                clean = clean.quantize(colors=256, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.NONE)
                entries[clean_path] = png_bytes(clean)
            else:
                entries[clean_path] = costume.clean[action].read_bytes()
            native_path = f'assets/8-directions/bagnaskiz/packed/native/{variant}/{action}.png'
            entries[native_path] = costume.native[action].read_bytes()
            entries[f'{prefix}/{action}.prompt.txt'] = costume.prompts[action].read_bytes()
        for name in (f'Bagnaskiz-{variant}-front.png', f'Bagnaskiz-{variant}-rear.png'):
            path = args.references_root / name
            entries[f'references/{name}'] = path.read_bytes()
        rear_prompt = args.references_root / 'normal-rear.prompt.txt'
        if variant == 'normal' and rear_prompt.is_file():
            entries['references/normal-rear.prompt.txt'] = rear_prompt.read_bytes()
        for key in ('contact', 'portraits', 'gait'):
            paths = previews[variant][key]
            if isinstance(paths, Path):
                paths = [paths]
            for path in paths:
                entries[f'previews/{path.name}'] = path.read_bytes()
        if include_full:
            path = previews[variant]['full']
            entries[f'previews/{path.name}'] = path.read_bytes()
    checksums = {name: {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
                 for name, content in entries.items()}
    manifest = {'character': 'Bagnaskiz', 'costumes': list(variants), 'base_commit': BASE_COMMIT,
                'max_archive_bytes': args.limit_bytes, 'clean128_palette_colors': 256 if quantize_clean else None,
                'runtime_and_native_pixels_preserved': True,
                'previews': {'combined_motion': include_main, 'all_actions_motion': include_full,
                             'compact_gait_motion': True},
                'files': checksums}
    entries['BAGNASKIZ_CONTENTS.json'] = json.dumps(manifest, indent=2).encode() + b'\n'
    return entries


def write_zip(path: Path, entries: dict[str, bytes]) -> dict:
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in entries.items():
            archive.writestr(name, content)
    with zipfile.ZipFile(path) as archive:
        error = archive.testzip()
        if error is not None:
            raise ValueError(f'{path}: CRC failure for {error}')
        if set(archive.namelist()) != set(entries):
            raise ValueError(f'{path}: archive entries do not match the delivery')
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'entries': len(entries), 'crc': 'OK'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=ROOT / 'assets/8-directions/bagnaskiz')
    reference_candidates = (ROOT / 'references', ROOT / 'assets/8-directions/bagnaskiz/references',
                            ROOT.parent / 'bagnaskiz-work/references')
    default_references = next((path for path in reference_candidates if path.is_dir()), reference_candidates[-1])
    parser.add_argument('--references-root', type=Path, default=default_references)
    parser.add_argument('--output-dir', type=Path, default=ROOT)
    parser.add_argument('--preview-dir', type=Path, default=ROOT / 'docs/screens/bagnaskiz')
    parser.add_argument('--limit-bytes', type=int, default=22_000_000)
    parser.add_argument('--previews-only', action='store_true')
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.preview_dir.mkdir(parents=True, exist_ok=True)
    costumes = {variant: Costume(variant, args.source_root) for variant in VARIANTS}
    for costume in costumes.values():
        costume.verify_native_roundtrip()
    previews = {'main': render_motion(costumes, args.preview_dir)}
    for variant, costume in costumes.items():
        previews[variant] = {'contact': render_contact(costume, args.preview_dir),
                             'full': render_full_motion(costume, args.preview_dir),
                             'gait': render_gait(costume, args.preview_dir),
                             'portraits': portraits(costume, args.preview_dir)}
        (args.source_root / variant / 'animations.json').write_text(json.dumps(costume.animations(), indent=2) + '\n')
    if args.previews_only:
        print(json.dumps({'preview_directory': str(args.preview_dir.resolve()), 'native_roundtrip': 'OK'}))
        return 0
    combined = args.output_dir / f'{PREFIX}_Normal_Armoured_8_Directions.zip'
    options = {'include_main': True, 'include_full': True, 'quantize_clean': False}
    report = write_zip(combined, archive_entries(VARIANTS, costumes, args, previews, **options))
    report.update({'costumes': list(VARIANTS), **options})
    deliveries = [report]
    if report['bytes'] > args.limit_bytes:
        combined.unlink()
        deliveries = []
        for variant in VARIANTS:
            name = 'Normal' if variant == 'normal' else 'Armoured'
            path = args.output_dir / f'{PREFIX}_{name}_8_Directions.zip'
            alternatives = (
                {'include_main': True, 'include_full': True, 'quantize_clean': False},
                {'include_main': True, 'include_full': False, 'quantize_clean': False},
                {'include_main': False, 'include_full': True, 'quantize_clean': False},
                {'include_main': False, 'include_full': False, 'quantize_clean': False},
                {'include_main': True, 'include_full': True, 'quantize_clean': True},
                {'include_main': False, 'include_full': True, 'quantize_clean': True},
                {'include_main': False, 'include_full': False, 'quantize_clean': True},
            )
            for settings in alternatives:
                report = write_zip(path, archive_entries((variant,), costumes, args, previews, **settings))
                if report['bytes'] <= args.limit_bytes:
                    report.update({'costumes': [variant], **settings})
                    deliveries.append(report)
                    break
            else:
                path.unlink()
                raise ValueError(f'{variant}: complete delivery cannot fit {args.limit_bytes} bytes')
    summary = {'character': 'Bagnaskiz', 'base_commit': BASE_COMMIT, 'max_archive_bytes': args.limit_bytes,
               'native_roundtrip': 'OK', 'preview_directory': str(args.preview_dir.resolve()),
               'deliveries': deliveries}
    (args.output_dir / 'Bagnaskiz_delivery-manifest.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
