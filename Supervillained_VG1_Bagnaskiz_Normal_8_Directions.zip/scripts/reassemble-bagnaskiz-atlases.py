#!/usr/bin/env python3
"""Reassemble Bagnaskiz runtime atlases from the lossless native 40px action sheets.

Requires Pillow. This copies cells without rescaling, redrawing or changing pixels.
The native sheets retain all eight authored frames; packing.json selects the runtime
frames (including the low-head sniff pair) used by the game's manifest.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ACTIONS = ('idle', 'walk', 'run', 'sniff', 'pee', 'poop', 'eat', 'bark', 'fetch', 'hurt', 'sit', 'tired')
DIRECTIONS = ('N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW')
COUNTS = dict(zip(ACTIONS, (8, 8, 8, 2, 8, 8, 8, 2, 4, 2, 8, 2)))
STEMS = {'normal': 'bagnaskiz', 'armoured': 'bagnaskizArmoured'}


def picks(action: str) -> list[int]:
    if action == 'sniff':
        return [3, 4]
    return list(range(8)) if COUNTS[action] == 8 else ([0, 2, 4, 6] if COUNTS[action] == 4 else [0, 4])


def reassemble(source_root: Path, variant: str, output: Path) -> None:
    metadata_path = source_root / variant / 'packing.json'
    metadata = json.loads(metadata_path.read_text()) if metadata_path.exists() else {}
    native_root = source_root / 'packed/native' / variant
    main = Image.new('RGBA', (320, 3520))
    tired = Image.new('RGBA', (80, 320))
    for action_index, action in enumerate(ACTIONS):
        image = Image.open(native_root / f'{action}.png').convert('RGBA')
        if image.size != (320, 320):
            raise ValueError(f'{action}: native action sheet must be 320×320')
        chosen = metadata.get('actions', {}).get(action, {}).get('source_frames', picks(action))
        if len(chosen) != COUNTS[action] or any(type(frame) is not int or not 0 <= frame < 8 for frame in chosen):
            raise ValueError(f'{action}: invalid runtime frame selection')
        for direction_index, direction in enumerate(DIRECTIONS):
            for destination_frame, authored_frame in enumerate(chosen):
                cell = image.crop((authored_frame * 40, direction_index * 40,
                                   (authored_frame + 1) * 40, (direction_index + 1) * 40))
                bounds = cell.getchannel('A').getbbox()
                if bounds is None or bounds[0] <= 0 or bounds[1] <= 0 or bounds[2] >= 40 or bounds[3] >= 40:
                    raise ValueError(f'{action} {direction} frame {authored_frame}: empty or clipped cell')
                target = tired if action == 'tired' else main
                row = direction_index if action == 'tired' else action_index * 8 + direction_index
                target.paste(cell, (destination_frame * 40, row * 40))
    output.mkdir(parents=True, exist_ok=True)
    for image, suffix in ((main, ''), (tired, '-tired')):
        path = output / f'{STEMS[variant]}{suffix}.png'
        image.save(path, optimize=True, compress_level=9)
        print(path)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=ROOT / 'assets/8-directions/bagnaskiz')
    parser.add_argument('--variant', choices=('normal', 'armoured', 'all'), default='all')
    parser.add_argument('--output', type=Path, default=ROOT / 'public/sprites')
    args = parser.parse_args()
    for variant in STEMS if args.variant == 'all' else (args.variant,):
        reassemble(args.source_root, variant, args.output)


if __name__ == '__main__':
    main()
