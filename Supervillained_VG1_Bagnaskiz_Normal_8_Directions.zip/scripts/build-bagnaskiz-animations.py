#!/usr/bin/env python3
"""Pack authored Bagnaskiz poses into the game's 40px eight-direction atlases.

Requires Pillow. Source artwork is one eight-column/eight-row PNG per action,
with eight authored frames across and N/NE/E/SE/S/SW/W/NW down. Whole-component
extraction accommodates small source-cell overruns without admitting fragments
from neighbouring sprites. One fixed transform per directional clip preserves
the artist's motion; this script does not draw, rotate or warp character poses.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import sys
from typing import Any

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
DIRECTIONS = ('N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW')
ACTIONS = ('idle', 'walk', 'run', 'sniff', 'pee', 'poop', 'eat', 'bark', 'fetch', 'hurt', 'sit', 'tired')
MAIN_ACTIONS = ACTIONS[:-1]
FRAME_COUNTS = dict(zip(ACTIONS, (8, 8, 8, 2, 8, 8, 8, 2, 4, 2, 8, 2)))
FRAME_SELECTIONS = {8: tuple(range(8)), 4: (0, 2, 4, 6), 2: (0, 4)}
ACTION_FRAME_SELECTIONS = {action: ((3, 4) if action == 'sniff' else FRAME_SELECTIONS[count])
                           for action, count in FRAME_COUNTS.items()}
FILE_STEMS = {'normal': 'bagnaskiz', 'armoured': 'bagnaskizArmoured'}
FRAME_SIZE = 40
ANCHOR = (20, 36)
BODY_LIMIT = (32, 30)
CLEAN_FRAME_SIZE = 128
CLEAN_ANCHOR = (64, 116)
CLEAN_BODY_LIMIT = (112, 108)
ALPHA_THRESHOLD = 128


@dataclass(frozen=True)
class Body:
    box: tuple[int, int, int, int]
    image: Image.Image
    pixels: int

    @property
    def center(self) -> tuple[float, float]:
        left, top, right, bottom = self.box
        return ((left + right) / 2, (top + bottom) / 2)


def extract_bodies(source: Image.Image, *, rows: int = 8, columns: int = 8) -> tuple[dict[tuple[int, int], Body], dict[str, Any]]:
    """Extract complete opaque bodies and retain an isolated alpha mask for each."""
    source = source.convert('RGBA')
    width, height = source.size
    pitch_x, pitch_y = width / columns, height / rows
    minimum_area = max(24, round(pitch_x * pitch_y * 0.022))
    remaining = bytearray(1 if alpha >= ALPHA_THRESHOLD else 0
                          for alpha in source.getchannel('A').tobytes())
    components: list[Body] = []
    ignored_count = 0
    ignored_pixels = 0
    for seed in range(len(remaining)):
        if not remaining[seed]:
            continue
        remaining[seed] = 0
        queue = [seed]
        cursor = 0
        left, top, right, bottom = width, height, 0, 0
        while cursor < len(queue):
            index = queue[cursor]
            cursor += 1
            y, x = divmod(index, width)
            left, top = min(left, x), min(top, y)
            right, bottom = max(right, x + 1), max(bottom, y + 1)
            if x and remaining[index - 1]:
                remaining[index - 1] = 0
                queue.append(index - 1)
            if x + 1 < width and remaining[index + 1]:
                remaining[index + 1] = 0
                queue.append(index + 1)
            if y and remaining[index - width]:
                remaining[index - width] = 0
                queue.append(index - width)
            if y + 1 < height and remaining[index + width]:
                remaining[index + width] = 0
                queue.append(index + width)
        body_width, body_height = right - left, bottom - top
        # A long gutter stripe is not a character, even if its total area is large.
        if len(queue) < minimum_area or body_width > pitch_x * 1.55 or body_height > pitch_y * 1.55:
            ignored_count += 1
            ignored_pixels += len(queue)
            continue
        isolated_alpha = bytearray(body_width * body_height)
        for index in queue:
            y, x = divmod(index, width)
            isolated_alpha[(y - top) * body_width + x - left] = 255
        sprite = source.crop((left, top, right, bottom))
        sprite.putalpha(Image.frombytes('L', sprite.size, bytes(isolated_alpha)))
        components.append(Body((left, top, right, bottom), sprite, len(queue)))
    expected = rows * columns
    if len(components) != expected:
        raise ValueError(f'Expected {expected} complete sprites in a {columns}×{rows} source, '
                         f'found {len(components)}; repair the source artwork rather than inventing frames')
    components.sort(key=lambda body: body.center[1])
    result: dict[tuple[int, int], Body] = {}
    row_centers = []
    for row in range(rows):
        group = sorted(components[row * columns:(row + 1) * columns], key=lambda body: body.center[0])
        centers_y = [body.center[1] for body in group]
        if max(centers_y) - min(centers_y) > pitch_y * 0.68:
            raise ValueError(f'Source row {row} is not a coherent row of {columns} sprites')
        row_centers.append(statistics.median(centers_y))
        for column, body in enumerate(group):
            expected_x = (column + 0.5) * pitch_x
            if abs(body.center[0] - expected_x) > pitch_x * 0.55:
                raise ValueError(f'Source row {row}, column {column} is outside its expected column')
            result[row, column] = body
    if any(b - a < pitch_y * 0.40 for a, b in zip(row_centers, row_centers[1:])):
        raise ValueError('Source row centers overlap; check the authored sheet layout')
    return result, {
        'source_size': [width, height], 'body_count': len(components),
        'alpha_threshold': ALPHA_THRESHOLD, 'minimum_component_pixels': minimum_area,
        'ignored_components': ignored_count, 'ignored_pixels': ignored_pixels,
        'row_centers': row_centers,
    }


def read_row_mapping(directory: Path) -> dict[str, tuple[str, ...]]:
    """An optional row-directions.json maps action names to top-to-bottom view names."""
    path = directory / 'row-directions.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError(f'{path}: expected an object mapping action names to direction arrays')
    result = {}
    for action, order in data.items():
        if action not in ACTIONS and action != 'default':
            raise ValueError(f'{path}: unknown action {action!r}')
        if not isinstance(order, list) or len(order) != 8 or set(order) != set(DIRECTIONS):
            raise ValueError(f'{path}: {action} must list all eight directions exactly once')
        result[action] = tuple(order)
    return result


def read_frame_selections(directory: Path) -> dict[str, tuple[int, ...]]:
    """Allow a costume's QA-selected authored phases without changing other clips."""
    path = directory / 'frame-selections.json'
    if not path.exists():
        return {}
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError(f'{path}: expected an object mapping action names to frame-index arrays')
    result = {}
    for action, frames in data.items():
        if action not in ACTIONS:
            raise ValueError(f'{path}: unknown action {action!r}')
        expected = FRAME_COUNTS[action]
        if (not isinstance(frames, list) or len(frames) != expected
                or any(type(frame) is not int or not 0 <= frame < 8 for frame in frames)
                or len(set(frames)) != len(frames)):
            raise ValueError(f'{path}: {action} must list {expected} unique integer authored indices from 0 through 7')
        result[action] = tuple(frames)
    return result


def pack_variant(directory: Path, variant: str) -> tuple[Image.Image, Image.Image, dict[str, Any],
                                                        dict[str, Image.Image], dict[str, Image.Image]]:
    main = Image.new('RGBA', (8 * FRAME_SIZE, len(MAIN_ACTIONS) * 8 * FRAME_SIZE))
    tired = Image.new('RGBA', (2 * FRAME_SIZE, 8 * FRAME_SIZE))
    clean_actions: dict[str, Image.Image] = {}
    native_actions: dict[str, Image.Image] = {}
    mapping = read_row_mapping(directory)
    frame_overrides = read_frame_selections(directory)
    selections = {action: frame_overrides.get(action, ACTION_FRAME_SELECTIONS[action]) for action in ACTIONS}
    metadata: dict[str, Any] = {
        'version': 1, 'variant': variant, 'runtime_stem': FILE_STEMS[variant],
        'directions': list(DIRECTIONS), 'main_actions': list(MAIN_ACTIONS),
        'frame_size': [FRAME_SIZE, FRAME_SIZE], 'anchor': list(ANCHOR),
        'body_limit': list(BODY_LIMIT), 'actions': {},
        'frame_selection_overrides': {action: list(frames) for action, frames in frame_overrides.items()},
        'clean_export': {'frame_size': [CLEAN_FRAME_SIZE, CLEAN_FRAME_SIZE],
                         'anchor': list(CLEAN_ANCHOR), 'body_limit': list(CLEAN_BODY_LIMIT),
                         'columns': 8, 'rows': 8, 'frames_per_direction': 8,
                         'directions': list(DIRECTIONS),
                         'paths': {action: f'{variant}/{action}.png' for action in ACTIONS}},
        'native_export': {'frame_size': [FRAME_SIZE, FRAME_SIZE],
                          'anchor': list(ANCHOR), 'body_limit': list(BODY_LIMIT),
                          'columns': 8, 'rows': 8, 'frames_per_direction': 8,
                          'directions': list(DIRECTIONS),
                          'paths': {action: f'native/{variant}/{action}.png' for action in ACTIONS}},
    }
    for action in ACTIONS:
        path = directory / f'{action}.png'
        if not path.is_file():
            raise FileNotFoundError(f'{path}: missing authored action sheet')
        source = Image.open(path).convert('RGBA')
        bodies, extraction = extract_bodies(source)
        pitch_x, pitch_y = source.width / 8, source.height / 8
        source_order = mapping.get(action, mapping.get('default', DIRECTIONS))
        selected_frames = selections[action]
        clean = Image.new('RGBA', (8 * CLEAN_FRAME_SIZE, 8 * CLEAN_FRAME_SIZE))
        native = Image.new('RGBA', (8 * FRAME_SIZE, 8 * FRAME_SIZE))
        action_info: dict[str, Any] = {
            'source_file': path.name, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'source_directions': list(source_order), 'source_frames': list(selected_frames),
            'frame_selection_origin': 'frame-selections.json' if action in frame_overrides else 'default',
            'runtime_frames': FRAME_COUNTS[action], 'extraction': extraction, 'directions': {},
        }
        for destination_row, direction in enumerate(DIRECTIONS):
            source_row = source_order.index(direction)
            row_bodies = [bodies[source_row, frame] for frame in range(8)]
            # Keep a common origin, crop, scale and ground alignment for all eight frames.
            left = min(body.box[0] - round(frame * pitch_x) for frame, body in enumerate(row_bodies)) - 1
            right = max(body.box[2] - round(frame * pitch_x) for frame, body in enumerate(row_bodies)) + 1
            top = min(body.box[1] - round(source_row * pitch_y) for body in row_bodies) - 1
            bottom = max(body.box[3] - round(source_row * pitch_y) for body in row_bodies) + 1
            union_width, union_height = right - left, bottom - top
            scale = min(BODY_LIMIT[0] / union_width, BODY_LIMIT[1] / union_height)
            target_width = max(1, round(union_width * scale))
            target_height = max(1, round(union_height * scale))
            offset_x, offset_y = ANCHOR[0] - target_width // 2, ANCHOR[1] - target_height
            clean_scale = min(CLEAN_BODY_LIMIT[0] / union_width, CLEAN_BODY_LIMIT[1] / union_height)
            clean_width = max(1, round(union_width * clean_scale))
            clean_height = max(1, round(union_height * clean_scale))
            clean_x, clean_y = CLEAN_ANCHOR[0] - clean_width // 2, CLEAN_ANCHOR[1] - clean_height
            for authored_frame in range(8):
                body = row_bodies[authored_frame]
                sequence_cell = Image.new('RGBA', (union_width, union_height))
                body_x = body.box[0] - round(authored_frame * pitch_x) - left
                body_y = body.box[1] - round(source_row * pitch_y) - top
                sequence_cell.alpha_composite(body.image, (body_x, body_y))
                clean_sprite = sequence_cell.resize((clean_width, clean_height), Image.Resampling.NEAREST)
                clean_cell = Image.new('RGBA', (CLEAN_FRAME_SIZE, CLEAN_FRAME_SIZE))
                clean_cell.alpha_composite(clean_sprite, (clean_x, clean_y))
                clean.paste(clean_cell, (authored_frame * CLEAN_FRAME_SIZE, destination_row * CLEAN_FRAME_SIZE))
                sprite = sequence_cell.resize((target_width, target_height), Image.Resampling.NEAREST)
                cell = Image.new('RGBA', (FRAME_SIZE, FRAME_SIZE))
                cell.alpha_composite(sprite, (offset_x, offset_y))
                native.paste(cell, (authored_frame * FRAME_SIZE, destination_row * FRAME_SIZE))
                if authored_frame in selected_frames:
                    frame = selected_frames.index(authored_frame)
                    output = tired if action == 'tired' else main
                    runtime_row = destination_row if action == 'tired' else MAIN_ACTIONS.index(action) * 8 + destination_row
                    output.paste(cell, (frame * FRAME_SIZE, runtime_row * FRAME_SIZE))
            action_info['directions'][direction] = {
                'source_row': source_row, 'source_boxes': [list(body.box) for body in row_bodies],
                'source_union': [left, top, right, bottom],
                'target_size': [target_width, target_height], 'offset': [offset_x, offset_y],
                'clean_target_size': [clean_width, clean_height], 'clean_offset': [clean_x, clean_y],
                'mask': 'isolated complete body component',
            }
        metadata['actions'][action] = action_info
        clean_actions[action] = clean
        native_actions[action] = native
    # Bathroom actions are one-shots. Begin and finish with the authored standing view.
    for action in ('pee', 'poop'):
        # Normally these are authored0/7. Additional QA reordering still has to
        # reconstruct the standing runtime entry/exit from its selected cells.
        authored_standing_frames = sorted({0, 7, selections[action][0], selections[action][-1]})
        for direction_index, direction in enumerate(DIRECTIONS):
            idle = main.crop((0, direction_index * FRAME_SIZE, FRAME_SIZE, (direction_index + 1) * FRAME_SIZE))
            destination_row = MAIN_ACTIONS.index(action) * 8 + direction_index
            for frame in (0, 7):
                main.paste(idle, (frame * FRAME_SIZE, destination_row * FRAME_SIZE))
            clean_idle = clean_actions['idle'].crop((0, direction_index * CLEAN_FRAME_SIZE,
                                                    CLEAN_FRAME_SIZE, (direction_index + 1) * CLEAN_FRAME_SIZE))
            for authored_frame in authored_standing_frames:
                native_actions[action].paste(idle, (authored_frame * FRAME_SIZE, direction_index * FRAME_SIZE))
                clean_actions[action].paste(clean_idle, (authored_frame * CLEAN_FRAME_SIZE, direction_index * CLEAN_FRAME_SIZE))
            metadata['actions'][action]['directions'][direction]['standing_entry_exit'] = {
                'destination_frames': [0, 7], 'source_action': 'idle', 'source_frame': 0,
                'native_and_clean_frames': authored_standing_frames,
            }
    verify_runtime(main, tired)
    verify_clean_exports(clean_actions)
    verify_clean_exports(native_actions, frame_size=FRAME_SIZE, label='native')
    verify_native_roundtrip(main, tired, native_actions, metadata['actions'])
    return main, tired, metadata, clean_actions, native_actions


def verify_clean_exports(actions: dict[str, Image.Image], *, frame_size: int = CLEAN_FRAME_SIZE,
                         label: str = 'clean') -> None:
    """Every editable action sheet retains all eight full authored-frame sequences."""
    for action, image in actions.items():
        expected_size = 8 * frame_size
        if image.size != (expected_size, expected_size):
            raise ValueError(f'{action}: {label} export must be {expected_size}×{expected_size}')
        signatures = []
        for direction_index, direction in enumerate(DIRECTIONS):
            signature = hashlib.sha256()
            for frame in range(8):
                cell = image.crop((frame * frame_size, direction_index * frame_size,
                                   (frame + 1) * frame_size, (direction_index + 1) * frame_size))
                box = cell.getchannel('A').getbbox()
                if box is None:
                    raise ValueError(f'{action} {direction} {label} frame {frame}: empty sprite')
                if box[0] <= 0 or box[1] <= 0 or box[2] >= frame_size or box[3] >= frame_size:
                    raise ValueError(f'{action} {direction} {label} frame {frame}: boundary clipping')
                signature.update(cell.tobytes())
            signatures.append(signature.digest())
        if len(set(signatures)) != len(DIRECTIONS):
            raise ValueError(f'{action}: {label} export must contain eight distinct direction sequences')


def verify_native_roundtrip(main: Image.Image, tired: Image.Image, native_actions: dict[str, Image.Image],
                            actions_metadata: dict[str, Any]) -> None:
    """The native full-frame exports must reconstruct every runtime pixel exactly."""
    for action, native in native_actions.items():
        output = tired if action == 'tired' else main
        for direction_index, direction in enumerate(DIRECTIONS):
            row = direction_index if action == 'tired' else MAIN_ACTIONS.index(action) * 8 + direction_index
            for frame, authored_frame in enumerate(actions_metadata[action]['source_frames']):
                exported = native.crop((authored_frame * FRAME_SIZE, direction_index * FRAME_SIZE,
                                        (authored_frame + 1) * FRAME_SIZE, (direction_index + 1) * FRAME_SIZE))
                runtime = output.crop((frame * FRAME_SIZE, row * FRAME_SIZE,
                                       (frame + 1) * FRAME_SIZE, (row + 1) * FRAME_SIZE))
                if exported.tobytes() != runtime.tobytes():
                    raise ValueError(f'{action} {direction} frame {frame}: native export round trip differs')


def verify_runtime(main: Image.Image, tired: Image.Image) -> None:
    """Reject empty/clipped frames or copied direction sequences before any write."""
    for action in ACTIONS:
        image = tired if action == 'tired' else main
        signatures = []
        for direction_index, direction in enumerate(DIRECTIONS):
            row = direction_index if action == 'tired' else MAIN_ACTIONS.index(action) * 8 + direction_index
            signature = hashlib.sha256()
            for frame in range(FRAME_COUNTS[action]):
                cell = image.crop((frame * FRAME_SIZE, row * FRAME_SIZE,
                                   (frame + 1) * FRAME_SIZE, (row + 1) * FRAME_SIZE))
                box = cell.getchannel('A').getbbox()
                if box is None:
                    raise ValueError(f'{action} {direction} frame {frame}: empty packed frame')
                if box[0] <= 0 or box[1] <= 0 or box[2] >= FRAME_SIZE or box[3] >= FRAME_SIZE:
                    raise ValueError(f'{action} {direction} frame {frame}: packed frame reaches its boundary')
                signature.update(cell.tobytes())
            signatures.append(signature.digest())
        if len(set(signatures)) != len(DIRECTIONS):
            raise ValueError(f'{action}: packed sheet does not have eight distinct visible direction sequences')


def atomic_image_write(image: Image.Image, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + '.tmp.png')
    image.save(temporary, optimize=True, compress_level=9)
    os.replace(temporary, destination)


def write_variant(directory: Path, variant: str,
                  packed: tuple[Image.Image, Image.Image, dict[str, Any],
                                dict[str, Image.Image], dict[str, Image.Image]],
                  packed_directory: Path) -> None:
    main, tired, metadata, clean_actions, native_actions = packed
    stem = FILE_STEMS[variant]
    if variant == 'normal':
        archive = ROOT / 'art-archive/bagnaskiz-before-reference-update'
        archive.mkdir(parents=True, exist_ok=True)
        for suffix in ('', '-tired'):
            original = ROOT / 'public/sprites' / f'{stem}{suffix}.png'
            saved = archive / original.name
            if original.exists() and not saved.exists():
                shutil.copy2(original, saved)
    atomic_image_write(main, ROOT / 'public/sprites' / f'{stem}.png')
    atomic_image_write(tired, ROOT / 'public/sprites' / f'{stem}-tired.png')
    for action, image in clean_actions.items():
        atomic_image_write(image, packed_directory / variant / f'{action}.png')
    for action, image in native_actions.items():
        atomic_image_write(image, packed_directory / 'native' / variant / f'{action}.png')
    metadata_path = directory / 'packing.json'
    temporary = metadata_path.with_name(metadata_path.name + '.tmp')
    temporary.write_text(json.dumps(metadata, indent=2) + '\n')
    os.replace(temporary, metadata_path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=ROOT / 'assets/8-directions/bagnaskiz')
    parser.add_argument('--variant', choices=('normal', 'armoured', 'all'), default='all')
    parser.add_argument('--packed-output', type=Path, default=ROOT / 'assets/8-directions/bagnaskiz/packed',
                        help='parent directory for 128px action sheets and native/ 40px full-frame sheets')
    parser.add_argument('--dry-run', action='store_true', help='validate and pack in memory without changing files')
    parser.add_argument('--check-source', type=Path, help='validate one 64-sprite source sheet without writing files')
    args = parser.parse_args()
    try:
        if args.check_source is not None:
            source = Image.open(args.check_source).convert('RGBA')
            _, info = extract_bodies(source)
            print(json.dumps({'source': str(args.check_source), **info}, separators=(',', ':')))
            return 0
        variants = tuple(FILE_STEMS) if args.variant == 'all' else (args.variant,)
        # Validate every requested costume before replacing any public PNG.
        results = [(variant, pack_variant(args.source_root / variant, variant)) for variant in variants]
        if not args.dry_run:
            for variant, packed in results:
                write_variant(args.source_root / variant, variant, packed, args.packed_output)
        for variant, (main_image, tired_image, _, clean_actions, native_actions) in results:
            print(f'{variant}: 12 actions, eight distinct directions, main {main_image.width}×{main_image.height}, '
                  f'tired {tired_image.width}×{tired_image.height}, {len(clean_actions)} cleaned 128px action sheets, '
                  f'{len(native_actions)} native 40px full-frame sheets'
                  + (' (dry run)' if args.dry_run else ''))
        return 0
    except (OSError, ValueError, KeyError) as error:
        print(f'Bagnaskiz packing failed: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
