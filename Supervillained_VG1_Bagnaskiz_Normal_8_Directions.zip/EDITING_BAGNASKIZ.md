# Editing the Bagnaskiz delivery

The compact game atlases in public/sprites are the authoritative installed images.
The native action sheets under assets/8-directions/bagnaskiz/packed/native contain
all eight authored frames at the original forty-pixel game size. Each sheet is an
8-column × 8-row grid: columns are frames, rows are N NE E SE S SW W NW.

Edit native cells in a pixel editor, keeping the transparent border and anchor
(20, 36). Reassemble them without resampling:

    python3 scripts/reassemble-bagnaskiz-atlases.py

The cleaned 128-pixel sheets under packed/normal and packed/armoured are larger
editable references with anchor (64, 116). They retain all eight authored frames
per direction. Runtime sniff/bark/hurt/tired use two selected frames; fetch uses
four. The selections and timing are recorded in animations.json and packing.json.

The original generated images have drifting cell positions and alpha processing
residue, so they are not shipped in these compact archives. The build script is
kept for workflows that retain those original generated sources. Use the native
reassembler above for an exact pixel-preserving rebuild from this delivery.

If two archives were delivered, extract both before running integration tests.
Shared code files are identical in both archives. The supplied integration patch
is based on commit 8a53d02bcdb8da3c1bb79ecbc8812018db64bd61; review it before
overwriting a manifest that has newer changes.
