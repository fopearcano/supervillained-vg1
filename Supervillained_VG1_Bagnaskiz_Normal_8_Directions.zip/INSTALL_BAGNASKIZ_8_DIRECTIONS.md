# Bagnaskiz — normal and Byzantine armoured animations

This delivery matches the supplied Bagnaskiz references and provides twelve actions for each
costume in eight directions: N, NE, E, SE, S, SW, W and NW. The normal rear-view reference is
included. The Byzantine back cross has the supplied three-bar Orthodox shape and slanted lower
bar, rendered as pixel art.

## Install

Extract the delivery archive into this game's project root, keeping folder paths. If delivery
is split into normal and armoured ZIPs, extract both before running the checks. The shared
integration files are identical in both archives.

The overlay was prepared against `claude/gallant-pascal-wjy5l2`, commit
`8a53d02bcdb8da3c1bb79ecbc8812018db64bd61`. It contains the updated manifest and regression
tests. A code patch is also included for reviewing or applying the integration to a checkout
that has moved on; do not overwrite a newer manifest without comparing changes.

Runtime files:

- Normal: `public/sprites/bagnaskiz.png` and `bagnaskiz-tired.png`.
- Byzantine armour: `public/sprites/bagnaskizArmoured.png` and `bagnaskizArmoured-tired.png`.
- Integration: `src/assets/manifest.ts`.

The normal key is `bagnaskiz`. The armoured art uses the existing `bagnaskizEmperor` key for
the Byzantine emperors. The French `bagnaskizMarshal` costume remains distinct.

Open the game's sprite viewer:

```text
?debug=sprites&char=bagnaskiz
?debug=sprites&char=bagnaskizEmperor
```

## Actions and files

Actions: idle, walk, run, sniff, pee, poop, eat/drink, bark, fetch, hurt, sit and tired. Idle
stands; sit is a separate seated clip; tired stands and pants. Pee and poop start and finish
standing. Fetch carries a yellow tennis ball. Normal hurt continues looping during the existing
arcade stun/flee behavior.

The main atlas uses forty-pixel cells, eight columns, and eight direction rows per action.
Its action order is the list above with tired omitted. Tired has its own two-column atlas.
The anchor is `(20, 36)`. Authored frame counts and holds match the game's existing full dog
animation layout; sniff, bark, hurt and tired use two runtime frames, and fetch uses four.

The delivery also includes clean editable action sheets with all eight authored frames per
direction, reference images, prompts, animation metadata and animated/contact previews. These
editable sheets are source assets; the game loads the compact forty-pixel runtime atlases.

For an exact rebuild after editing the native forty-pixel action sheets, run:

```bash
python3 scripts/reassemble-bagnaskiz-atlases.py
```

This copies the selected native frames into the runtime atlases without resampling. The larger
128-pixel sheets provide editable reference artwork; the original generated sheets with uneven
cell positions and matte residue are excluded from the compact delivery archives.

The full three-bar cross is clear in the larger artwork. At the game's forty-pixel character
size, the lower diagonal compresses into a tiny red mark; fine armour detail is retained in
the editable sheets and reference images.

## Checks

```bash
npm test
npm run build
```

Regression checks decode the actual PNGs, verify every active frame is visible, require eight
distinct directions in each frame, check clear borders, and verify the normal hurt loop and
imperial-role integration. The previews are rendered from the delivered runtime atlases.
All 173 tests and the production build passed on the prepared checkout. The native action
sheets also reconstruct all four delivered runtime PNGs pixel-for-pixel.
Live browser checking is unavailable in this execution environment because browser socket
creation is restricted; this limitation does not affect the exported PNG and GIF inspection.
