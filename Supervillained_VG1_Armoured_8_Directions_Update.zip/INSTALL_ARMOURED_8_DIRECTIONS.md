# Armoured animations — eight directions

This update gives armoured Zampanò and Sbrimbrulòn distinct N, NE, E, SE, S, SW, W and NW views
for all twelve actions: idle, walk, run, sniff, pee, poop, eat, bark, fetch, hurt, sit and tired.
The previous delivery had eight atlas rows but only four actual views: NE/E/SE matched, and
NW/W/SW matched.

## Install the compact ZIP

Extract `Supervillained_VG1_Armoured_8_Directions_Update.zip` into the game project root, keeping
its folder structure and replacing the four matching PNGs and sprite viewer file. This is an
overlay for the existing `claude/gallant-pascal-wjy5l2` animation integration, not a full game
project. The updated files are already installed in this local repository.

- `public/sprites/zampanoKnight.png` and `zampanoKnight-tired.png`
- `public/sprites/sbrimbrulonKnight.png` and `sbrimbrulonKnight-tired.png`
- `src/scenes/spriteViewerScene.ts`
- `preview/armoured-eight-directions.gif` shows idle, walk and run in all eight views.
- The two contact sheets in `preview/` show every action in all eight views.

Open `?debug=sprites&char=zampanoKnight` or `?debug=sprites&char=sbrimbrulonKnight` in the game
to see all actions and headings. No manifest edits or movement-code changes are needed.
The normal animation sheets are separate and stay unchanged.

## Source artwork and packing

The repository includes generated source atlases and prompts under `assets/8-directions/`.
The source artwork preserves the pointed helmets, broad shoulder plates, short body armour,
fur belly and paws below the armour, free curled tails and red crosses on the backs.

With Pillow installed, rebuild from the archived cardinal frames and new diagonal artwork:

```bash
python3 scripts/build-zampano-knight-diagonals.py
python3 scripts/build-sbrimbrulon-knight-diagonals.py
```

The scripts extract complete sprites and apply a fixed transform to each directional clip.
They retain the original N/E/S/W pixels, atlas dimensions, frame counts, timing and `(20, 36)`
ground anchor. Previous knight sheets are preserved in `art-archive/directions-before-8way/`.

## Verification

The pixel regression checks decode the actual PNGs, require eight distinct views for every
action, check every active frame is visible, and compare all cardinal frames with their
archived originals. The full test suite and production build pass. Contact sheets and motion
previews are rendered directly from the installed game atlases. Live browser verification is
unavailable in this execution environment because browser socket creation is restricted.
