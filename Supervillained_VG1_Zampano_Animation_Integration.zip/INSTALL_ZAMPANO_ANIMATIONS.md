# Zampanò animation integration

This ZIP is an overlay for branch `claude/gallant-pascal-wjy5l2` of `fopearcano/supervillained-vg1`, based on commit `ebb2d5d58b0961c6de2cb901a510cd52a1699314`. The game uses PixiJS and TypeScript for the web and Capacitor for Android. [Reviewed branch](https://github.com/fopearcano/supervillained-vg1/tree/ebb2d5d58b0961c6de2cb901a510cd52a1699314)

## Install

1. Extract the ZIP. Copy its `public`, `src`, `tests`, and `art-archive` folders and `ASSETS.md` into the repository root, next to `package.json`. Merge the folders and replace the matching files. If you have local changes to any matching TypeScript files, merge those changes before replacing them.
2. Run `npm ci` if dependencies are missing, then `npm run build` and `npm test`.
3. Run `npm run dev`. Open the URL Vite prints with `?debug=sprites&char=zampano` to inspect the loops, or `?skip=game` to try the Green Zone controls.
4. For an existing Android checkout, run `npm run android:sync` before building the APK.

## In-game mapping

| Source animation | Plain Zampanò trigger |
|---|---|
| Seated idle | Three seconds at rest. Longer rests alternate seated idle and sniffing. |
| Standing idle | Stopping or returning to free movement after an action. |
| Walk | Move with the joystick, WASD, or arrow keys. |
| Run | Move with RUN or Shift held and energy available. |
| Drink/eat | Pick up food or drink at water or a fountain. |
| Pee | Press PEE or Space in the Green Zone with bladder charges available. |
| Poop | The digestion rules trigger the squat automatically. |

The atlas uses the game's 40 × 40 cells and foot anchor at (20, 36). New actions use the back view for N, front for S, right profile for NE/E/SE, and left profile for NW/W/SW. The overhead artwork is in the original animation ZIP for a top-down camera. The game fits the authored pee, squat, and feeding frame holds to its existing action durations. The rag-cross and knight costumes each use their own sprite sheet.
