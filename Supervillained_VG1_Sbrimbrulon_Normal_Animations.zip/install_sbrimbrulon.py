#!/usr/bin/env python3
"""Install the Sbrimbrulon normal/knight sprites without replacing other character art.

Run from the extracted delivery: python install_sbrimbrulon.py --repo /path/to/supervillained
Only Python's standard library is required. Every source edit is preflighted before any write.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import struct
import tempfile
import uuid


BUNDLE = Path(__file__).resolve().parent
KEYS = ("sbrimbrulon", "sbrimbrulonKnight")

ANIMATIONS = """// SBRIMBRULON ANIMATIONS BEGIN
/** Authored Sbrimbrulòn clips. Their order is also the order of the runtime atlas rows. */
function sbrimClip(frameDurationsMs: readonly number[], loop = true): AnimDef {
  const frames = frameDurationsMs.length;
  const durationMs = frameDurationsMs.reduce((total, ms) => total + ms, 0);
  return { frames, fps: frames * 1000 / durationMs, loop, frameDurationsMs };
}

const SBRIMBRULON_ANIMS = {
  idle: sbrimClip([100, 110, 120, 110, 100, 110, 120, 110]),
  walk: sbrimClip([90, 80, 90, 110, 90, 80, 90, 110]),
  run: sbrimClip([50, 60, 60, 50, 60, 50, 50, 50]),
  sniff: { frames: 2, fps: 5, loop: true },
  pee: sbrimClip([120, 100, 130, 250, 360, 280, 140, 180], false),
  poop: sbrimClip([120, 130, 150, 220, 360, 220, 140, 180], false),
  eat: sbrimClip([110, 100, 100, 90, 180, 90, 90, 120]),
  bark: { frames: 2, fps: 10, loop: false },
  fetch: { frames: 4, fps: 13, loop: false },
  hurt: { frames: 2, fps: 10, loop: false },
  sit: sbrimClip([120, 120, 150, 120, 120, 120, 150, 120]),
  tired: { frames: 2, fps: 4, loop: true },
} satisfies Partial<Record<AnimName, AnimDef>>;
// SBRIMBRULON ANIMATIONS END

"""

TIMING = """import type { AnimDef } from './manifest';

export function animationDuration(def: AnimDef): number {
  return def.frames / def.fps;
}

/** Frame for an elapsed time in seconds. The sprite viewer can loop one-shots for inspection. */
export function animationFrame(def: AnimDef, seconds: number, loop = def.loop): number {
  const holds = def.frameDurationsMs;
  if (!holds) {
    const frame = Math.floor(seconds * def.fps);
    return loop ? frame % def.frames : Math.min(frame, def.frames - 1);
  }

  const elapsedMs = seconds * 1000;
  let elapsed = loop ? elapsedMs % (animationDuration(def) * 1000) : elapsedMs;
  for (let frame = 0; frame < def.frames - 1; frame++) {
    const hold = holds[frame]!;
    if (elapsed < hold) return frame;
    elapsed -= hold;
  }
  return def.frames - 1;
}
"""

ACTOR_FIELDS = """  private emoteAnim: AnimName = 'bark';
  private actionLocksMovement = false;
  private idleSeconds = 0;"""

ACTOR_ANIMATE = """      if (this.emoteLeft > 0) {
        this.emoteLeft = Math.max(0, this.emoteLeft - dt);
        this.idleSeconds = 0;
        this.animator.play(this.emoteAnim, dir);
      } else {
        this.actionLocksMovement = false;
        this.idleSeconds = moving ? 0 : this.idleSeconds + dt;
        const hasSit = CHARACTERS[this.animator.key].anims.sit !== undefined;
        this.animator.play(moving ? (running ? 'run' : 'walk') : hasSit && this.idleSeconds >= 3 ? 'sit' : 'idle', dir);
      }
      this.animator.update(dt);"""

ACTOR_METHODS = """  /** Plays a bark/hurt gesture while allowing the actor's existing movement. */
  emote(anim: 'bark' | 'hurt', seconds = 0.6): void {
    this.beginAction(anim, seconds, false);
  }

  /** Plays an authored action in place, then resumes the actor's behavior.
   * One-shots use their complete clip duration by default; loops play one cycle.
   */
  playAction(anim: AnimName, seconds?: number): void {
    if (!this.animator) return;
    const clip = CHARACTERS[this.animator.key].anims[anim];
    if (!clip) return;
    this.beginAction(anim, seconds ?? animationDuration(clip), true);
  }

  private beginAction(anim: AnimName, seconds: number, lockMovement: boolean): void {
    if (!this.animator || !CHARACTERS[this.animator.key].anims[anim]) return;
    if (!Number.isFinite(seconds) || seconds <= 0) return;
    this.emoteAnim = anim;
    this.emoteLeft = seconds;
    this.actionLocksMovement = lockMovement;
    this.idleSeconds = 0;
    this.animator.speed = 1;
    this.animator.play(anim, this.animator.dir, true);
  }"""

TESTS = """import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { animationDuration, animationFrame } from '../src/assets/animationTiming';
import { CHARACTERS, SHEET_DIRS } from '../src/assets/manifest';

const keys = ['sbrimbrulon', 'sbrimbrulonKnight'] as const;
const actions = ['idle', 'walk', 'run', 'sniff', 'pee', 'poop', 'eat', 'bark', 'fetch', 'hurt', 'sit', 'tired'];
const size = (path: string) => {
  const bytes = readFileSync(join('public', path));
  expect(bytes.subarray(0, 8)).toEqual(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  return [bytes.readUInt32BE(16), bytes.readUInt32BE(20)];
};

describe('complete Sbrimbrulòn normal and armoured delivery', () => {
  it('has matching twelve-action layouts, native anchors and separate tired atlases', () => {
    for (const key of keys) {
      const def = CHARACTERS[key];
      expect(Object.keys(def.anims)).toEqual(actions);
      expect([def.frameW, def.frameH, def.anchorX, def.anchorY]).toEqual([40, 40, 20, 36]);
      expect(size(def.sheet!)).toEqual([320, 11 * SHEET_DIRS.length * 40]);
      expect(size(def.animSheets!.tired!)).toEqual([80, 320]);
    }
    expect(CHARACTERS.sbrimbrulonKnight.anims).toEqual(CHARACTERS.sbrimbrulon.anims);
  });

  it('loops both eight-frame idles at authored holds', () => {
    for (const key of keys) {
      const { idle, sit } = CHARACTERS[key].anims;
      expect(animationFrame(idle!, 0.099)).toBe(0);
      expect(animationFrame(idle!, 0.100)).toBe(1);
      for (const clip of [idle!, sit!]) {
        expect(clip.frames).toBe(8);
        expect(animationFrame(clip, animationDuration(clip) + 0.005)).toBe(0);
      }
    }
  });

  it('holds the last frame of authored one-shots until the caller resumes behavior', () => {
    for (const key of keys) {
      for (const action of ['pee', 'poop', 'bark', 'fetch', 'hurt'] as const) {
        const clip = CHARACTERS[key].anims[action]!;
        expect(clip.loop).toBe(false);
        expect(animationFrame(clip, animationDuration(clip) + 0.01)).toBe(clip.frames - 1);
      }
    }
  });
});
"""

ACTOR_TESTS = """import { describe, expect, it, vi } from 'vitest';
import { Actor } from '../src/entities/actor';
import type { Entity } from '../src/entities/entity';
import type { GameMap } from '../src/world/map';
import { animationDuration } from '../src/assets/animationTiming';
import { CHARACTERS } from '../src/assets/manifest';

vi.mock('pixi.js', () => {
  class Container {
    addChild(_child: unknown): void {}
    destroy(_options: unknown): void {}
  }
  class Sprite {
    roundPixels = false;
    constructor(public texture: unknown) {}
  }
  return { Container, Sprite };
});
vi.mock('../src/core/assets', () => ({ textures: { get: (name: string) => name } }));

function context(key: 'sbrimbrulon' | 'sbrimbrulonKnight') {
  const actor = new Actor('sbrim', key, 0, 0);
  const map = {
    moveCircle: vi.fn((x: number, y: number, dx: number, dy: number) => ({ x: x + dx, y: y + dy, blocked: false })),
  };
  const player = { gx: 10, gy: 10 } as Entity;
  const step = (dt: number) => actor.step(dt, map as unknown as GameMap, player);
  return { actor, map, step };
}

describe.each(['sbrimbrulon', 'sbrimbrulonKnight'] as const)('%s actor action selection', (key) => {
  it('walks, stands when stopping, sits after three seconds, and stands again on movement', () => {
    const { actor, step } = context(key);
    actor.setBehavior({ kind: 'goto', to: { x: 3, y: 0 }, speed: 1 });
    step(0.1);
    expect(actor.animator!.anim).toBe('walk');
    actor.setBehavior({ kind: 'idle' });
    step(1);
    expect(actor.animator!.anim).toBe('idle');
    step(1);
    expect(actor.animator!.anim).toBe('idle');
    step(1);
    expect(actor.animator!.anim).toBe('sit');
    actor.setBehavior({ kind: 'goto', to: { x: 3, y: 0 }, speed: 1 });
    step(0.1);
    expect(actor.animator!.anim).toBe('walk');
  });

  it.each(['pee', 'poop', 'bark', 'fetch', 'hurt'] as const)('plays all of %s in place before resuming movement', (action) => {
    const { actor, map, step } = context(key);
    actor.setBehavior({ kind: 'goto', to: { x: 3, y: 0 }, speed: 1 });
    actor.playAction(action);
    const duration = animationDuration(CHARACTERS[key].anims[action]!);
    step(duration * 0.5);
    expect(actor.animator!.anim).toBe(action);
    expect(actor.animator!.finished).toBe(false);
    step(duration * 0.5);
    expect(actor.animator!.anim).toBe(action);
    expect(actor.animator!.finished).toBe(true);
    expect(map.moveCircle).not.toHaveBeenCalled();
    expect([actor.gx, actor.gy]).toEqual([0, 0]);
    step(0.01);
    expect(actor.animator!.anim).toBe('walk');
    expect(map.moveCircle).toHaveBeenCalledOnce();
    expect(actor.gx).toBeGreaterThan(0);
  });

  it('plays the tired clip and returns to standing instead of a stale seated animation', () => {
    const { actor, step } = context(key);
    step(3);
    expect(actor.animator!.anim).toBe('sit');
    actor.playAction('tired', 0.5);
    step(0.1);
    expect(actor.animator!.anim).toBe('tired');
    const first = actor.animator!.sprite.texture;
    step(0.25);
    expect(actor.animator!.sprite.texture).not.toBe(first);
    step(0.2);
    step(0.01);
    expect(actor.animator!.anim).toBe('idle');
  });
});
"""


VIEWER_TESTS = """import { describe, expect, it } from 'vitest';
import { spriteViewerLayout } from '../src/scenes/spriteViewerScene';

describe('portrait sprite viewer frame layout', () => {
  it.each([[192, 312], [216, 400], [270, 600]])('fits twelve complete 40px rows and all four profiles at %s × %s', (width, height) => {
    const layout = spriteViewerLayout(width, height, 12, 40, 40);
    const { margin, labelWidth, top, columnWidth, rowHeight, scale } = layout;
    const boxes: Array<{ left: number; top: number; right: number; bottom: number }> = [];
    for (let row = 0; row < 12; row++) {
      for (let col = 0; col < 4; col++) {
        const x = margin + labelWidth + col * columnWidth + (columnWidth - 40 * scale) / 2;
        const y = top + row * rowHeight + (rowHeight - 40 * scale) / 2;
        const left = Math.round(x + 20 * scale) - 20 * scale;
        const frameTop = Math.round(y + 36 * scale) - 36 * scale;
        const box = { left, top: frameTop, right: left + 40 * scale, bottom: frameTop + 40 * scale };
        expect(box.left).toBeGreaterThanOrEqual(margin + labelWidth);
        expect(box.top).toBeGreaterThanOrEqual(top);
        expect(box.right).toBeLessThanOrEqual(width - margin);
        expect(box.bottom).toBeLessThanOrEqual(height - margin);
        if (col) expect(box.left).toBeGreaterThan(boxes[boxes.length - 1]!.right);
        if (row) expect(box.top).toBeGreaterThan(boxes[(row - 1) * 4 + col]!.bottom);
        boxes.push(box);
      }
    }
    expect(boxes).toHaveLength(48);
  });

  it('recomputes frame scale when the game viewport changes', () => {
    const compact = spriteViewerLayout(192, 312, 12, 40, 40);
    const tall = spriteViewerLayout(216, 500, 12, 40, 40);
    expect(tall.scale).toBeGreaterThan(compact.scale);
    expect(tall.rowHeight).toBeGreaterThan(compact.rowHeight);
  });
});
"""


def once(text: str, before: str, after: str, label: str) -> str:
    if text.count(before) != 1:
        raise ValueError(f"{label}: expected one known source anchor, found {text.count(before)}. No files were changed; merge this edit manually.")
    return text.replace(before, after, 1)


def manifest(text: str) -> str:
    if "// SBRIMBRULON ANIMATIONS BEGIN" in text:
        if ANIMATIONS not in text:
            raise ValueError("The installed Sbrimbrulòn timing block has local edits. No files were changed.")
        for expected in ("  'sbrimbrulonKnight',", "sbrimbrulon-tired.png", "sbrimbrulonKnight-tired.png", "? SBRIMBRULON_ANIMS"):
            if expected not in text:
                raise ValueError("The installed Sbrimbrulòn manifest is incomplete. No files were changed.")
        return text
    if "'sit'" not in text.split("export type AnimName", 1)[0]:
        text = once(text, "'fetch', 'hurt', 'tired']", "'fetch', 'hurt', 'sit', 'tired']", "ANIMS")
    if "frameDurationsMs?: readonly number[];" not in text:
        text = once(text, "  loop: boolean;\n}", "  loop: boolean;\n  /** Optional authored frame holds, in playback order. */\n  frameDurationsMs?: readonly number[];\n}", "AnimDef")
    text = once(text, "  'sbrimbrulon',\n", "  'sbrimbrulon',\n  'sbrimbrulonKnight',\n", "CAST_KEYS")
    text = once(text,
        "  sbrimbrulon: { sheet: 'sprites/sbrimbrulon.png' },",
        "  sbrimbrulon: { sheet: 'sprites/sbrimbrulon.png', animSheets: tired('sprites/sbrimbrulon-tired.png') },\n  sbrimbrulonKnight: { sheet: 'sprites/sbrimbrulonKnight.png', animSheets: tired('sprites/sbrimbrulonKnight-tired.png') },",
        "DELIVERED")
    text = once(text, "function castDefs<K extends string>", ANIMATIONS + "function castDefs<K extends string>", "cast definitions")
    text = once(text, "      anims:\n        key ===", "      anims:\n        key === 'sbrimbrulon' || key === 'sbrimbrulonKnight'\n          ? SBRIMBRULON_ANIMS\n          : key ===", "cast animation choice")
    return text


def entity(text: str) -> str:
    if "import { animationDuration, animationFrame } from '../assets/animationTiming';" in text:
        if "animationFrame(this.definition, this.time)" not in text or "this.time >= animationDuration(def)" not in text:
            raise ValueError("Unknown authored CharacterAnimator playback. No files were changed.")
        return text
    text = once(text, "import { textures } from '../core/assets';", "import { textures } from '../core/assets';\nimport { animationDuration, animationFrame } from '../assets/animationTiming';", "entity imports")
    text = once(text, "textureName, type AnimName,", "textureName, type AnimDef, type AnimName,", "entity definition type")
    start = text.index("  get finished(): boolean {")
    old = text[start:]
    expected = """  get finished(): boolean {
    const def = (CHARACTERS[this.key].anims as Record<string, { frames: number; fps: number; loop: boolean }>)[this.anim]!;
    return !def.loop && this.time * def.fps >= def.frames;
  }

  update(dt: number): void {
    this.time += dt * this.speed;
    const def = (CHARACTERS[this.key].anims as Record<string, { frames: number; fps: number; loop: boolean }>)[this.anim]!;
    let frame = Math.floor(this.time * def.fps);
    frame = def.loop ? frame % def.frames : Math.min(frame, def.frames - 1);
    this.sprite.texture = textures.get(textureName(this.key, this.anim, this.dir, frame));
  }
}
"""
    replacement = """  get definition(): AnimDef {
    const anims = CHARACTERS[this.key].anims;
    return anims[this.anim] ?? anims.idle!;
  }

  get finished(): boolean {
    const def = this.definition;
    return !def.loop && this.time >= animationDuration(def);
  }

  update(dt: number): void {
    this.time += dt * this.speed;
    const frame = animationFrame(this.definition, this.time);
    this.sprite.texture = textures.get(textureName(this.key, this.anim, this.dir, frame));
  }
}
"""
    if old != expected:
        raise ValueError("Unknown CharacterAnimator implementation. No files were changed.")
    return text[:start] + replacement


RESPONSIVE_VIEWER = """import { Container, Graphics, Sprite } from 'pixi.js';
import { textures } from '../core/assets';
import type { Game } from '../core/game';
import type { Scene } from '../core/scene';
import { animationFrame } from '../assets/animationTiming';
import { CHARACTERS, textureName, type AnimName, type CharacterKey } from '../assets/manifest';
import type { Dir8 } from '../iso/projection';
import { PixelText } from '../ui/pixelText';

/** Four distinct source profiles; the runtime atlases retain all eight facing directions. */
const VIEW_DIRS: readonly Dir8[] = ['S', 'W', 'E', 'N'];

/** Fit complete frames into a portrait table without overlapping adjacent rows. */
export function spriteViewerLayout(width: number, height: number, rows: number, frameW: number, frameH: number) {
  const margin = 2;
  const labelWidth = 44;
  const top = 28;
  const columnWidth = Math.max(1, (width - margin * 2 - labelWidth) / VIEW_DIRS.length);
  const rowHeight = Math.max(1, (height - top - margin) / Math.max(1, rows));
  const scale = Math.max(0.01, Math.min(1, (columnWidth - 4) / frameW, (rowHeight - 2) / frameH));
  return { margin, labelWidth, top, columnWidth, rowHeight, scale };
}

/** Debug page: every action playing in front, left, right and back views. */
export class SpriteViewerScene implements Scene {
  readonly root = new Container();
  readonly pausesBelow = true;
  private readonly background = new Graphics();
  private readonly title: PixelText;
  private readonly labels: PixelText[] = [];
  private readonly headings: PixelText[] = [];
  private readonly cells: Array<{ sprite: Sprite; anim: AnimName; dir: Dir8; row: number; col: number }> = [];
  private time = 0;

  constructor(
    readonly game: Game,
    readonly key: CharacterKey,
  ) {
    const def = CHARACTERS[key];
    this.root.addChild(this.background);
    this.title = new PixelText(key.toUpperCase(), { color: '#ffe23a', outline: '#000000' });
    this.root.addChild(this.title);
    VIEW_DIRS.forEach((dir) => {
      const heading = new PixelText(dir, { color: '#ffffff', outline: '#000000' });
      this.root.addChild(heading);
      this.headings.push(heading);
    });
    (Object.keys(def.anims) as AnimName[]).forEach((anim, row) => {
      const label = new PixelText(anim.toUpperCase(), { color: '#ffffff', outline: '#000000' });
      this.root.addChild(label);
      this.labels.push(label);
      VIEW_DIRS.forEach((dir, col) => {
        const sprite = new Sprite(textures.get(textureName(key, anim, dir, 0)));
        sprite.roundPixels = true;
        this.root.addChild(sprite);
        this.cells.push({ sprite, anim, dir, row, col });
      });
    });
    this.resize(game.width, game.height);
  }

  resize(width: number, height: number): void {
    const def = CHARACTERS[this.key];
    const layout = spriteViewerLayout(width, height, this.labels.length, def.frameW, def.frameH);
    const { margin, labelWidth, top, columnWidth, rowHeight, scale } = layout;
    this.background.clear().rect(0, 0, width, height).fill(0x3fcf1f);
    this.title.scale.set(Math.min(1, (width - margin * 2) / this.title.texture.frame.width));
    this.title.position.set(margin, margin);
    this.headings.forEach((heading, col) => {
      const centerX = margin + labelWidth + (col + 0.5) * columnWidth;
      heading.position.set(Math.round(centerX - heading.width / 2), 16);
    });
    this.labels.forEach((label, row) => {
      label.position.set(margin, Math.round(top + row * rowHeight + (rowHeight - label.height) / 2));
    });
    for (const { sprite, row, col } of this.cells) {
      const left = margin + labelWidth + col * columnWidth + (columnWidth - def.frameW * scale) / 2;
      const y = top + row * rowHeight + (rowHeight - def.frameH * scale) / 2;
      sprite.scale.set(scale);
      sprite.position.set(Math.round(left + def.anchorX * scale), Math.round(y + def.anchorY * scale));
    }
  }

  update(dt: number): void {
    this.time += dt;
    const anims = CHARACTERS[this.key].anims;
    for (const c of this.cells) {
      const frame = animationFrame(anims[c.anim]!, this.time, true);
      c.sprite.texture = textures.get(textureName(this.key, c.anim, c.dir, frame));
    }
  }
}
"""

KNOWN_VIEWER_SHA256 = ['2231f2ddcb245a68df55bea6068daf67fba21c4e8eb74238c0cadce9c85983b6', '70b35bcef7408eaa12f6e48cb0966fec1b195cf4663f8a7ec7c416951f02f541', 'e895efa34ddaf5e4db71d5753c0a253194edc4f9191a404b178a77942ed45610']

def viewer(text: str) -> str:
    if text == RESPONSIVE_VIEWER:
        return text
    if sha256(text.encode('utf-8')).hexdigest() not in KNOWN_VIEWER_SHA256:
        raise ValueError("Unknown sprite viewer layout. No files were changed; merge the viewer diff manually.")
    return RESPONSIVE_VIEWER


def actor(text: str) -> str:
    if "  private actionLocksMovement = false;" in text:
        if ACTOR_METHODS not in text or ACTOR_ANIMATE not in text or ACTOR_FIELDS not in text:
            raise ValueError("The installed Sbrimbrulòn Actor integration has local edits. No files were changed.")
        return text
    text = once(text, "import { spriteName, type CharacterKey } from '../assets/manifest';", "import { CHARACTERS, spriteName, type AnimName, type CharacterKey } from '../assets/manifest';\nimport { animationDuration } from '../assets/animationTiming';", "actor imports")
    text = once(text, "  private emoteAnim: 'bark' | 'hurt' = 'bark';", ACTOR_FIELDS, "actor action state")
    text = once(text, "    this.time += dt;\n    const b = this.behavior;", "    this.time += dt;\n    if (this.actionLocksMovement && this.emoteLeft > 0) {\n      this.animate(dt, false, false);\n      return;\n    }\n    const b = this.behavior;", "actor action movement lock")
    text = once(text, """      if (this.emoteLeft > 0) {
        this.emoteLeft -= dt;
        this.animator.play(this.emoteAnim, dir);
      } else this.animator.play(moving ? (running ? 'run' : 'walk') : 'idle', dir);
      this.animator.update(dt);""", ACTOR_ANIMATE, "actor animation selection")
    return once(text, """  /** Plays a bark/hurt animation for flavor (critters only). */
  emote(anim: 'bark' | 'hurt', seconds = 0.6): void {
    this.emoteAnim = anim;
    this.emoteLeft = seconds;
    this.animator?.play(anim, this.animator.dir, true);
  }""", ACTOR_METHODS, "actor action API")


def placeholders(text: str) -> str:
    if "  sbrimbrulonKnight: {" in text:
        return text
    return once(text, "  /** Mad chihuahua:", """  /** Fallback only; the delivered PNG supplies the reference-matching knight art. */
  sbrimbrulonKnight: {
    ...ZAMPANO_SPEC,
    colors: { ...ZAMPANO_SPEC.colors, ...recolor('#bc7836', '#473022', '#071e1b', '#071e1b') },
    marks: 'patches', markColor: '#fff3d9', muzzle: '#fff3d9', eyes: 'big',
    costume: 'tabard', hat: 'helm', hatColor: '#99959a',
  },
  /** Mad chihuahua:""", "knight fallback")


def sprite_tests(text: str) -> str:
    if "'sbrimbrulonKnight', 'watson'" in text:
        return text
    return once(text, "'sbrimbrulon', 'watson'", "'sbrimbrulon', 'sbrimbrulonKnight', 'watson'", "delivered sprite expectations")


def new_file_or_identical(path: Path, wanted: bytes) -> bytes:
    if path.exists() and path.read_bytes() != wanted:
        raise ValueError(f"{path}: file already exists with different contents. No files were changed.")
    return wanted


def prepare(repo: Path) -> dict[str, bytes]:
    if not (repo / 'package.json').is_file():
        raise ValueError(f"Not a repository root (missing package.json): {repo}")
    edits = {}
    transformers = {
        'src/assets/manifest.ts': manifest,
        'src/entities/entity.ts': entity,
        'src/scenes/spriteViewerScene.ts': viewer,
        'src/entities/actor.ts': actor,
        'src/assets/placeholders/cast.ts': placeholders,
        'tests/sprites.test.ts': sprite_tests,
    }
    for relative, transform in transformers.items():
        path = repo / relative
        edits[relative] = transform(path.read_text(encoding='utf-8')).encode('utf-8')
    timing = repo / 'src/assets/animationTiming.ts'
    edits['src/assets/animationTiming.ts'] = new_file_or_identical(timing, TIMING.encode('utf-8'))
    test = repo / 'tests/sbrimbrulon.test.ts'
    edits['tests/sbrimbrulon.test.ts'] = new_file_or_identical(test, TESTS.encode('utf-8'))
    actor_test = repo / 'tests/sbrimbrulonActor.test.ts'
    edits['tests/sbrimbrulonActor.test.ts'] = new_file_or_identical(actor_test, ACTOR_TESTS.encode('utf-8'))
    viewer_test = repo / 'tests/spriteViewerLayout.test.ts'
    edits['tests/spriteViewerLayout.test.ts'] = new_file_or_identical(viewer_test, VIEWER_TESTS.encode('utf-8'))
    for key in KEYS:
        for suffix, dimensions in (('', (320, 3520)), ('-tired', (80, 320))):
            relative = f'public/sprites/{key}{suffix}.png'
            source = BUNDLE / 'game' / relative
            data = source.read_bytes()
            if data[:8] != b'\x89PNG\r\n\x1a\n' or len(data) < 33 or struct.unpack('>II', data[16:24]) != dimensions:
                raise ValueError(f"Invalid runtime PNG or dimensions: {source}")
            edits[relative] = data
    return {relative: data for relative, data in edits.items() if not (repo / relative).exists() or (repo / relative).read_bytes() != data}


def install(repo: Path, edits: dict[str, bytes], dry_run: bool) -> None:
    if not edits:
        print('Sbrimbrulòn normal and knight integration is already installed; no changes needed.')
        return
    print(('Would install ' if dry_run else 'Installing ') + str(len(edits)) + ' files:')
    for relative in edits:
        print('  ' + relative)
    if dry_run:
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8]
    backup = repo / '.sbrimbrulon-backups' / stamp
    originals: dict[str, bytes | None] = {}
    staged: dict[str, Path] = {}
    try:
        for relative, data in edits.items():
            path = repo / relative
            originals[relative] = path.read_bytes() if path.exists() else None
            if path.exists():
                saved = backup / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, saved)
            path.parent.mkdir(parents=True, exist_ok=True)
            handle, temporary = tempfile.mkstemp(prefix='.sbrim-stage-', dir=path.parent)
            with os.fdopen(handle, 'wb') as stream:
                stream.write(data)
            staged[relative] = Path(temporary)
        for relative, temporary in staged.items():
            os.replace(temporary, repo / relative)
    except BaseException:
        for relative, original in originals.items():
            path = repo / relative
            if original is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(original)
        raise
    finally:
        for temporary in staged.values():
            temporary.unlink(missing_ok=True)
    print('Installed. Backups: ' + str(backup))
    print('Next: npm run build && npm test')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True, help='Repository root containing package.json')
    parser.add_argument('--dry-run', action='store_true', help='Validate all source edits and PNGs without writing files')
    args = parser.parse_args()
    repo = args.repo.resolve()
    try:
        edits = prepare(repo)
        install(repo, edits, args.dry_run)
    except (OSError, ValueError) as error:
        parser.exit(1, f'Install stopped: {error}\n')


if __name__ == '__main__':
    main()
