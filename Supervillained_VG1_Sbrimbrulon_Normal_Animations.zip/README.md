# Sbrimbrulòn — normal and armoured animation ZIPs

This delivery is split into two archives for smaller GitHub uploads:

- Supervillained_VG1_Sbrimbrulon_Normal_Animations.zip: normal artwork.
- Supervillained_VG1_Sbrimbrulon_Armoured_Animations.zip: armoured artwork.

Each archive contains twelve transparent animation sheets, five views, eight frames per view, its two game-ready atlases, timing metadata, and a static contact preview. The sprite PNGs retain the original quality and exact bytes. The large combined animated preview is supplied separately in the earlier delivery.

## Install both costume sets

Extract BOTH ZIPs into the SAME folder, merging their contents. Keep the supplied relative paths. Shared installation files are identical in the two archives and can be overwritten when merging.

The merged folder must contain all four PNGs under game/public/sprites/. Then run:

```sh
python install_sbrimbrulon.py --repo "/path/to/supervillained-vg1"
```

Use python3 or py if that is your installed Python command. Read INSTALL_SBRIMBRULON_ANIMATIONS.md and CLAUDE_IMPLEMENTATION.md for the complete implementation instructions. Either archive alone supplies one costume's artwork; the existing game installer requires both sets together.

For GitHub, upload both smaller ZIPs for Claude to extract, or extract their contents locally and commit the merged implementation files.

## Sheets

Each sheet uses eight 256 × 256 frame columns and five view rows: front, back, side-L, side-R, top. Each costume's animations.json supplies timing and playback flags.

Actions: seated idle, standing idle, walk, run, drinking/eating, pee, squat, sniff, bark, hurt/flinch, tired/pant, fetch/pounce. Both idles visibly breathe; walk and run play in place.
