# Sbrimbrulòn — normal and armoured animations

> Split delivery: extract BOTH the Normal and Armoured ZIPs into the SAME folder before running the installer. Merge their contents and preserve the paths. The installer needs all four runtime PNGs.

This delivery contains the complete matching normal and armoured character: twelve actions, five source views, eight frames in each source view, transparent PNG sheets, timing metadata, previews, and PixiJS/TypeScript integration for Supervillained VG1.

The character keeps the large exposed eye, white fringe covering the other eye, dark and rust coat, white muzzle and paws, and worried mouth. The armoured version adds the supplied helmet with nose guard, rounded shoulder plates, short mail coat, and red cross on the back. The tail and lower furry legs remain exposed.

## Install

Extract the ZIP anywhere outside the game repository. Python 3 is the only installer requirement.

```sh
python install_sbrimbrulon.py --repo "/path/to/supervillained-vg1"
```

Use `python3` on systems where Python is installed with that command. On Windows, `py` can be used instead. The target path is the directory containing the game's `package.json`.

The installer validates every edit before writing, backs up replaced files in the target repository, and preserves other characters' assets and animation definitions. It can be run again without duplicating edits. To review the planned changes first, add `--dry-run`. If a source file has a different layout, the installer stops before changing any files; `current-31614e8.patch` shows the integration edits for manual merging.

The supported source layouts are the original branch at `ebb2d5d58b0961c6de2cb901a510cd52a1699314`, the branch read on 18 November 2026 at `31614e80fb4d2e3d5d3747fd5e8005c51aa16e2b`, and the preceding Zampanò plain/knight animation overlay. No earlier animation ZIP is required.

From the game repository, run:

```sh
npm run build
npm test
npm run dev
```

Open the Vite address with `?debug=sprites&char=sbrimbrulon` for the normal version and `?debug=sprites&char=sbrimbrulonKnight` for the armoured version. All twelve actions fit in the responsive viewer, with four columns **S, W, E, N** showing front, left, right and back. Frames scale to the available row height so adjacent actions do not overlap.

For Android, run `npm run android:sync` before rebuilding the APK.

## Game keys and actions

Existing story actors with the `sbrimbrulon` key automatically use the new normal art. Use `sbrimbrulonKnight` when a scene calls for armour, for example:

```ts
const friend = ctx.addActor(
  'sbrim', 'sbrimbrulonKnight',
  { x: 3.4, y: 4.4 }, { kind: 'idle', face: 'E' },
);
```

For an `Actor` instance, movement selects walking/running. Stopping selects the standing idle, then the seated idle after three seconds. Both idles visibly rise and fall. `Actor.playAction()` plays any supported action in place and then resumes the actor's existing behavior:

```ts
friend.playAction('pee');       // complete one-shot, including return to standing
friend.playAction('poop');
friend.playAction('eat', 1.5);   // eating/drinking pose for 1.5 seconds
friend.playAction('tired', 2);   // panting for 2 seconds
friend.playAction('sniff');
friend.playAction('bark');
friend.playAction('fetch');
friend.playAction('hurt');
```

An action with no explicit duration uses one complete animation cycle. Non-looping clips hold their final frame until behavior resumes. `emote('bark' | 'hurt', seconds)` retains the existing moving gesture behavior. Armour is available through the new key; the package does not invent story events or alter chapter costume choices.

## Files and layouts

| Location | Content |
|---|---|
| `animations/normal/sheets/` | Twelve transparent normal sheets |
| `animations/armoured/sheets/` | Twelve transparent armoured sheets |
| `animations/normal/animations.json`, `animations/armoured/animations.json` | Five-view sheet metadata, frame holds and runtime action mapping |
| `previews/` | Animated previews and contact sheets |
| `game/public/sprites/sbrimbrulon.png` | Normal runtime atlas, 320 × 3520 pixels |
| `game/public/sprites/sbrimbrulon-tired.png` | Normal tired atlas, 80 × 320 pixels |
| `game/public/sprites/sbrimbrulonKnight.png` | Armoured runtime atlas, 320 × 3520 pixels |
| `game/public/sprites/sbrimbrulonKnight-tired.png` | Armoured tired atlas, 80 × 320 pixels |
| `install_sbrimbrulon.py` | Preflighted source integration and asset installation |
| `current-31614e8.patch` | Reviewable source diff against the verified current branch |
| `CLAUDE_IMPLEMENTATION.md` | Implementation brief for Claude |

Each large sheet is 2048 × 1280 pixels: eight columns of 256 × 256 cells and five rows ordered **front, back, side-L, side-R, top**. Read each animation left to right.

The runtime uses 40 × 40 cells, ground anchor `(20, 36)`, and eight direction rows per action: **N, NE, E, SE, S, SW, W, NW**. N uses the back view; S uses the front; NE/E/SE use side-R; NW/W/SW use side-L. The overhead art is supplied in the large sheets for a top-down camera.

| Runtime action | Source action | Runtime frames |
|---|---|---:|
| `idle` | Standing | 8 |
| `walk` | Walking | 8 |
| `run` | Running | 8 |
| `sniff` | Sniffing | 2 |
| `pee` | Peeing | 8 |
| `poop` | Squatting | 8 |
| `eat` | Drinking/eating | 8 |
| `bark` | Barking | 2 |
| `fetch` | Fetching | 4 |
| `hurt` | Flinching | 2 |
| `sit` | Seated idle | 8 |
| `tired` | Panting, separate atlas | 2 |

The main atlas contains the first eleven actions in this exact order. Tired is loaded from its separate atlas. Unused columns are transparent. The source sheets keep all eight exported frames even where the runtime uses a shorter clip.
