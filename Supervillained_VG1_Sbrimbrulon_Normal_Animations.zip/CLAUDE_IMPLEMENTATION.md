# Implement Sbrimbrulòn's normal and armoured animations

> Split delivery: extract BOTH the Normal and Armoured ZIPs into the SAME folder before running the installer. Merge their contents and preserve the paths. The installer needs all four runtime PNGs.

Use this package to replace Sbrimbrulòn's old normal sprite sheet and add his armoured variant in `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`.

1. Read `INSTALL_SBRIMBRULON_ANIMATIONS.md` and inspect the `current-31614e8.patch` source diff.
2. Run `python install_sbrimbrulon.py --repo <repository-root> --dry-run`, then run the same command without `--dry-run`. The installer supports original `ebb2d5d`, current `31614e8`, and the prior Zampanò animation overlay. Preserve other local changes. If the installer stops on a changed source anchor, manually merge the corresponding review diff and use the installer constants as the authored timing reference.
3. The four runtime PNGs are supplied under `game/public/sprites/`. Use these newly generated images for every Sbrimbrulòn action. Preserve the reference's exposed eye and asymmetric white fringe, rust/dark/white coat, and worried mouth. Preserve the armoured design and red cross in rear views. Use nearest-neighbor sampling in the renderer.
4. Normal key: `sbrimbrulon`. Armoured key: `sbrimbrulonKnight`. Both have twelve animations. Main atlases are 320 × 3520, tired atlases 80 × 320, frame size 40 × 40, anchor `(20, 36)`. The main action row order is idle/walk/run/sniff/pee/poop/eat/bark/fetch/hurt/sit; each action has eight direction rows. Tired is separate. The manifest constants specify exact frame counts and holds.
5. Existing normal story appearances use the replacement automatically. Select `sbrimbrulonKnight` explicitly when a scene needs the costume. Keep chapter events as they are unless a separate instruction asks for a story change. Use `Actor.playAction()` for the new companion gestures, which pause movement during playback and then resume the actor's behavior. Standing transitions to seated idle after three seconds; movement resets the idle timer.
6. Run `npm run build` and `npm test`. Check both `?debug=sprites&char=sbrimbrulon` and `?debug=sprites&char=sbrimbrulonKnight`, verify every action in the four cardinal preview columns (S/W/E/N) and preserve all eight native atlas direction rows, and confirm standing/seated motion and complete return-to-standing bathroom one-shots. For Android, run `npm run android:sync` before rebuilding.

The delivery includes twenty-four large five-view animation sheets for future re-export. Those source sheets have eight 256 × 256 frames per row; they are not directly substituted for the native runtime atlases.
