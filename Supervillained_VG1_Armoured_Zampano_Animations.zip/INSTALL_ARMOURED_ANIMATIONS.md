# Armoured Zampanò animations

The animation sheets depict the supplied armoured character with his conical helmet, rounded shoulder plates, short mail coat, exposed furry legs and tail, and red cross on the back. The twelve actions are seated idle, standing idle, walk, run, drink/eat, pee, poop, sniff, bark, flinch, tired, and fetch.

The large sheets use five direction rows in the order front, back, side-L, side-R, and overhead. Each row contains eight 256 × 256 frames, read left to right. The timing metadata gives the frame holds and looping behaviour. The preview files show the complete set.

## Install in Supervillained VG1

The `game` folder is an overlay for `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`, based on commit `ebb2d5d58b0961c6de2cb901a510cd52a1699314`.

The overlay includes the current plain-character atlases required by the shared animation definitions, together with the new knight atlases.

1. Copy the contents of `game` into the repository root, next to `package.json`. Merge the folders and replace the matching files. Merge any local TypeScript edits before replacing the corresponding files.
2. Run `npm ci` if dependencies are missing. Run `npm run build` and `npm test`.
3. Run `npm run dev`. Open the URL Vite prints with `?debug=sprites&char=zampanoKnight` to inspect the knight costume.
4. For Android, run `npm run android:sync` before rebuilding the APK.

The game selects the knight costume through its existing story progression. Standing, walking, running, eating, drinking, peeing, squatting, barking, flinching, fetching, and tired poses follow the existing controls and action states. After three seconds at rest, the knight also uses the seated idle and then alternates resting and sniffing. The frame timing fits the existing action timers.

## Runtime files

The game uses 40 × 40 cells with the foot anchor at (20, 36). Both knight PNGs must be installed together.

| File | Purpose |
|---|---|
| `public/sprites/zampanoKnight.png` | 320 × 3520 atlas for eleven actions in manifest order |
| `public/sprites/zampanoKnight-tired.png` | 80 × 320 strip for the tired action |
| `src/assets/manifest.ts` | Knight and plain action definitions, frame counts and timing |
| `src/assets/animationTiming.ts` | Authored frame hold playback |
| `src/entities/entity.ts` | Directional animation playback |
| `src/entities/zampano.ts` | Costume switching and idle/action selection |
| `src/config.ts` | Seated idle delay |
| `src/scenes/spriteViewerScene.ts` | Preview timing |
| `tests/sprites.test.ts` | Sheet layout and animation timing checks |
| `ASSETS.md` | Current sprite layout documentation |

The runtime direction rows are N, NE, E, SE, S, SW, W, NW. N uses the back view, S the front view, NE/E/SE the right profile, and NW/W/SW the left profile. The overhead row is available in the large sheets for a top-down camera.
