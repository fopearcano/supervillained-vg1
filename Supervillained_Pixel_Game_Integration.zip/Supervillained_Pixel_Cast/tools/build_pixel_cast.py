#!/usr/bin/env python3
"""Assemble authored pixel poses. This script never draws characters or invents poses.

Input config: {"characters": [{"key": "santina", "label": "Santina",
"source": "/absolute/generated-sheet.png", "mode": "generated"}, ...]}.
Generated sources are authored 8x8 grids: direction rows N NE E SE S SW W NW;
columns idle0 idle1 walk0 walk1 walk2 walk3 gesture hurt. Existing runtime sheets
can be included with mode="existing" and optional tired_source / animations.

Usage: python work/build_pixel_cast.py --config work/cast.json --out deliverable
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import io
import json
import math
import shutil
from collections import OrderedDict
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
NPC = OrderedDict([
    ("idle", {"frames": 2, "fps": 3, "loop": True}),
    ("walk", {"frames": 4, "fps": 9, "loop": True}),
    ("run", {"frames": 4, "fps": 13, "loop": True}),
    ("bark", {"frames": 2, "fps": 8, "loop": True}),
    ("hurt", {"frames": 2, "fps": 10, "loop": True}),
])
SBRIM = OrderedDict([
    ("idle", {"loop": True, "frameDurationsMs": [100,110,120,110,100,110,120,110]}),
    ("walk", {"loop": True, "frameDurationsMs": [90,80,90,110,90,80,90,110]}),
    ("run", {"loop": True, "frameDurationsMs": [50,60,60,50,60,50,50,50]}),
    ("sniff", {"frames": 2, "fps": 5, "loop": True}),
    ("pee", {"loop": False, "frameDurationsMs": [120,100,130,250,360,280,140,180]}),
    ("poop", {"loop": False, "frameDurationsMs": [120,130,150,220,360,220,140,180]}),
    ("eat", {"loop": True, "frameDurationsMs": [110,100,100,90,180,90,90,120]}),
    ("bark", {"frames": 2, "fps": 10, "loop": False}),
    ("fetch", {"frames": 4, "fps": 13, "loop": False}),
    ("hurt", {"frames": 2, "fps": 10, "loop": False}),
    ("sit", {"loop": True, "frameDurationsMs": [120,120,150,120,120,120,150,120]}),
    ("tired", {"frames": 2, "fps": 4, "loop": True}),
])
COLS = {"idle": [0,1], "walk": [2,3,4,5], "run": [2,3,4,5], "bark": [0,6], "hurt": [7,0]}
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def normalize_animations(defs):
    result = OrderedDict()
    for name, definition in defs.items():
        clip = dict(definition)
        holds = clip.get("frameDurationsMs")
        if holds:
            if any(not isinstance(ms,(int,float)) or ms <= 0 for ms in holds):
                raise ValueError(f"{name}: frame durations must be positive")
            clip["frameDurationsMs"] = list(holds)
            clip["frames"] = len(holds)
            clip["fps"] = 1000 * len(holds) / sum(holds)
        if clip.get("frames",0) <= 0 or clip.get("fps",0) <= 0:
            raise ValueError(f"{name}: positive frames and fps required")
        result[name] = clip
    return result


SBRIM = normalize_animations(SBRIM)


def font(size=15):
    try:
        return ImageFont.truetype(FONT_PATH, size)
    except OSError:
        return ImageFont.load_default()


def digest(im):
    return hashlib.sha256(im.tobytes()).hexdigest()


def hard_alpha(im, threshold):
    im = im.convert("RGBA")
    im.putalpha(im.getchannel("A").point(lambda a: 255 if a >= threshold else 0))
    return im


def clear_hidden_rgb(im):
    # Deterministic hashes and lossless compression: invisible pixels carry no RGB.
    pixels = list(im.getdata())
    im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in pixels])
    return im


def shared_palette(frames, colors):
    """Quantize only opaque pixels, then apply the same palette to every pose."""
    opaque = []
    for im in frames:
        opaque.extend((r,g,b) for r,g,b,a in im.getdata() if a)
    if not opaque:
        raise ValueError("source sheet has no opaque character pixels")
    w = 256
    h = (len(opaque) + w - 1) // w
    sample = Image.new("RGB", (w,h))
    sample.putdata(opaque + [opaque[-1]] * (w*h-len(opaque)))
    pal = sample.quantize(colors=colors, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    result = []
    for im in frames:
        alpha = im.getchannel("A")
        q = im.convert("RGB").quantize(palette=pal, dither=Image.Dither.NONE).convert("RGBA")
        q.putalpha(alpha)
        result.append(clear_hidden_rgb(q))
    return result


def transparent_gap_cut(projection, expected, radius):
    """Move a nominal grid cut only to a nearby genuinely transparent gutter.

    Cuts remain within a small fraction of one cell, so this cannot jump to the
    next pose. Requiring a blank column/row on both sides also distinguishes a
    safely cropped accessory from one ending exactly at the nominal grid edge.
    """
    candidates = [cut for cut in range(max(1,expected-radius),min(len(projection)-1,expected+radius)+1)
                  if projection[cut-1] == 0 and projection[cut] == 0]
    return min(candidates,key=lambda cut:(abs(cut-expected),cut)) if candidates else expected


def authored_grid_cuts(source):
    alpha = source.getchannel("A")
    # One full-width horizontal gutter partitions each direction row. Within
    # that row, columns can have independent gutters around outstretched props.
    horizontal = [sum(alpha.crop((0,y,source.width,y+1)).getdata()) for y in range(source.height)]
    rows = [0] + [transparent_gap_cut(horizontal,round(i*source.height/8),round(source.height/8*.22))
                  for i in range(1,8)] + [source.height]
    cols = []
    for row in range(8):
        band = alpha.crop((0,rows[row],source.width,rows[row+1]))
        vertical = [sum(band.crop((x,0,x+1,band.height)).getdata()) for x in range(source.width)]
        cols.append([0] + [transparent_gap_cut(vertical,round(i*source.width/8),round(source.width/8*.22))
                          for i in range(1,8)] + [source.width])
    return rows,cols


def split_source(spec):
    source = Image.open(spec["source"]).convert("RGBA")
    threshold = spec.get("alpha_threshold", 192)
    source = hard_alpha(source, threshold)
    rows,columns = authored_grid_cuts(source)
    cells, geometry = [], []
    for row in range(8):
        for col in range(8):
            bounds = (columns[row][col], rows[row],columns[row][col+1],rows[row+1])
            cell = source.crop(bounds)
            box = cell.getbbox()
            if not box:
                raise ValueError(f"{spec['key']}: empty source cell {row},{col}")
            geometry.append({"row": row, "column": col, "cell": list(bounds), "opaqueBounds": list(box),
                             "touchesSourceCell": box[0] == 0 or box[1] == 0 or box[2] == cell.width or box[3] == cell.height})
            cells.append(cell.crop(box))
    # ONE scale for this character, with stable baseline and central ground contact.
    max_w = max(im.width for im in cells)
    max_h = max(im.height for im in cells)
    scale = min(36/max_w, 34/max_h)
    native = []
    for cell in cells:
        w = max(1, round(cell.width*scale))
        h = max(1, round(cell.height*scale))
        small = cell.resize((w,h), Image.Resampling.NEAREST)
        im = Image.new("RGBA", (40,40))
        im.alpha_composite(small, (20-w//2,36-h))
        native.append(im)
    native = shared_palette(native, spec.get("colors",32))
    return native, {"sourceSize": list(source.size), "scale": scale, "maxOpaqueSize": [max_w,max_h],
                    "directionRowCuts":rows,"poseColumnCutsByRow":columns,"cells": geometry}


def build_generated(spec):
    native, geometry = split_source(spec)
    frames = OrderedDict()
    for anim, cols in COLS.items():
        frames[anim] = {d: [native[row*8+c].copy() for c in cols] for row,d in enumerate(DIRS)}
    return frames, NPC.copy(), geometry


def build_existing(spec):
    image = Image.open(spec["source"]).convert("RGBA")
    if image.width % 40 or image.height % 40:
        raise ValueError(f"{spec['key']}: existing sheet dimensions are not multiples of 40")
    defaults = SBRIM if spec["key"] in ("sbrimbrulon", "sbrimbrulonKnight") else NPC
    defs = normalize_animations(spec.get("animations", defaults))
    tired = Image.open(spec["tired_source"]).convert("RGBA") if spec.get("tired_source") else None
    frames = OrderedDict()
    row = 0
    for anim, definition in defs.items():
        sheet = tired if anim == "tired" and tired else image
        start = 0 if sheet is tired else row
        if (start+8)*40 > sheet.height:
            raise ValueError(f"{spec['key']}: {anim} rows exceed source sheet")
        frames[anim] = {d: [clear_hidden_rgb(hard_alpha(sheet.crop((f*40,(start+di)*40,(f+1)*40,(start+di+1)*40)),
                                                     spec.get("alpha_threshold",128)))
                            for f in range(definition["frames"])] for di,d in enumerate(DIRS)}
        if sheet is not tired:
            row += 8
    if spec.get("quantize_existing", True):
        ordered = [(anim,d,f) for anim,by_dir in frames.items() for d,poses in by_dir.items() for f in range(len(poses))]
        reduced = shared_palette([frames[a][d][f] for a,d,f in ordered],spec.get("colors",32))
        for (a,d,f),im in zip(ordered,reduced):
            frames[a][d][f] = im
    return frames, defs, {"sourceSize": list(image.size), "retainedExistingPoses": True}


def checker(w,h):
    im=Image.new("RGB",(w,h),(235,235,230)); d=ImageDraw.Draw(im)
    for y in range(0,h,12):
        for x in range(0,w,12):
            if ((x//12)+(y//12))%2:
                d.rectangle((x,y,x+11,y+11),fill=(216,221,216))
    return im


def preview_frame(frames, defs, label, time=0, fixed_first=False):
    names=list(frames)
    cell=88; left=112; top=52
    canvas=checker(left+len(DIRS)*cell, top+len(names)*cell)
    draw=ImageDraw.Draw(canvas)
    draw.rectangle((0,0,canvas.width-1,30),fill=(15,39,42))
    draw.text((12,6),label,fill=(255,247,218),font=font(17))
    for i,d in enumerate(DIRS):
        draw.text((left+i*cell+32,34),d,fill=(15,39,42),font=font(13))
    for ai,anim in enumerate(names):
        definition=defs[anim]
        index=0 if fixed_first else frame_at(definition,time)
        draw.rectangle((0,top+ai*cell,left-3,top+(ai+1)*cell-1),fill=(245,242,228))
        draw.text((10,top+ai*cell+25),anim,fill=(15,39,42),font=font(14))
        for di,d in enumerate(DIRS):
            im=frames[anim][d][index].resize((80,80),Image.Resampling.NEAREST)
            canvas.paste(im,(left+di*cell+4,top+ai*cell+2),im)
    return canvas


def frame_at(definition,time):
    # Preview deliberately repeats one-shots so they remain reviewable.
    holds=definition.get("frameDurationsMs")
    if holds:
        t=(time*1000)%sum(holds)
        for index,hold in enumerate(holds):
            if t < hold:
                return index
            t-=hold
        return len(holds)-1
    return int(time*definition["fps"])%definition["frames"]


def save_gifs(out,frames,defs,label):
    # Cross-action overview keeps every authored direction visible at native integer zoom.
    overviews=[preview_frame(frames,defs,label,f/10) for f in range(20)]
    overviews[0].save(out/"animations.gif",save_all=True,append_images=overviews[1:],duration=100,loop=0,optimize=False)
    clips=out/"clips"; clips.mkdir(exist_ok=True)
    for anim,by_dir in frames.items():
        poses=[]
        for f in range(defs[anim]["frames"]):
            canvas=checker(8*120,140)
            draw=ImageDraw.Draw(canvas)
            for di,d in enumerate(DIRS):
                draw.text((di*120+50,4),d,fill=(15,39,42),font=font(12))
                im=by_dir[d][f].resize((120,120),Image.Resampling.NEAREST)
                canvas.paste(im,(di*120,20),im)
            poses.append(canvas)
        durations=defs[anim].get("frameDurationsMs") or round(1000/defs[anim]["fps"])
        poses[0].save(clips/f"{anim}.gif",save_all=True,append_images=poses[1:],duration=durations,loop=0,optimize=False)


def validate(spec,frames,defs):
    errors=[]; warnings=[]; colors=set(); report={}
    for anim,by_dir in frames.items():
        report[anim]={}
        for d,poses in by_dir.items():
            hashes=[]
            for f,im in enumerate(poses):
                box=im.getbbox()
                if not box:
                    errors.append(f"{anim}/{d}/{f}: empty")
                    continue
                if im.size != (40,40):
                    errors.append(f"{anim}/{d}/{f}: size {im.size}")
                if box[0] <= 0 or box[1] <= 0 or box[2] >= 40 or box[3] >= 40:
                    warnings.append(f"{anim}/{d}/{f}: touches frame boundary")
                alpha=set(im.getchannel("A").getdata())
                if not alpha <= {0,255}:
                    errors.append(f"{anim}/{d}/{f}: soft alpha")
                colors.update((r,g,b) for r,g,b,a in im.getdata() if a)
                hashes.append(digest(im))
            report[anim][d]={"frames":len(poses),"uniqueFrames":len(set(hashes))}
            if anim in ("walk","run") and len(set(hashes)) < 2:
                errors.append(f"{anim}/{d}: movement has fewer than two distinct poses")
    if (spec.get("mode","generated") == "generated" or spec.get("quantize_existing",True)) and len(colors) > spec.get("colors",32):
        errors.append(f"opaque palette has {len(colors)} colors")
    if spec["key"] in ("sbrimbrulon","sbrimbrulonKnight"):
        for anim,by_dir in frames.items():
            for side,diag in [("E","NE"),("E","SE"),("W","NW"),("W","SW")]:
                if all(digest(a)==digest(b) for a,b in zip(by_dir[side],by_dir[diag])):
                    errors.append(f"{anim}: {diag} repeats {side}")
    return {"errors":errors,"warnings":warnings,"opaquePaletteColors":len(colors),"animations":report,
            "hardAlpha":not any("alpha" in x for x in errors),"passed":not errors}


def process(spec,root,no_gifs=False):
    key=spec["key"]; label=spec.get("label",key)
    if not key or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in key):
        raise ValueError(f"unsafe character key {key!r}")
    if spec.get("mode","generated") == "existing":
        frames,defs,source_info=build_existing(spec)
    else:
        frames,defs,source_info=build_generated(spec)
    out=root/"characters"/key; native=out/"frames"
    native.mkdir(parents=True,exist_ok=True)
    public=root/"public"/"sprites"/"pixel-cast"; public.mkdir(parents=True,exist_ok=True)
    separate_tired=bool(spec.get("tired_source"))
    main_names=[a for a in frames if not (a == "tired" and separate_tired)]
    width=max(defs[a]["frames"] for a in main_names)*40
    atlas=Image.new("RGBA",(width,len(main_names)*8*40))
    metadata={"key":key,"label":label,"frameWidth":40,"frameHeight":40,"anchor":[20,36],"directions":DIRS,
              "sheet":f"sprites/pixel-cast/{key}.png","animations":{},"source":Path(spec["source"]).name,
              "sourceMode":spec.get("mode","generated"),"notes":spec.get("notes","")}
    if spec.get("mode","generated") == "existing":
        adaptation = "Existing authored poses, geometry and timing retained; alpha hardened to 0/255."
        if spec.get("quantize_existing",True):
            adaptation += f" One shared palette limited to {spec.get('colors',32)} opaque colours across all actions and directions."
    else:
        adaptation = "Authored 8x8 pose grid cropped and packed; one common scale and a 36px ground baseline. Run reuses the four walk poses with faster timing. Bark pairs idle with the authored role gesture; hurt pairs the authored recoil with idle."
    metadata["notes"] = " ".join(part for part in [metadata["notes"],adaptation] if part)
    for anim,by_dir in frames.items():
        is_tired=anim == "tired" and separate_tired
        sheet=Image.new("RGBA",(defs[anim]["frames"]*40,320)) if is_tired else atlas
        base_row=0 if is_tired else main_names.index(anim)*8
        metadata["animations"][anim]={**defs[anim],"row":base_row,
            "sheet":f"sprites/pixel-cast/{key}-tired.png" if is_tired else metadata["sheet"]}
        for di,d in enumerate(DIRS):
            for fi,im in enumerate(by_dir[d]):
                im.save(native/f"{anim}_{d}_{fi:02}.png")
                sheet.paste(im,(fi*40,(base_row+di)*40))
        if is_tired:
            sheet.save(public/f"{key}-tired.png")
    atlas.save(public/f"{key}.png")
    portrait=frames["idle"]["S"][0].resize((160,160),Image.Resampling.NEAREST)
    portrait.save(out/"portrait.png")
    preview_frame(frames,defs,label,fixed_first=True).save(out/"preview.png")
    if not no_gifs:
        save_gifs(out,frames,defs,label)
    qa=validate(spec,frames,defs)
    qa["atlasSize"]=list(atlas.size)
    qa["sourceSegmentation"]=source_info
    qa["sourceBoundaryTouches"]=sum(c["touchesSourceCell"] for c in source_info.get("cells",[]))
    if qa["sourceBoundaryTouches"]:
        qa["warnings"].append("Some authored source poses touch their grid cell; review source geometry.")
    (out/"animations.json").write_text(json.dumps(metadata,indent=2)+"\n")
    (out/"qa.json").write_text(json.dumps(qa,indent=2)+"\n")
    return metadata,qa


def gallery(root,items):
    cards=[]
    for meta in items:
        key=meta["key"]
        controls="".join(f'<option value="{html.escape(a)}">{html.escape(a)}</option>' for a in meta["animations"])
        cards.append(f'<article data-key="{key}"><h2>{html.escape(meta["label"])}</h2><canvas width="320" height="320"></canvas>'
                     f'<label>Action <select>{controls}</select></label><label>Direction <select class="direction">'
                     +"".join(f'<option value="{d}" {"selected" if d=="S" else ""}>{d}</option>' for d in DIRS)
                     +f'</select></label><p><a href="characters/{key}/animations.gif">All animations</a> · '
                     f'<a href="characters/{key}/preview.png">Direction sheet</a></p></article>')
    data=json.dumps({m["key"]:m for m in items})
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Supervillained · Pixel Cast</title><style>
*{box-sizing:border-box}body{margin:0;padding:24px;background:#10272a;color:#f7eed7;font:15px system-ui,sans-serif}h1{margin:0 0 8px}header p{max-width:900px;color:#b8ccc3}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:20px}article{background:#1a383b;border:1px solid #35565a;padding:14px;border-radius:10px}h2{font-size:18px;margin:0 0 8px}canvas{width:100%;height:auto;image-rendering:pixelated;background:repeating-conic-gradient(#d8ddd8 0% 25%,#ebece6 0% 50%) 50%/24px 24px}label{display:inline-block;margin:10px 10px 0 0}select{padding:5px;background:#10272a;color:#f7eed7;border:1px solid #557677}a{color:#f4b783}p{font-size:13px}.toolbar{margin:15px 0}button{padding:8px;background:#ecb06a;color:#10272a;border:0;border-radius:5px}
</style><header><h1>SUPERVILLAINED · Pixel Cast</h1><p>Authored poses assembled as native 40×40 sprites. Choose an action and camera direction for each character. Runs locally, without a server. NPC runs reuse their walk poses at faster timing. Gesture clips use the runtime's “bark” slot.</p><div class="toolbar"><button id="pause">Pause all</button></div></header><main>''' + "".join(cards) + '''</main><script>
const cast=DATA;let paused=false,pausedAt=0,offset=0;const start=performance.now();
document.querySelector('#pause').onclick=()=>{paused=!paused;if(paused)pausedAt=performance.now();else offset+=performance.now()-pausedAt;document.querySelector('#pause').textContent=paused?'Play all':'Pause all'};
for(const article of document.querySelectorAll('article')){const m=cast[article.dataset.key],canvas=article.querySelector('canvas'),ctx=canvas.getContext('2d'),action=article.querySelector('select'),direction=article.querySelector('.direction'),images={};ctx.imageSmoothingEnabled=false;
 for(const a of Object.values(m.animations)){if(!images[a.sheet]){let im=new Image();im.src='public/'+a.sheet;images[a.sheet]=im;}}
 const draw=now=>{const a=m.animations[action.value],t=((paused?pausedAt:now)-start-offset),d=m.directions.indexOf(direction.value);let f=0;if(a.frameDurationsMs){let elapsed=t%a.frameDurationsMs.reduce((x,y)=>x+y,0);for(let i=0;i<a.frames;i++){f=i;if(elapsed<a.frameDurationsMs[i])break;elapsed-=a.frameDurationsMs[i];}}else f=Math.floor(t/1000*a.fps)%a.frames;
 ctx.clearRect(0,0,320,320);const image=images[a.sheet];if(image.complete&&image.naturalWidth)ctx.drawImage(image,f*40,(a.row+d)*40,40,40,0,0,320,320);requestAnimationFrame(draw)};requestAnimationFrame(draw);}
</script></html>'''
    (root/"preview.html").write_text(page.replace("DATA",data))


def wrap_label(draw,text,width):
    lines=[]; current=""
    for word in text.split():
        trial=(current+" "+word).strip()
        if current and draw.textbbox((0,0),trial,font=font(14))[2] > width:
            lines.append(current);current=word
        else:
            current=trial
    if current:
        lines.append(current)
    return lines


def combined_overviews(root,items,no_gifs=False):
    """Contact views of actual runtime frames, without redrawing or transforming poses."""
    columns=5; cw=210; ch=216; top=66
    rows=(len(items)+columns-1)//columns
    size=(columns*cw,top+rows*ch)
    cached={}
    for meta in items:
        cached[meta["key"]]={}
        for anim in ("idle","walk"):
            definition=meta["animations"].get(anim)
            if not definition:
                continue
            sheet=Image.open(root/"public"/definition["sheet"]).convert("RGBA")
            row=definition["row"]+meta["directions"].index("S")
            cached[meta["key"]][anim]=[sheet.crop((f*40,row*40,(f+1)*40,(row+1)*40)).resize((160,160),Image.Resampling.NEAREST)
                                      for f in range(definition["frames"])]

    def make(action,time=0):
        board=checker(*size); draw=ImageDraw.Draw(board)
        draw.rectangle((0,0,size[0]-1,top-1),fill=(15,39,42))
        draw.text((18,10),"SUPERVILLAINED · COMPLETE PIXEL CAST",fill=(255,247,218),font=font(22))
        draw.text((18,39),"FRONT / IDLE" if action == "idle" else "FRONT / WALK · ALL CHARACTERS",fill=(193,215,205),font=font(13))
        for i,meta in enumerate(items):
            x=(i%columns)*cw;y=top+(i//columns)*ch
            poses=cached[meta["key"]].get(action) or cached[meta["key"]]["idle"]
            definition=meta["animations"].get(action,meta["animations"]["idle"])
            index=0 if action == "idle" else frame_at(definition,time)
            im=poses[index]
            board.paste(im,(x+(cw-160)//2,y+4),im)
            lines=wrap_label(draw,meta["label"],cw-16)
            for li,line in enumerate(lines):
                length=draw.textbbox((0,0),line,font=font(14))[2]
                draw.text((x+(cw-length)//2,y+169+li*17),line,fill=(15,39,42),font=font(14))
        return board

    make("idle").save(root/"all-characters-front.png")
    if not no_gifs:
        frames=[make("walk",f/10) for f in range(24)]
        frames[0].save(root/"all-characters-walk.gif",save_all=True,append_images=frames[1:],duration=100,loop=0,optimize=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",required=True,type=Path)
    parser.add_argument("--out",required=True,type=Path)
    parser.add_argument("--no-gifs",action="store_true")
    parser.add_argument("--only",help="Comma-separated character keys")
    args=parser.parse_args()
    config=json.loads(args.config.read_text())
    specs=config["characters"]
    if args.only:
        only=set(args.only.split(",")); specs=[s for s in specs if s["key"] in only]
    args.out.mkdir(parents=True,exist_ok=True)
    metadata=[];qa_all={}
    for spec in specs:
        meta,qa=process(spec,args.out,args.no_gifs)
        metadata.append(meta);qa_all[spec["key"]]=qa
        print(json.dumps({"key":spec["key"],"passed":qa["passed"],"palette":qa["opaquePaletteColors"],
                          "errors":qa["errors"],"warnings":len(qa["warnings"]),"atlas":qa["atlasSize"]}),flush=True)
    (args.out/"cast-manifest.json").write_text(json.dumps({"characters":metadata},indent=2)+"\n")
    summary={"passed":all(q["passed"] for q in qa_all.values()),"characters":{k:{x:q[x] for x in ["passed","errors","warnings","opaquePaletteColors","atlasSize","sourceBoundaryTouches"]} for k,q in qa_all.items()}}
    (args.out/"qa-summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    gallery(args.out,metadata)
    combined_overviews(args.out,metadata,args.no_gifs)
    if not summary["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
