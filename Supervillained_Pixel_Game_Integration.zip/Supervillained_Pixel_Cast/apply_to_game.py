#!/usr/bin/env python3
"""Install the reviewed pixel-cast patch and native PNGs without replacing local edits."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys

LEGACY = (
    'bagnaskiz.png', 'confusione.png', 'jack.png', 'watson.png',
    'sbrimbrulon.png', 'sbrimbrulon-tired.png',
    'sbrimbrulonKnight.png', 'sbrimbrulonKnight-tired.png',
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(repo: Path, *args: str, check: bool = True):
    result = subprocess.run(['git', '-C', str(repo), *args], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or 'git command failed')
    return result


def safe_path(root: Path, name: str) -> Path:
    rel = PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts:
        raise RuntimeError(f'Unsafe package path: {name}')
    target = root.joinpath(*rel.parts)
    for part in [target, *target.parents]:
        if part == root.parent:
            break
        if part.is_symlink():
            raise RuntimeError(f'Refusing a symlink in install path: {part}')
    return target


def changed(repo: Path, names: list[str]) -> list[str]:
    if not names:
        return []
    return git(repo, 'diff', '--name-only', 'HEAD', '--', *names).stdout.splitlines()


def archive_target(directory: Path, source: Path) -> tuple[Path, bool]:
    target = directory / source.name
    if not target.exists():
        return target, True
    if target.is_symlink():
        raise RuntimeError(f'Refusing archive symlink: {target}')
    digest = sha(source)
    if target.is_file() and sha(target) == digest:
        return target, False
    suffix = 0
    while True:
        name = f'{source.stem}-{digest[:12]}' + (f'-{suffix}' if suffix else '') + source.suffix
        target = directory / name
        if not target.exists():
            return target, True
        if target.is_file() and not target.is_symlink() and sha(target) == digest:
            return target, False
        suffix += 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path, help='Path to the game checkout')
    parser.add_argument('--dry-run', action='store_true', help='Check everything without changing the checkout')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    manifest = json.loads((package / 'integration-manifest.json').read_text())
    repo = args.repo.expanduser().resolve()
    if not repo.is_dir():
        raise RuntimeError(f'Checkout does not exist: {repo}')
    top = Path(git(repo, 'rev-parse', '--show-toplevel').stdout.strip()).resolve()
    if top != repo:
        raise RuntimeError(f'--repo must name the checkout root: {top}')
    patch = package / 'INTEGRATION.patch'
    if sha(patch) != manifest['patch_sha256']:
        raise RuntimeError('INTEGRATION.patch does not match the delivered manifest')
    # Git checks the complete patch before the installer writes, copies or moves anything.
    git(repo, 'apply', '--check', '--whitespace=nowarn', str(patch))
    paths = manifest['code_paths']
    if any(p.startswith('public/') or p.startswith('art-archive/') for p in paths):
        raise RuntimeError('Code patch unexpectedly modifies artwork')
    dirty = changed(repo, paths)
    if dirty:
        raise RuntimeError('Local edits in files changed by the patch; use a clean checkout or worktree:\n  ' + '\n  '.join(dirty))
    assets = []
    for item in manifest['assets']:
        name = item['path']
        if not name.startswith('public/sprites/pixel-cast/') or 'zampano' in PurePosixPath(name).name.lower():
            raise RuntimeError(f'Unexpected asset destination: {name}')
        source = safe_path(package, name)
        target = safe_path(repo, name)
        if not source.is_file() or sha(source) != item['sha256']:
            raise RuntimeError(f'Delivered asset missing or changed: {name}')
        if target.exists() and (not target.is_file() or sha(target) != item['sha256']):
            raise RuntimeError(f'Existing asset differs; refusing to overwrite: {name}')
        assets.append((source, target, not target.exists()))
    archive_dir = safe_path(repo, 'art-archive/pixel-cast-2026-11-19')
    legacy = [repo / 'public' / 'sprites' / name for name in LEGACY]
    legacy = [p for p in legacy if p.exists()]
    for old in legacy:
        safe_path(repo, old.relative_to(repo).as_posix())
        if not old.is_file():
            raise RuntimeError(f'Legacy asset is not a regular file: {old}')
    legacy_dirty = changed(repo, [p.relative_to(repo).as_posix() for p in legacy])
    if legacy_dirty:
        raise RuntimeError('Modified legacy artwork would be archived; preserve your edits first:\n  ' + '\n  '.join(legacy_dirty))
    archives = [(old, *archive_target(archive_dir, old)) for old in legacy]
    # Snapshot only for an integrity assertion; the installer never writes these files.
    zampano = {p: sha(p) for p in (repo / 'public' / 'sprites').glob('zampano*.png')}
    head = git(repo, 'rev-parse', 'HEAD').stdout.strip()
    print(f'Prepared against {manifest["base_commit"]}; target checkout {head}.')
    print(f'Patch applies cleanly. {len(assets)} native PNGs; {len(archives)} old PNGs to archive.')
    if args.dry_run:
        print('Dry run passed. No files changed.')
        return 0
    applied = False
    copied = []
    moved = []
    try:
        git(repo, 'apply', '--whitespace=nowarn', str(patch))
        applied = True
        for old, archived, create in archives:
            archive_dir.mkdir(parents=True, exist_ok=True)
            if create:
                shutil.copy2(old, archived)
                if sha(old) != sha(archived):
                    raise RuntimeError(f'Archive verification failed: {old.name}')
            old.unlink()
            moved.append((old, archived, create))
        for source, target, create in assets:
            if create:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                copied.append(target)
            if sha(target) != sha(source):
                raise RuntimeError(f'Installed image verification failed: {target.name}')
        if any(not p.exists() or sha(p) != digest for p, digest in zampano.items()):
            raise RuntimeError('Zampano integrity check failed')
    except Exception:
        for target in reversed(copied):
            target.unlink(missing_ok=True)
        for old, archived, created in reversed(moved):
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(archived, old)
            if created:
                archived.unlink(missing_ok=True)
        if applied:
            undo = git(repo, 'apply', '--reverse', '--whitespace=nowarn', str(patch), check=False)
            if undo.returncode:
                print('Automatic code rollback could not finish; inspect git diff before continuing.', file=sys.stderr)
        raise
    print('Installed pixel cast. Zampano artwork is unchanged. No commit or push was made.')
    print('Validate in your checkout with: npm test && npm run build')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, RuntimeError) as exc:
        print(f'Install stopped: {exc}', file=sys.stderr)
        raise SystemExit(1)
