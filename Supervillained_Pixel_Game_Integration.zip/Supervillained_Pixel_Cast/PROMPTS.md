# Pixel cast source prompts

The new pose grids were generated from the supplied character references using this shared specification. Runtime atlases are cropped, reduced to a shared palette per character, and packed without drawing additional poses.

## Shared grid specification

Convert the supplied character reference into a PRODUCTION PIXEL-ART ANIMATION SPRITE SHEET for the SUPERVILLAINED isometric game. Preserve the reference's individual face, costume, silhouette, bold dark outline and strong colours, translating into crisp chunky 16-bit pixel clusters and a limited approximately 24-colour palette; NO smooth vector contours, NO photorealism, NO painted shading, NO antialiasing. SQUARE 1024x1024 image, EXACTLY EIGHT COLUMNS AND EIGHT ROWS of equal invisible 128x128 cells, 64 distinct complete full-body sprites. Genuine transparent background, no labels, text, numbers, outlines around cells, scenery, floor, ground shadows, or decorative borders. Each sprite centered with feet on the same baseline in its cell, consistent body size and generous internal padding; accessories fully within cell, no overlap.
Rows top to bottom are eight facing directions in this EXACT order: N (back to viewer), NE (rear three-quarter facing up-right), E (right profile), SE (front three-quarter facing down-right), S (front facing viewer), SW (front three-quarter facing down-left), W (left profile), NW (rear three-quarter facing up-left). Front, back, profiles and diagonal views must actually differ; don't repeat the front view.
Columns left to right: 1 idle neutral, 2 subtly breathing idle with small visible garment change, 3 walking left-leg forward contact, 4 walking passing step, 5 walking right-leg forward contact, 6 opposite passing step, 7 the described role-specific speaking/working gesture, 8 brief recoiling/stumbling reaction. For humans preserve natural two legs and two arms; animate opposing arms/legs with actual contact and passing poses, not a whole-body translation. The four walk columns must have distinct leg placements. Repeat the role gesture and recoil in all eight directions consistently. Keep the comic oversized head and compact body.

## Character instructions

Santina: white female Maltese, long dense fringe completely covering both eyes, dusty rose bow, small knowing smile; ball kept separate. Questioning gesture and recoil. Four-legged walking.

### The Professor

HUMAN modern medieval historian: wild grey hair, round wire spectacles, grey stubble, olive corduroy coat and teal waistcoat, cream shirt, brown trousers/shoes, old book and lecture notes. COLUMN7 role action: raise index finger and open mouth, lecturing with book tucked in other arm. Keep book and notes during walk. Do not make him an animal or medieval monk.

### The Doge

NATURAL FOUR-LEGGED ELDERLY DOG, cream/russet long-eared Basset-like hound, cloudy blind eyes, soft big ivory cotton cap with small red cross, crimson mantle gold trim. Stand on four paws in locomotion frames rather than human body; old dignified dog. COLUMN7 role action: authoritative open-mouth rebuke, raised forepaw while seated upright. Cap and mantle visible in each direction; no human hands.

### Niketas Choniates

HUMAN Byzantine historian with greying wavy dark hair, full beard, exhausted ironic eyes, plum-and-gold robe, dark teal cloak, parchment and reed pen. COLUMN7 role action: look down and write on parchment with reed pen. Keep scroll and pen through poses. This is a specific human scholar, not generic Greek or animal.

### Fulk of Neuilly

HUMAN gaunt crusade preacher, dark stubble, clerical tonsure, intense eyes, simple oatmeal robe and brown shoulder cape, rope belt, simple shoes, wooden cross. COLUMN7 role action: lift cross and raise preaching index finger, mouth open emphatically.

### The Clerk

HUMAN anxious clean-shaven young clerk, black bowl-cut hair, tiny brown cap, huge nervous eyes, moss-green tunic, parchment register and quill, little inkpot at belt. COLUMN7: checking the long scroll and writing with quill. No readable writing. Parchment must stay in its own cell; don't drag into next row.

### The Abbot of Vaux

HUMAN broad elderly abbot, large round clean-shaven face, grey tonsure, heavy eyebrows, deeply unimpressed expression, unbleached light grey Cistercian robe and dark grey shoulder cowl, ropebelt. Holds folded parchment with bright red wax seal. COLUMN7: thrust letter out and lift other hand palm-forward in refusal. No bishop mitre.

### The Envoy

HUMAN compact slim bearded diplomat, arched brows, low burgundy cap, dark blue cloak over ochre tunic, leather satchel, brown leggings and boots. Holds sealed parchment. COLUMN7: present message with cautious open-mouth speech, free hand open. Distinct from priest or bishop.

### The Bishop

HUMAN older stern bishop with large angular clean-shaven face, grey hair and brows, ivory/gold mitre, burgundy robe, ivory/gold vestment, gold-curved crozier and small closed book. COLUMN7: raise hand over book administering oath, crozier held against other shoulder. Entire tall mitre and crozier must fit within each individual cell.

### The Cook

HUMAN squat chubby camp cook, rosy face, bulbous nose, rust-red moustache, missing tooth, flat soft linen cap, rolled cream sleeves, olive tunic, stained apron, brown leggings/shoes. Small black pot and wooden ladle. COLUMN7: stir pot emphatically with ladle and smile. Low medieval cap, not modern tall toque.

### The Sailmaker

HUMAN older wiry tanned maritime craftsman, grey beard, wry eyes, ochre low cap, teal tunic, rust shoulder cape, ropebelt, patched brown trousers, rolled cream stitched canvas and wooden sailmaker tool. COLUMN7: lean toward canvas and stitch / pull thread through it. All cloth/tool within cell. No weapons or modern sewing machine.

### Young Alexios

HUMAN youthful slim Byzantine prince, olive skin, short dark curls, clean-shaven, large anxious hopeful eyes, narrow gold circlet, purple gold-edged tunic, crimson travelling cloak, dark leggings, brown boots, rolled parchment. Column7: pleading palm-up bargaining gesture and nervous smile, parchment in other hand.

### Woman of Niketas's Household

HUMAN adult Byzantine woman, olive skin, large wary dark eyes, dark wavy hair under cream veil, teal long dress and brick-red overgarment gold edging, plain brown shoes, small bronze unlit oil lamp in hands. Column7: protectively draw lamp toward chest and look anxiously outward. Walking keeps lamp secure, visible stepping feet beneath dress.

### The Knight

HUMAN tired blond moustached crusader knight, open conical iron nasal helmet and chainmail coif, grey mail, worn ivory surcoat with small sewn red cloth cross at left shoulder, brown belt/boots, plain weathered blue shield, sheathed sword at hip. Column7: draw sword in controlled attack wind-up with shield raised. Entire sword remains inside cell, no blood. Walking sword sheathed.

### The Pilgrim

HUMAN poor thin elderly pilgrim, sparse grey beard, big hopeful eyes, broad soft brown hat, oatmeal travel cloak with rough red cloth cross, faded green tunic, patched brown hose, leather shoes, wooden staff, bundle on shoulder, clay flask. Column7: shiver and draw cloak around shoulders. Complete hat and staff inside cell.

### The Venetian

HUMAN compact clever Venetian merchant, tan face, neat dark moustache/pointed beard, low burgundy cap, rust-orange tunic, short teal cloak, coinpouch, dark hose, brown shoes, bundle rolled coloured cloth and small leather book. Column7: openhand bargaining gesture while holding goods. No writing.

### The Greek Citizen

HUMAN sturdy elderly Greek market woman, olive skin, wry suspicious eyes, grey hair in burgundy kerchief, olive long dress, plum sleeveless overgarment, cream sleeves, brown shoes, wickerbasket with bread at hip. Column7: questioning palm-up gesture with speaking mouth. Basket carried throughout walking.

### Confusione

NATURAL FOUR-LEGGED scarred ginger tabby fighting cat, big square head, half-lidded unimpressed eyes, torn triangular ears, cream muzzle/chest, dark orange stripes, curled upright tail. No clothes. Stand on four paws with actual opposing paw phases in four walk columns. Column7 lift a front paw for sharp slap and open mouth; column8 low recoil with flattened ears. Feline not human anatomy.

### Jack

NATURAL FOUR-LEGGED tiny black Chihuahua, huge pointed pink-lined ears, enormous bulging bloodshot eyes with yellow irises, white muzzle/chest/pawtips, manic open grin and fangs, curled black tail. No clothes. Column7 mocking bark with head forward and mouth wide; column8 frightened recoil, ears back. All ears/tail entirely inside cell.

### Watson

NATURAL FOUR-LEGGED scruffy white-and-tan Jack Russell, drooping stoned pink-rimmed eyes, floppy tan ears, backward teal-and-red cap, spiked black collar, short brown cigar, lolling tongue, fluffy cream chest. Column7 leanforward and reach frontpaw as if pulling bowl; column8 surprised recoil. No separate bowl/flies/smoke. Keep cap/cigar during all poses.

### Bagnaskiz — Marshal

NATURAL FOUR-LEGGED stocky fawn PUG BAGNASKIZ as FRENCH MARSHAL VILLEHARDOUIN. Enormous yellow eyes, furrowed brow, black ears and flat black muzzle, sharp toothy grin, curled tail. Western crusader mailcoat and short navy mantle with ochre trim and simple small red sewn cross on back, plain conical steel nasal helmet WITHOUT plume. No imperialcrown, no Byzantine scales. Column7 imperiously raise forepaw and barkorders, column8 duckhead/recoil.

### The Varangian Guard

Create a NEW HUMAN BYZANTINE VARANGIAN AXE GUARD in the same graphic/pixel visual family, not a Latin crusader. Broad muscular squat adult man, huge square head, thick dark brown beard and stern heavy brows, conical steel helmet, dark iron mail with muted crimson Byzantine tunic, wide leather belt, tall plain brown boots, holds long-handled DOUBLE-HANDED BROAD AXE angled close to body. No Latin cross or crusader surcoat, no horns. Column7: controlled axe attack wind-up with axe raised close alongside head, entire handle and blade INSIDE cell. Column8 stagger/recoil. Allordinarywalkframes axe carried along one shoulder. Actualtwolegwalkingsteps. EXACTLY EIGHT COLUMNS perrow, NOT7; same regular spacing as SECOND layoutreference, not its dog identity.

### The Marquis — Boniface

Create a NEW HUMAN older Latin crusade noble BONIFACE THE MARQUIS, not youngAlexios. Broad compact matureadult with oversized long face, tawny/greyshortwavyhair, pointedgreymoustacheandbeard, worriedheavybrowndroopingeyes, scarletlongmantle with simpleochregoldtrim over mutedbluecivilian tunic and greychainmailsleeves, plainbrownboots andleatherbelt. Uncrowned, noByzantinecirclet. Column7: emotional pleadinggesture with handoverchest, mouthopentalking; column8 briefkneeling/weepduckedhead. Standardidleandwalkupright. EXACTLY EIGHT sprites across EACH row, NOT7; same regular spacing as SECOND reference layout, notdogidentity.

Sbrimbrulon normal/knight and Bagnaskiz normal/Byzantine retain their earlier authored poses and frame holds; the delivered native copies use a shared maximum 32-colour palette and hard alpha. No Zampano artwork was generated or changed.

