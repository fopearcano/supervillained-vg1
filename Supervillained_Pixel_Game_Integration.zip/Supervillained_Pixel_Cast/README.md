# SUPERVILLAINED — Pixel Cast and Animation Delivery

Native transparent pixel sprites and animation files for every supplied character except Zampanò.
This delivery contains 27 character appearances, including the normal and
armoured forms of the two additional player-ready dogs, and separate French marshal and Byzantine
imperial appearances for Bagnaskiz. The Varangian guard and Marquis cover roles used by the game.

Prepared for `fopearcano/supervillained-vg1`, branch `claude/gallant-pascal-wjy5l2`,
commit `879ac0fdab999c8a10c676698d5d4c33e846e10a` (19 November 2026).

## Files

- **Supervillained_Pixel_Animals.zip**: animal cast, native individual frames, animation metadata,
  all-direction contact sheets, pixel portraits and animated overviews.
- **Supervillained_Pixel_Humans.zip**: human cast with the same editable assets and previews.
- **Supervillained_Pixel_Game_Integration.zip**: all native runtime PNGs, reviewed source patch,
  installer, source-file snapshots, complete cast metadata, QA results and offline animation viewer.

All three archives extract into the same `Supervillained_Pixel_Cast/` folder, so their contents
can be merged. The integration archive is sufficient to install and preview the game assets;
the other two add the individual frames, editable source grids and per-character animated WebP previews.

Open `preview.html` in a browser to choose each character's action and direction. It works offline.
`all-characters-front.png` shows the full cast, and `all-characters-walk.gif` previews their movement.

## Install into the game

Extract the integration archive outside your game checkout. From its extracted folder run:

```bash
python3 apply_to_game.py --repo /path/to/supervillained-vg1 --dry-run
python3 apply_to_game.py --repo /path/to/supervillained-vg1
```

The installer verifies the complete code patch and every image before changing the checkout.
It refuses local edits in patched files, modified legacy art and differing destination images.
A newer checkout is accepted only when the patch applies cleanly. Use a clean worktree if your
current files have changes. No commit, push or network operation is performed.

The eight replaced legacy PNGs are retained in
`art-archive/pixel-cast-2026-11-19/`, with collision-safe filenames. Zampanò's artwork is never
copied, moved or replaced. `INTEGRATION.patch` and `integration/source-files/` are also included
for code review or manual integration; compare changes rather than blindly copying source files.

After installing:

```bash
npm test
npm run build
npm run dev
```

Useful sprite viewer URLs are `?debug=sprites&char=santina`,
`?debug=sprites&char=sbrimbrulonKnight`, `?debug=sprites&char=bagnaskizEmperor`,
or any key listed in `cast-manifest.json`.

## Runtime format and actions

| Property | Value |
|---|---|
| Native character cell | 40 × 40 RGBA PNG |
| Ground anchor | (20, 36) |
| Direction row order | N, NE, E, SE, S, SW, W, NW |
| Ordinary NPC atlas | 160 × 1600 |
| Full dog atlas | 320 × 3520, plus 80 × 320 tired strip |
| Palette and alpha | At most 32 opaque colours per character; alpha 0 or 255 |

Each ordinary NPC supplies `idle` (2 frames), `walk` (4), `run` (4), `bark/gesture` (2),
and `hurt/recover` (2) in all eight directions. NPC running intentionally reuses its four walk
poses at faster timing. A human's `bark` slot is the authored speaking or working gesture.
The integration triggers gestures for stationary on-stage speakers when dialogue starts.

Sbrimbrulòn (normal and knight) and Bagnaskiz (normal and Byzantine armour) supply twelve actions:
`idle`, `walk`, `run`, `sniff`, `pee`, `poop`, `eat/drink`, `bark`, `fetch`, `hurt`, `sit`, `tired`.
Their existing authored poses, directions and timings are retained, with consistent palette and
hard-alpha normalization. Normal Bagnaskiz retains looping hurt during the Green Zone stun;
the imperial actor's hurt is a one-shot. The French marshal uses the ordinary five-action NPC set.

**Player-ready assets do not add new playable campaign sections.** The checked branch plays as
Zampanò. The player-skin APIs now also accept Sbrimbrulòn and Bagnaskiz for future authored levels;
no new character-switching story rules are inserted. Sword and shield remain the existing
combat overlays. All Zampanò art and animation timings are retained.

Niketas, the generic Greek citizen, the abbot, envoy and bishop have distinct identities.
The Professor has a matching 24 × 24 dialogue face; his existing pacing-legs view remains in use
under the desk, while a full-body character set is supplied for other uses.

## Editable sources

Each newly authored character includes `characters/<key>/source-grid.png`: an eight-by-eight
pose grid at the original source resolution and layout. Pose positions are retained; soft alpha
is hardened and colours are normalized to the same shared palette as the native atlas. This
keeps the editable grid consistent with the pixel-art deliverable. These are compact normalized
working sources, rather than the larger unnormalized generated illustrations.

Within each source grid, direction rows follow the runtime order. Columns are idle 0–1,
walk 0–3, role gesture and recoil. `animations.json` records the final atlas layout and timing.
Individual native frame PNGs are under each character's `frames/` folder. Animated overview
WebPs are previews; transparent PNGs are the runtime assets. Each WebP preserves the original
overview GIF's decoded frames and frame holds losslessly in a smaller file. `PROMPTS.md` records source guidance.

For a deterministic rebuild after extracting all three archives together (Pillow required):

```bash
python3 tools/build_pixel_cast.py --config source-config.json --out rebuilt
```

The source assembler crops and packs authored poses; it does not draw or invent character art.
For the retained dog libraries, the supplied native atlases are the rebuild inputs.

## Validation

- Production build and TypeScript check: **passed**.
- Unit tests: **196 passed** across 25 test files.
- Native frame validation: **4753 required frames checked**;
  no empty frames, wrong dimensions or soft alpha in the delivered runtime files.
- Zampanò artwork hashes match the checked base commit.
- Browser gameplay smoke test: **not run**. The environment blocked browser socket creation;
  no browser gameplay result is claimed. Run the game's smoke/playtest tools in your checkout.

Detailed results are in `game-validation.json`, `qa-summary.json` and each character's `qa.json`.
