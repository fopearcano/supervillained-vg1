# Claude Code prompt: apply the complete level, gameplay, and Color Ink update

Integrate the attached `Supervillained_Complete_Level_Gameplay_Color_Ink_Implementation.zip` into the current SUPERVILLAINED repository.

## Package layout

- `COMPLETE_OVERLAY/` contains the authoritative final versions of every changed or added source file, test, runtime asset, document, and reference screenshot using repository-relative paths.
- `TRACKED_CHANGES_COLOR_INK.patch` is a convenience binary Git patch for files that existed at the source baseline.
- `COMPLETE_IMPLEMENTATION_MANIFEST.md` records the scope, compatibility decisions, files, source hashes, and verified results.

## Source baseline

- Repository: `https://github.com/fopearcano/supervillained-vg1.git`
- Branch: `claude/gallant-pascal-wjy5l2`
- Baseline commit: `879ac0fdab999c8a10c676698d5d4c33e846e10a`

The supplied Color Ink art pack was originally authored against older ancestor commit `83beed9ba9c245c3eab029fc984dd5584c29b04d`. This complete implementation has already merged it semantically with the newer controls, combat, campaign, redesigned Green Zone, pollution waves, and terrain animation. Do not reapply the raw art pack's older source overlay.

## Integration task

1. Read the target repository's `CLAUDE.md` completely.
2. Inspect the current branch and `git status`. Preserve all unrelated user changes.
3. Extract this implementation ZIP into a temporary directory; do not blindly unzip it over a divergent checkout.
4. If the target is still the exact baseline commit, copy `COMPLETE_OVERLAY/` over the checkout, preserving its relative paths. The patch may be used first, but the overlay is still required for new files and binary runtime art.
5. If the target has diverged, merge the overlay semantically. Preserve newer unrelated work and all current gameplay behavior.
6. Retain these intentional compatibility decisions:
   - Keep the deterministic branching 96x96 Green Zone generator, its plazas, ponds, optional circuits, route-aware treats, balance, cat/ball tuning, and pollution-wave encounters.
   - Load the delivered `ch01_greenzone` native tile and prop bank for the arcade.
   - Do not select the manifest's `1:arcade` authored cell composition. It belongs to the old single-corridor map and would ghost obsolete routes over the redesigned park.
   - Keep current phase-offset tall-grass, pond, and deep-water animation and the continuous-water seam fix.
   - Preserve action-button modes, gestures, sword/shield combat, pause/resume behavior, and `consumeAny(['action', 'pee', 'confirm'])` in mini-games.
   - Story floor compositions are visual-only; they must not alter LevelData, collision, props, numbered markers, objectives, or scripts.
   - Character sheets are not part of the environment delivery and must remain unchanged.
7. Confirm `public/environment-ink/` contains the 15 chapter atlas PNGs and `manifest.json`, and that `src/assets/environment.ts` preloads them locally with guarded procedural fallbacks.
8. Add no runtime dependency or CDN resource. Keep strict TypeScript and offline Capacitor compatibility.

## Required verification

Run and fix every failure from:

```bash
npm install
npm test
npm run build
npm run smoke
npm run playtest
npm run screens -- m1 story1 story7
```

Expected implementation snapshot: 27 test files and 185 tests passing; all 36 story sub-levels pass smoke; playtest finishes 36/36 with zero unfinished scenes, flags, or page errors.

Visually inspect at least:

- `docs/screens/m1-walk.png`
- `docs/screens/m1-behind-tree.png`
- `docs/screens/c1-lawn.png`
- `docs/screens/c7-vanguard.png`
- `docs/screens/c8-supervillained.png`

Check actor/HUD contrast, water continuity and animation, prop anchors, occlusion, chapter colors, story floor layouts, and preservation of the redesigned park routes. Finish by reporting changed files, merge decisions, verification output, and screenshot paths. Do not commit or push unless explicitly asked.

