# Normal animations — eight directions

This update gives normal Zampanò and Sbrimbrulòn distinct N, NE, E, SE, S, SW, W and NW views
for all twelve actions. The previous delivery had eight atlas rows but only four actual views:
NE/E/SE matched, and NW/W/SW matched.

## Install the compact ZIP

Extract `Supervillained_VG1_Normal_8_Directions_Update.zip` into the game project root, keeping
its folder structure and replacing the four matching PNGs and sprite viewer file. It is an
overlay for the existing `claude/gallant-pascal-wjy5l2` integration, not a full game project.
The updated files are already installed in this repository.

- `public/sprites/zampano.png` and `zampano-tired.png`
- `public/sprites/sbrimbrulon.png` and `sbrimbrulon-tired.png`
- `src/scenes/spriteViewerScene.ts`
- `preview/normal-eight-directions.gif` in the ZIP shows idle, walk and run in all eight views.

Open the game with `?debug=sprites&char=zampano` or `?debug=sprites&char=sbrimbrulon` to see
every action across all eight headings. The atlas grid, action names, frame counts and authored
timing are unchanged, so no manifest edits or movement-code changes are needed.

## Source artwork

The repository also includes generated quarter-view source sheets and prompts under
`assets/8-directions/`, plus packing metadata. These are source artwork, not runtime downloads.
Rebuild each normal atlas with Pillow installed:

```bash
python3 scripts/build-zampano-diagonals.py
python3 scripts/build-sbrimbrulon-diagonals.py
```

Both scripts start from `art-archive/directions-before-8way/`, extract complete authored
sprites, and use one fixed transform per directional clip. They preserve the original cardinal
frames and the ground anchor `(20, 36)` exactly.

## Verification

`npm test` passes all 160 tests, including actual decoded pixel comparisons for all 24 normal
character/action combinations and layout checks for all 96 viewer cells. `npm run build`
passes. Browser screenshot verification was attempted but could not launch in the execution
environment because browser socket creation is restricted; the source sprites and preview
were inspected directly.

The armoured sheets still contain their original four source profiles. This update covers
the normal costumes only.
