"""Build versioned frontend Flux Kontext workflows on C: only."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WORKFLOWS = WORK / "workflows"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
TEMPLATE = WORKFLOWS / "zampano_canonical_N_kontext_attempt-2.json"
ACCEPTED_E = WORK / "canonical-inputs" / "zampano_E_v1_sdxl_640.png"

DIRECTION_SPECS = {
    "NE": {
        "attempt": 1,
        "seed": 611172820001,
        "prompt": (
            "Turn this exact pixel-art dog to a strict three-quarter rear NE view, facing upper-right "
            "and mostly away from the camera. Preserve the exact same compact low Maltese body, very "
            "long shaggy white coat, short legs, thick curled tail, head/body proportions, and especially "
            "the same large rounded floppy ears hanging down at both sides of the head. The ears must never "
            "be upright, pointed, triangular, fox-like or cat-like. Show only the appropriate small side of "
            "the muzzle for a rear three-quarter view. Keep the exact pale ivory, blue-gray and dark teal "
            "palette, hard square pixels, size, outline and orthographic game-sprite style. Complete full "
            "body centered on flat solid chroma green, four paws grounded, no shadow, props, collar, text, "
            "red, orange or purple."
        ),
    },
    "SE": {
        "attempt": 1,
        "seed": 611172830001,
        "prompt": (
            "Turn this exact pixel-art dog to a strict three-quarter front SE view, facing lower-right "
            "with body and muzzle both pointing diagonally right. Preserve the exact same compact low "
            "Maltese body, very long shaggy white coat, short legs, thick curled tail, head/body proportions, "
            "and especially the same large rounded floppy ears hanging down at both sides of the head. The "
            "ears must never be upright, pointed, triangular, fox-like or cat-like. Keep the exact pale ivory, "
            "blue-gray and dark teal palette, hard square pixels, size, outline and orthographic game-sprite "
            "style. Complete full body centered on flat solid chroma green, four paws grounded, no shadow, "
            "props, collar, text, red, orange or purple."
        ),
    },
    "S": {
        "attempt": 1,
        "seed": 611172840001,
        "prompt": (
            "Turn this exact pixel-art dog to a strict symmetrical front S view, facing directly toward the "
            "camera with chest and all four paws visible. Preserve the exact same compact low Maltese body, "
            "very long shaggy white coat, short legs, thick curled tail, head/body proportions, and especially "
            "the same two large rounded floppy ears hanging down symmetrically. The ears must never be upright, "
            "pointed, triangular, fox-like or cat-like. Keep the exact pale ivory, blue-gray and dark teal "
            "palette, hard square pixels, size, outline and orthographic game-sprite style. Complete full body "
            "centered on flat solid chroma green, four paws grounded, no shadow, props, collar, text, red, "
            "orange or purple."
        ),
    },
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def nodes_by_type(workflow: dict[str, object], node_type: str) -> list[dict[str, object]]:
    return [node for node in workflow["nodes"] if node.get("type") == node_type]


def prompt_nodes(workflow: dict[str, object]) -> list[dict[str, object]]:
    known = {"MarkdownNote", "SaveImage", "LoadImage"}
    return [
        node
        for node in workflow["nodes"]
        if node.get("type") not in known
        and isinstance(node.get("widgets_values"), list)
        and len(node["widgets_values"]) >= 6
        and isinstance(node["widgets_values"][0], str)
        and "flux1-dev-kontext" in str(node["widgets_values"][1])
    ]


def validate_frontend(workflow: dict[str, object]) -> None:
    if not isinstance(workflow.get("nodes"), list) or not isinstance(workflow.get("links"), list):
        raise ValueError("not a frontend workflow")
    if len(nodes_by_type(workflow, "LoadImage")) != 2:
        raise ValueError("Kontext workflow must have exactly two LoadImage reference nodes")
    if len(nodes_by_type(workflow, "SaveImage")) != 1 or len(prompt_nodes(workflow)) != 1:
        raise ValueError("Kontext workflow must have one prompt subgraph and one SaveImage")


def build_direction(direction: str, spec: dict[str, object]) -> Path:
    workflow = copy.deepcopy(json.loads(TEMPLATE.read_text(encoding="utf-8")))
    for node in nodes_by_type(workflow, "LoadImage"):
        node["widgets_values"][0] = ACCEPTED_E.name
    prompt = prompt_nodes(workflow)[0]
    prompt["widgets_values"][0] = spec["prompt"]
    prompt["widgets_values"][5] = spec["seed"]
    save = nodes_by_type(workflow, "SaveImage")[0]
    save["widgets_values"][0] = f"update2-local-kontext/canonical_{direction}_attempt-{spec['attempt']}"
    validate_frontend(workflow)
    output = WORKFLOWS / f"zampano_canonical_{direction}_kontext_attempt-{spec['attempt']}.json"
    write_json(output, workflow)
    return output


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    manifest["requests"].setdefault("canonical/N/kontext-attempt-1", {}).update(
        {
            "engine": "local-flux-kontext",
            "status": "failed_visual_review",
            "prompt_id": "c7c4d8ca...",
            "failure_reason": "Rear-view direction was readable but both ears became upright and pointy; fails Maltese identity.",
            "actual_charge": 0,
        }
    )
    manifest["requests"].setdefault("canonical/N/kontext-attempt-2", {}).update(
        {
            "engine": "local-flux-kontext",
            "status": "accepted_candidate",
            "prompt_id": "e4e68595...",
            "accepted_output": "sprites-out/update2-local/raw/canonical/N/kontext-attempt-2/e4e68595_000.png",
            "notes": "Acceptable rear/floppy-ear candidate; still requires native cleanup, envelope and palette validation.",
            "actual_charge": 0,
        }
    )
    for direction, spec in DIRECTION_SPECS.items():
        path = build_direction(direction, spec)
        key = f"canonical/{direction}/kontext-attempt-{spec['attempt']}"
        manifest["requests"][key] = {
            "engine": "local-flux-kontext",
            "direction": direction,
            "attempt": spec["attempt"],
            "seed": spec["seed"],
            "prompt": spec["prompt"],
            "reference_images": [ACCEPTED_E.name, ACCEPTED_E.name],
            "reference_sha256": digest(ACCEPTED_E),
            "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": digest(path),
            "status": "planned",
            "prompt_id": None,
            "actual_charge": 0,
        }
        print(path)
    write_json(MANIFEST, manifest)


if __name__ == "__main__":
    main()

