"""Create synchronized costume contacts and GIFs from validated maintenance frames."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
CONFIG = json.loads((WORK / "config" / "actions.json").read_text(encoding="utf-8"))
DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
VARIANTS = {"cross": WORK / "frames-cross", "knight": WORK / "frames-knight"}
OUT = WORK / "previews" / "costumes"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for variant, folder in VARIANTS.items():
        actions = tuple(CONFIG)
        contact = Image.new("RGBA", (640, len(actions) * 340), (0, 0, 0, 0))
        draw = ImageDraw.Draw(contact)
        for row, action in enumerate(actions):
            count = int(CONFIG[action]["frames"])
            phases: list[Image.Image] = []
            for phase in range(count):
                grid = Image.new("RGBA", (640, 320), (0, 0, 0, 0))
                for index, direction in enumerate(DIRECTIONS):
                    frame = Image.open(folder / f"{action}_{direction}_{phase}.png").convert("RGBA").resize((160, 160), Image.Resampling.NEAREST)
                    grid.alpha_composite(frame, ((index % 4) * 160, (index // 4) * 160))
                phases.append(grid)
            y = row * 340
            contact.alpha_composite(phases[0], (0, y + 20))
            draw.rectangle((0, y, 639, y + 19), fill=(0, 0, 0, 255))
            draw.text((4, y + 3), f"{variant} {action} phase 0 — N NE E SE / S SW W NW", fill=(255, 255, 255, 255))
            gif = OUT / f"{variant}-{action}.gif"
            phases[0].save(gif, save_all=True, append_images=phases[1:], duration=round(1000 / int(CONFIG[action]["fps"])), loop=0 if CONFIG[action]["loop"] else 1, disposal=2, transparency=0)
        contact.save(OUT / f"{variant}-all-actions-contact.png")
    print("wrote costume contacts and synchronized GIFs")


if __name__ == "__main__":
    main()

