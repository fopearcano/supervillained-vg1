"""Build local SDXL pose workflows for Zampano's two-frame actions."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(__file__).resolve().parents[3]
CONFIG = json.loads((WORK / "config" / "actions.json").read_text(encoding="utf-8"))
TEMPLATE = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_tired_E_sdxl_api.json"
PLACEHOLDER = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_placeholder_full.png"
ACCEPTED_E = WORK / "canonical-native" / "zampano_E_v1.png"
V2_FRAMES = REPO / "sprites-out" / "zampano" / "v2" / "frames"
GUIDES = WORK / "guides"
WORKFLOWS = WORK / "workflows"
METADATA = WORK / "metadata"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")

DIRECTIONS = {
    "N": "rear view facing directly away from the camera",
    "NE": "three-quarter rear view facing upper right",
    "E": "exact right-facing side profile",
    "SE": "three-quarter front view facing lower right",
    "S": "front view facing directly toward the camera",
}
SHEET_DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
ACTION_ORDER = ("idle", "walk", "run", "sniff", "pee", "poop", "eat", "bark", "fetch", "hurt")
POSE_ACTIONS = ("idle", "sniff", "pee", "poop", "eat", "bark", "hurt", "tired")
BASE_SEED = 611172700000
NEGATIVE = (
    "changing dog identity, changing breed, pointy ears, upright ears, cat, human, "
    "extra dog, duplicate dog, extra legs, missing legs, cropped body, portrait, close-up, "
    "realistic fur, photograph, 3d render, smooth vector art, blur, antialiasing, scenery, "
    "floor, ground, cast shadow, collar, clothing, text, watermark"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def neutral(direction: str) -> Image.Image:
    source = ACCEPTED_E if direction == "E" else V2_FRAMES / f"run_{direction}_0.png"
    return Image.open(source).convert("RGBA")


def breathing(frame: Image.Image, phase: int) -> Image.Image:
    if phase == 0:
        return frame.copy()
    rgba = np.asarray(frame.convert("RGBA")).copy()
    alpha = rgba[:, :, 3] > 0
    ys, _ = np.nonzero(alpha)
    split = min(31, int(ys.max()) - 5)
    upper = rgba[:split].copy()
    rgba[: split + 1] = 0
    rgba[1 : split + 1] = upper
    # Restore the planted lower body and paws exactly.
    original = np.asarray(frame.convert("RGBA"))
    rgba[split:] = original[split:]
    return Image.fromarray(rgba, "RGBA")


def placeholder_pose(action: str, direction: str, phase: int) -> Image.Image:
    if action == "idle":
        return breathing(neutral(direction), phase)
    if action == "tired":
        source = Image.open(V2_FRAMES / f"tired_{direction}_{phase}.png").convert("RGBA")
        return source
    sheet = Image.open(PLACEHOLDER).convert("RGBA")
    action_row = ACTION_ORDER.index(action) * 8 + SHEET_DIRECTIONS.index(direction)
    return sheet.crop((phase * 40, action_row * 40, phase * 40 + 40, action_row * 40 + 40))


def on_green(frame: Image.Image) -> Image.Image:
    sprite = frame.convert("RGBA").resize((640, 640), Image.Resampling.NEAREST)
    background = Image.new("RGB", (640, 640), (0, 255, 0))
    background.paste(sprite.convert("RGB"), (0, 0), sprite.getchannel("A"))
    return background


def prepare_inputs(install: bool) -> dict[str, object]:
    GUIDES.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, object] = {"canonical": {}, "guides": {}}
    for direction in DIRECTIONS:
        source = ACCEPTED_E if direction == "E" else V2_FRAMES / f"run_{direction}_0.png"
        canonical_name = f"update2_local_zampano_{direction}_canonical_set-v1_sdxl_640.png"
        canonical_path = GUIDES / canonical_name
        on_green(neutral(direction)).save(canonical_path)
        manifest["canonical"][direction] = {
            "path": str(canonical_path.relative_to(REPO)).replace("\\", "/"),
            "sha256": sha256(canonical_path),
            "source": str(source.relative_to(REPO)).replace("\\", "/"),
            "reference_only": direction != "E",
            "accepted_appearance_canonical": direction == "E",
        }
        if install:
            shutil.copy2(canonical_path, COMFY_INPUT / canonical_name)
        for action in POSE_ACTIONS:
            for phase in range(2):
                guide_name = f"update2_local_{action}_{direction}_{phase}_guide_sdxl.png"
                guide_path = GUIDES / guide_name
                on_green(placeholder_pose(action, direction, phase)).save(guide_path)
                manifest["guides"][f"{action}/{direction}/{phase}"] = {
                    "path": str(guide_path.relative_to(REPO)).replace("\\", "/"),
                    "sha256": sha256(guide_path),
                    "reference_only": True,
                }
                if install:
                    shutil.copy2(guide_path, COMFY_INPUT / guide_name)
    write_json(METADATA / "pose-guide-manifest.json", manifest)
    guide_contact()
    return manifest


def guide_contact() -> None:
    cell = 160
    actions = POSE_ACTIONS
    contact = Image.new("RGB", (len(DIRECTIONS) * cell, len(actions) * cell * 2), (20, 20, 20))
    draw = ImageDraw.Draw(contact)
    for action_index, action in enumerate(actions):
        for phase in range(2):
            for direction_index, direction in enumerate(DIRECTIONS):
                image = Image.open(GUIDES / f"update2_local_{action}_{direction}_{phase}_guide_sdxl.png")
                image = image.resize((cell, cell), Image.Resampling.NEAREST)
                x = direction_index * cell
                y = (action_index * 2 + phase) * cell
                contact.paste(image, (x, y))
                draw.text((x + 3, y + 3), f"{action} {direction} {phase}", fill=(0, 0, 0))
    output = WORK / "previews" / "pose-guides.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    contact.save(output)


def seed_for(action: str, direction: str, phase: int, attempt: int) -> int:
    return (
        BASE_SEED
        + POSE_ACTIONS.index(action) * 1000
        + tuple(DIRECTIONS).index(direction) * 100
        + phase * 10
        + attempt
    )


def action_prompt(action: str, direction: str, phase: int) -> str:
    phase_text = "first key pose" if phase == 0 else "second key pose"
    return (
        "pixel art game sprite of Zampano, one small scruffy white fluffy Maltese dog, "
        f"complete full body visible with generous empty space, {DIRECTIONS[direction]}. "
        f"{CONFIG[action]['prompt']}, {phase_text}. Preserve the exact rounded floppy ears, "
        "long low body, shaggy coat, identity, proportions, scale, palette and facing from "
        "the reference. Centered isolated character on flat solid chroma green, hard square "
        "pixels, limited colors, no ground and no shadow"
    )


def build(batch: str, attempt: int, install: bool) -> None:
    guide_manifest = prepare_inputs(install)
    template = json.loads(TEMPLATE.read_text(encoding="utf-8"))
    selected = (
        tuple(("idle", "E", phase) for phase in range(2))
        if batch == "idle-e"
        else tuple(
            (action, direction, phase)
            for action in POSE_ACTIONS
            for direction in DIRECTIONS
            for phase in range(2)
        )
    )
    generation_path = METADATA / "generation-manifest.json"
    generation = json.loads(generation_path.read_text(encoding="utf-8"))
    generation.setdefault("sdxl_pose_models", {})
    generation["sdxl_pose_models"] = {
        "checkpoint": "sd_xl_base_1.0.safetensors",
        "pixel_lora": "pixel-art-xl.safetensors",
        "ip_adapter": "PLUS (high strength)",
        "controlnet": "controlnet-canny-sdxl-1.0_diffusion_pytorch_model.fp16.safetensors",
        "vae": "sdxl.vae.safetensors",
    }
    generation.setdefault("failures", [])
    pose_selections_path = METADATA / "pose-selections.json"
    if pose_selections_path.exists():
        pose_selections = json.loads(pose_selections_path.read_text(encoding="utf-8"))
    else:
        pose_selections = {}

    denoise = {
        "idle": 0.28,
        "sniff": 0.34,
        "pee": 0.4,
        "poop": 0.4,
        "eat": 0.36,
        "bark": 0.34,
        "hurt": 0.38,
        "tired": 0.35,
    }
    for action, direction, phase in selected:
        workflow = copy.deepcopy(template)
        seed = seed_for(action, direction, phase, attempt)
        canonical_name = f"update2_local_zampano_{direction}_canonical_set-v1_sdxl_640.png"
        guide_name = f"update2_local_{action}_{direction}_{phase}_guide_sdxl.png"
        text = action_prompt(action, direction, phase)
        workflow["4"]["inputs"]["image"] = canonical_name
        workflow["17"]["inputs"]["image"] = canonical_name
        workflow["8"]["inputs"]["image"] = guide_name
        workflow["6"]["inputs"]["text"] = text
        workflow["7"]["inputs"]["text"] = NEGATIVE
        workflow["13"]["inputs"]["seed"] = seed
        workflow["13"]["inputs"]["denoise"] = denoise[action]
        workflow["16"]["inputs"]["filename_prefix"] = (
            f"update2-local-sdxl/{action}_{direction}_{phase}_attempt-{attempt}"
        )
        path = WORKFLOWS / f"zampano_{action}_{direction}_{phase}_sdxl_attempt-{attempt}_api.json"
        write_json(path, workflow)
        key = f"{action}/{direction}/phase-{phase}/sdxl-attempt-{attempt}"
        generation["requests"][key] = {
            "action": action,
            "direction": direction,
            "phase": phase,
            "attempt": attempt,
            "engine": "local-sdxl-ipadapter-canny",
            "seed": seed,
            "prompt": text,
            "negative_prompt": NEGATIVE,
            "denoise": denoise[action],
            "canonical_sha256": guide_manifest["canonical"][direction]["sha256"],
            "guide_sha256": guide_manifest["guides"][f"{action}/{direction}/{phase}"]["sha256"],
            "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": sha256(path),
            "status": "planned",
            "prompt_id": None,
            "actual_charge": 0,
        }
        selection = pose_selections.setdefault(
            f"{action}/{direction}/phase-{phase}",
            {
                "attempt": None,
                "index": None,
                "reviewed": False,
                "notes": "",
            },
        )
        if not selection.get("reviewed"):
            selection["attempt"] = attempt
            selection["index"] = 0
    write_json(generation_path, generation)
    write_json(pose_selections_path, pose_selections)
    print(f"wrote {len(selected)} SDXL pose workflows; no inference was submitted")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch", choices=("idle-e", "full"), default="idle-e")
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--install-inputs", action="store_true")
    args = parser.parse_args()
    if args.attempt < 1:
        parser.error("--attempt must be >= 1")
    build(args.batch, args.attempt, args.install_inputs)


if __name__ == "__main__":
    main()

