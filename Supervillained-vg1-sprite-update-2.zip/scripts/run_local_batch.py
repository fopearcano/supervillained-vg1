"""Run vetted API-format workflows against the loopback ComfyUI server.

This deliberately bypasses comfy-cli: it submits one workflow at a time to the
local REST API, waits for completion, downloads SaveImage results, and records
sanitized job metadata.  It never embeds workflow payloads or image data in the
job log.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import glob
import hashlib
import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
RAW = WORK / "raw"
JOBS_PATH = WORK / "metadata" / "local-jobs.json"
DEFAULT_BASE_URL = "http://127.0.0.1:8190"
DEFAULT_INPUT_DIR = Path(r"E:\CodexComfyUI\workspace\input")
INPUT_SOURCE_DIRS = (WORK / "canonical", WORK / "canonical-inputs", WORK / "guides")

DIRS = {"N", "NE", "E", "SE", "S"}
ENGINE_TOKENS = {"sdxl", "wan", "kontext"}
DENIED_NODE_TERMS = (
    "api",
    "partner",
    "cloud",
    "retrodiffusion",
    "replicate",
    "openai",
    "gemini",
    "anthropic",
    "stabilityai",
    "falai",
)
SECRET_RE = re.compile(r"(?:rdpk-[A-Za-z0-9_-]+|(?:api[_-]?key|token|secret)\s*[:=])", re.I)
ATTEMPT_RE = re.compile(r"^attempt-(\d+)$")


class RunnerError(RuntimeError):
    pass


@dataclass(frozen=True)
class WorkflowSpec:
    path: Path
    key: str
    sha256: str
    prompt: dict[str, dict[str, Any]]
    action: str
    direction: str
    phase: int | None
    attempt: int
    engine: str

    @property
    def destination(self) -> Path:
        if self.engine == "sdxl" and self.phase is not None:
            return RAW / self.action / self.direction / f"sdxl-attempt-{self.attempt}" / f"phase-{self.phase}"
        return RAW / self.action / self.direction / f"attempt-{self.attempt}"

    @property
    def output_stem(self) -> str:
        if self.phase is not None:
            return f"{self.engine}_phase-{self.phase}"
        return self.engine


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def validate_base_url(value: str) -> str:
    parsed = urllib.parse.urlparse(value.rstrip("/"))
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise RunnerError("ComfyUI URL must be loopback HTTP (127.0.0.1, localhost, or ::1)")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise RunnerError("ComfyUI URL may not contain credentials, query parameters, or a fragment")
    return value.rstrip("/")


def expand_workflows(values: list[str]) -> list[Path]:
    found: dict[str, Path] = {}
    for value in values:
        matches = [Path(item) for item in glob.glob(value, recursive=True)]
        if not matches and Path(value).exists():
            matches = [Path(value)]
        if not matches:
            raise RunnerError(f"workflow path/glob matched nothing: {value}")
        for match in matches:
            if match.is_dir():
                candidates = sorted(match.glob("*.json"))
            else:
                candidates = [match]
            for candidate in candidates:
                found[str(candidate.resolve()).lower()] = candidate.resolve()
    if not found:
        raise RunnerError("no workflows selected")
    return [found[key] for key in sorted(found)]


def parse_name(path: Path) -> tuple[str, str, int | None, int, str]:
    stem = path.stem
    if stem.endswith("_api"):
        stem = stem[:-4]
    if not stem.startswith("zampano_"):
        raise RunnerError(f"cannot infer output layout from workflow name: {path.name}")
    tokens = stem[len("zampano_") :].split("_")
    attempt_index = next((i for i, token in enumerate(tokens) if ATTEMPT_RE.match(token)), None)
    if attempt_index is None:
        raise RunnerError(f"workflow name lacks attempt-N: {path.name}")
    attempt = int(ATTEMPT_RE.match(tokens[attempt_index]).group(1))
    prefix = tokens[:attempt_index]
    action = prefix[0].lower() if prefix else ""
    direction = next((token for token in prefix if token in DIRS), "")
    phase = next((int(token) for token in prefix if token.isdigit()), None)
    engine = next((token for token in prefix if token.lower() in ENGINE_TOKENS), "")
    if not engine:
        engine = "wan" if action in {"walk", "run", "fetch"} and phase is None else "local"
    if not action or not direction:
        raise RunnerError(f"workflow name lacks action/direction: {path.name}")
    return action, direction, phase, attempt, engine.lower()


def walk_values(value: Any):
    if isinstance(value, dict):
        for key, child in value.items():
            yield str(key), child
            yield from walk_values(child)
    elif isinstance(value, list):
        for child in value:
            yield "", child


def validate_prompt(path: Path, value: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(value, dict) or not value:
        raise RunnerError(f"{path.name}: workflow must be a non-empty API prompt object")
    if "nodes" in value or "links" in value:
        raise RunnerError(f"{path.name}: frontend workflow JSON is not accepted; convert it to API format")
    classes: list[str] = []
    save_nodes = 0
    for node_id, node in value.items():
        if not isinstance(node_id, str) or not isinstance(node, dict):
            raise RunnerError(f"{path.name}: invalid API workflow node {node_id!r}")
        class_type = node.get("class_type")
        inputs = node.get("inputs")
        if not isinstance(class_type, str) or not isinstance(inputs, dict):
            raise RunnerError(f"{path.name}: node {node_id} lacks class_type/inputs")
        classes.append(class_type)
        save_nodes += int(class_type == "SaveImage")
        lowered = class_type.lower()
        if any(term in lowered for term in DENIED_NODE_TERMS):
            raise RunnerError(f"{path.name}: refusing possible paid/remote node {class_type}")
        for key, child in walk_values(inputs):
            key_lower = key.lower()
            if any(term in key_lower for term in ("api_key", "apikey", "token", "secret")):
                raise RunnerError(f"{path.name}: refusing credential-bearing input {key}")
            if isinstance(child, str):
                if "base64" in child.lower() or SECRET_RE.search(child):
                    raise RunnerError(f"{path.name}: refusing embedded data/credential text")
                if key_lower in {"url", "endpoint", "base_url", "host"} and child:
                    parsed = urllib.parse.urlparse(child if "://" in child else f"http://{child}")
                    if parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
                        raise RunnerError(f"{path.name}: refusing non-loopback endpoint {child}")
    if save_nodes < 1:
        raise RunnerError(f"{path.name}: workflow has no SaveImage output")
    return value


def load_spec(path: Path) -> WorkflowSpec:
    try:
        text = path.read_text(encoding="utf-8")
        value = json.loads(text)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RunnerError(f"cannot read workflow {path}: {exc}") from exc
    prompt = validate_prompt(path, value)
    action, direction, phase, attempt, engine = parse_name(path)
    try:
        key = path.relative_to(WORK).as_posix()
    except ValueError:
        key = path.as_posix()
    return WorkflowSpec(path, key, digest(path), prompt, action, direction, phase, attempt, engine)


def load_jobs() -> dict[str, Any]:
    if not JOBS_PATH.exists():
        return {"version": 1, "jobs": {}}
    try:
        value = json.loads(JOBS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RunnerError(f"cannot read {JOBS_PATH}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("jobs"), dict):
        raise RunnerError(f"invalid job log: {JOBS_PATH}")
    value["version"] = 1
    return value


def http_json(base_url: str, path: str, *, method: str = "GET", payload: object | None = None, timeout: float = 30) -> Any:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        base_url + path,
        data=data,
        method=method,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read()
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
        raise RunnerError(f"loopback ComfyUI request failed: {type(exc).__name__}: {exc}") from exc
    if not body:
        return {}
    try:
        return json.loads(body)
    except json.JSONDecodeError as exc:
        raise RunnerError("ComfyUI returned non-JSON data") from exc


def history_record(base_url: str, prompt_id: str) -> dict[str, Any] | None:
    value = http_json(base_url, f"/history/{urllib.parse.quote(prompt_id)}")
    if isinstance(value, dict) and isinstance(value.get(prompt_id), dict):
        return value[prompt_id]
    return None


def wait_for_job(base_url: str, prompt_id: str, timeout: float, poll: float) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        record = history_record(base_url, prompt_id)
        if record is not None:
            status = record.get("status") if isinstance(record.get("status"), dict) else {}
            status_text = str(status.get("status_str", "")).lower()
            completed = bool(status.get("completed"))
            messages = status.get("messages") if isinstance(status.get("messages"), list) else []
            if status_text in {"error", "failed"} or any(
                isinstance(message, list) and message and message[0] == "execution_error" for message in messages
            ):
                raise RunnerError(f"ComfyUI job {prompt_id} failed")
            if completed or status_text == "success":
                return record
        time.sleep(poll)
    raise RunnerError(f"ComfyUI job {prompt_id} timed out after {timeout:g}s")


def output_images(record: dict[str, Any]) -> list[dict[str, str]]:
    outputs = record.get("outputs")
    if not isinstance(outputs, dict):
        raise RunnerError("completed ComfyUI job has no outputs object")
    images: list[dict[str, str]] = []
    for node_id in sorted(outputs, key=lambda item: (not str(item).isdigit(), str(item))):
        node = outputs[node_id]
        if not isinstance(node, dict) or not isinstance(node.get("images"), list):
            continue
        for item in node["images"]:
            if not isinstance(item, dict) or not isinstance(item.get("filename"), str):
                continue
            images.append(
                {
                    "filename": item["filename"],
                    "subfolder": str(item.get("subfolder", "")),
                    "type": str(item.get("type", "output")),
                }
            )
    if not images:
        raise RunnerError("completed ComfyUI job produced no SaveImage files")
    return images


def download_images(base_url: str, spec: WorkflowSpec, prompt_id: str, record: dict[str, Any]) -> list[str]:
    spec.destination.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for index, item in enumerate(output_images(record)):
        suffix = Path(item["filename"]).suffix.lower()
        if suffix not in {".png", ".jpg", ".jpeg", ".webp"}:
            raise RunnerError(f"unexpected ComfyUI output extension: {suffix}")
        target = spec.destination / f"{spec.output_stem}_{index:03d}{suffix}"
        if target.exists():
            raise RunnerError(f"refusing to overwrite output: {target}")
        query = urllib.parse.urlencode(item)
        request = urllib.request.Request(base_url + "/view?" + query, method="GET")
        temp = target.with_suffix(target.suffix + ".part")
        try:
            with urllib.request.urlopen(request, timeout=60) as response, temp.open("xb") as handle:
                while chunk := response.read(1024 * 1024):
                    handle.write(chunk)
            if temp.stat().st_size == 0:
                raise RunnerError(f"empty ComfyUI output: {item['filename']}")
            os.replace(temp, target)
        except Exception:
            temp.unlink(missing_ok=True)
            raise
        written.append(target.relative_to(WORK).as_posix())
    return written


def existing_for(spec: WorkflowSpec) -> list[Path]:
    return sorted(spec.destination.glob(spec.output_stem + "_*")) if spec.destination.exists() else []


def load_image_names(specs: list[WorkflowSpec]) -> list[str]:
    names: set[str] = set()
    for spec in specs:
        for node in spec.prompt.values():
            if node["class_type"] != "LoadImage":
                continue
            name = node["inputs"].get("image")
            if not isinstance(name, str) or not name:
                raise RunnerError(f"{spec.path.name}: LoadImage has no image filename")
            normalized = name.replace("\\", "/")
            pure = Path(normalized)
            if pure.is_absolute() or ".." in pure.parts:
                raise RunnerError(f"{spec.path.name}: unsafe LoadImage path {name}")
            if pure.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
                raise RunnerError(f"{spec.path.name}: unsupported LoadImage extension {pure.suffix}")
            names.add(normalized)
    return sorted(names)


def input_candidates(name: str) -> list[Path]:
    basename = Path(name).name
    matches: list[Path] = []
    for root in INPUT_SOURCE_DIRS:
        if root.exists():
            matches.extend(path for path in root.rglob(basename) if path.is_file())
    unique = {str(path.resolve()).lower(): path.resolve() for path in matches}
    return [unique[key] for key in sorted(unique)]


def copy_verified(source: Path, target: Path, retries: int) -> None:
    expected = digest(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(1, retries + 1):
        temp = target.with_name(target.name + f".copy-{os.getpid()}.part")
        try:
            temp.unlink(missing_ok=True)
            shutil.copyfile(source, temp)
            if digest(temp) != expected:
                raise RunnerError(f"hash mismatch while copying {source.name}")
            os.replace(temp, target)
            if digest(target) != expected:
                raise RunnerError(f"hash mismatch after installing {target.name}")
            return
        except (OSError, RunnerError):
            temp.unlink(missing_ok=True)
            if attempt == retries:
                raise
            time.sleep(min(2.0, 0.25 * (2 ** (attempt - 1))))


def alias_names(source: Path):
    value = digest(source)
    for length in (8, 12, 16):
        yield f"u2_{value[:length]}{source.suffix.lower()}"


def readable_hash(path: Path) -> tuple[bool, str | None]:
    """Return existence and digest; an unreadable existing file has hash None."""

    try:
        exists = path.exists()
    except OSError:
        return True, None
    if not exists:
        return False, None
    try:
        return True, digest(path)
    except OSError:
        return True, None


def install_alias(source: Path, input_dir: Path, retries: int) -> tuple[str, str]:
    source_hash = digest(source)
    for name in alias_names(source):
        target = input_dir / name
        exists, current_hash = readable_hash(target)
        if exists and current_hash == source_hash:
            return name, "alias_reused"
        if exists:
            continue
        try:
            copy_verified(source, target, retries)
            return name, "alias_copied"
        except OSError:
            continue
    raise RunnerError(f"could not install a readable short alias for {source.name}")


def sync_inputs(
    specs: list[WorkflowSpec],
    input_dir: Path,
    *,
    execute: bool,
    retries: int,
) -> tuple[list[dict[str, Any]], dict[str, str], dict[str, str]]:
    """Install LoadImage files and return (plan, name aliases, source hashes).

    Some Windows/E: configurations reject particular long filenames with OS
    error 433.  If a verified direct copy fails, install a stable content-hash
    alias and rewrite only the in-memory prompt submitted to ComfyUI.
    """

    plan: list[dict[str, Any]] = []
    aliases: dict[str, str] = {}
    hashes: dict[str, str] = {}
    root = input_dir.resolve() if execute else None
    for name in load_image_names(specs):
        candidates = input_candidates(name)
        candidate_hashes = {digest(path) for path in candidates}
        if len(candidate_hashes) > 1:
            raise RunnerError(f"ambiguous local input sources with different content: {name}")
        source = candidates[0] if candidates else None
        source_hash = digest(source) if source else None
        installed_name = name
        if not execute:
            status = "copy_required" if source else "preinstalled_required"
            installed_hash = source_hash or "unverified"
            aliases[name] = installed_name
            hashes[name] = str(installed_hash)
            plan.append(
                {
                    "name": name,
                    "installed_name": installed_name,
                    "status": status,
                    "source": source.relative_to(WORK).as_posix() if source else None,
                    "sha256": str(installed_hash),
                }
            )
            continue
        relative = Path(name.replace("/", os.sep))
        target = (input_dir / relative).resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise RunnerError(f"LoadImage target escapes ComfyUI input directory: {name}") from exc
        status = "installed"
        target_exists, target_hash = readable_hash(target)
        if target_exists and target_hash is not None and (source is None or target_hash == source_hash):
            installed_hash = target_hash
        elif source is None:
            raise RunnerError(f"missing LoadImage input and no local source found: {name}")
        else:
            try:
                if target_exists:
                    raise RunnerError(f"installed input differs from versioned source: {name}")
                copy_verified(source, target, retries)
                status = "copied"
                installed_hash = digest(target)
            except (OSError, RunnerError):
                installed_name, status = install_alias(source, input_dir, retries)
                installed_hash = source_hash
        if installed_name == name and not readable_hash(target)[0]:
            raise RunnerError(f"input was not installed: {name}")
        aliases[name] = installed_name
        hashes[name] = str(installed_hash)
        plan.append(
            {
                "name": name,
                "installed_name": installed_name,
                "status": status,
                "source": source.relative_to(WORK).as_posix() if source else None,
                "sha256": str(installed_hash),
            }
        )
    return plan, aliases, hashes


def prompt_with_aliases(spec: WorkflowSpec, aliases: dict[str, str]) -> dict[str, dict[str, Any]]:
    prompt = copy.deepcopy(spec.prompt)
    for node in prompt.values():
        if node["class_type"] != "LoadImage":
            continue
        original = str(node["inputs"]["image"]).replace("\\", "/")
        node["inputs"]["image"] = aliases.get(original, original)
    return prompt


def summarize(specs: list[WorkflowSpec], jobs: dict[str, Any], resume: bool) -> list[dict[str, Any]]:
    summary: list[dict[str, Any]] = []
    records = jobs["jobs"]
    for spec in specs:
        prior = records.get(spec.key) if isinstance(records.get(spec.key), dict) else None
        matches = existing_for(spec)
        resumable = bool(
            resume
            and prior
            and prior.get("workflow_sha256") == spec.sha256
            and prior.get("status") == "completed"
            and all((WORK / path).exists() for path in prior.get("outputs", []))
        )
        if matches and not resumable:
            raise RunnerError(
                f"existing outputs for {spec.key} are not a matching completed resume record: "
                + ", ".join(path.name for path in matches)
            )
        summary.append(
            {
                "workflow": spec.key,
                "sha256": spec.sha256,
                "action": spec.action,
                "direction": spec.direction,
                "phase": spec.phase,
                "attempt": spec.attempt,
                "engine": spec.engine,
                "destination": spec.destination.relative_to(WORK).as_posix(),
                "status": "skip_completed" if resumable else "ready",
            }
        )
    return summary


def sanitized_error(exc: Exception) -> str:
    text = f"{type(exc).__name__}: {exc}"
    return SECRET_RE.sub("[redacted]", text)[:1000]


def execute(
    spec: WorkflowSpec,
    jobs: dict[str, Any],
    base_url: str,
    timeout: float,
    poll: float,
    resume: bool,
    aliases: dict[str, str],
    input_hashes: dict[str, str],
) -> None:
    records = jobs["jobs"]
    prior = records.get(spec.key) if isinstance(records.get(spec.key), dict) else None
    if (
        resume
        and prior
        and prior.get("workflow_sha256") == spec.sha256
        and prior.get("status") == "completed"
        and all((WORK / path).exists() for path in prior.get("outputs", []))
    ):
        print(f"skip completed: {spec.key}")
        return

    started = time.monotonic()
    submitted_at = utc_now()
    prompt_id: str | None = None
    try:
        if resume and prior and prior.get("workflow_sha256") == spec.sha256 and prior.get("status") in {"queued", "running"}:
            prompt_id = str(prior.get("prompt_id") or "") or None
        if prompt_id is None:
            response = http_json(
                base_url,
                "/prompt",
                method="POST",
                payload={"prompt": prompt_with_aliases(spec, aliases), "client_id": str(uuid.uuid4())},
                timeout=30,
            )
            prompt_id = str(response.get("prompt_id", "")) if isinstance(response, dict) else ""
            if not prompt_id:
                raise RunnerError("ComfyUI did not return a prompt_id")
        records[spec.key] = {
            "workflow": spec.key,
            "workflow_sha256": spec.sha256,
            "action": spec.action,
            "direction": spec.direction,
            "phase": spec.phase,
            "attempt": spec.attempt,
            "engine": spec.engine,
            "prompt_id": prompt_id,
            "status": "running",
            "submitted_at": prior.get("submitted_at", submitted_at) if prior else submitted_at,
            "completed_at": None,
            "elapsed_seconds": None,
            "outputs": [],
            "actual_charge": 0,
            "inputs": [
                {
                    "name": name,
                    "installed_name": aliases.get(name, name),
                    "sha256": input_hashes[name],
                }
                for name in load_image_names([spec])
            ],
        }
        atomic_json(JOBS_PATH, jobs)
        print(f"running {spec.key}: {prompt_id}", flush=True)
        record = wait_for_job(base_url, prompt_id, timeout, poll)
        outputs = download_images(base_url, spec, prompt_id, record)
        records[spec.key].update(
            {
                "status": "completed",
                "completed_at": utc_now(),
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "outputs": outputs,
            }
        )
        atomic_json(JOBS_PATH, jobs)
        print(f"completed {spec.key}: {len(outputs)} file(s)", flush=True)
    except Exception as exc:
        records[spec.key] = {
            **(records.get(spec.key) if isinstance(records.get(spec.key), dict) else {}),
            "workflow": spec.key,
            "workflow_sha256": spec.sha256,
            "action": spec.action,
            "direction": spec.direction,
            "phase": spec.phase,
            "attempt": spec.attempt,
            "engine": spec.engine,
            "prompt_id": prompt_id,
            "status": "error",
            "completed_at": utc_now(),
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "outputs": [],
            "actual_charge": 0,
            "error": sanitized_error(exc),
        }
        atomic_json(JOBS_PATH, jobs)
        raise


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workflows", nargs="+", help="API workflow JSON files, directories, or glob patterns")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--comfy-input-dir", type=Path, default=DEFAULT_INPUT_DIR)
    parser.add_argument("--input-retries", type=int, default=5)
    parser.add_argument("--timeout", type=float, default=1800, help="per-workflow timeout in seconds")
    parser.add_argument("--poll", type=float, default=2.0, help="history poll interval in seconds")
    parser.add_argument("--resume", action="store_true", help="skip matching completed jobs and resume queued jobs")
    parser.add_argument("--dry-run", action="store_true", help="validate and print the plan without contacting ComfyUI")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    try:
        base_url = validate_base_url(args.base_url)
        if args.timeout <= 0 or args.poll <= 0:
            raise RunnerError("--timeout and --poll must be positive")
        if args.input_retries < 1:
            raise RunnerError("--input-retries must be positive")
        paths = expand_workflows(args.workflows)
        specs = [load_spec(path) for path in paths]
        jobs = load_jobs()
        plan = summarize(specs, jobs, args.resume)
        inputs, aliases, input_hashes = sync_inputs(
            specs,
            args.comfy_input_dir,
            execute=not args.dry_run,
            retries=args.input_retries,
        )
        if args.dry_run:
            print(json.dumps({"base_url": base_url, "workflow_count": len(plan), "inputs": inputs, "plan": plan}, indent=2))
            return
        for spec in specs:
            execute(spec, jobs, base_url, args.timeout, args.poll, args.resume, aliases, input_hashes)
    except (RunnerError, OSError, ValueError) as exc:
        print(f"error: {sanitized_error(exc)}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
