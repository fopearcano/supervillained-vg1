"""Stage validated sprite sheets into public/sprites without touching other assets."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
SOURCE = WORK / "runtime"
TARGET = REPO / "public" / "sprites"
PLAIN_VALIDATION = WORK / "metadata" / "validation.json"
COSTUME_VALIDATION = WORK / "metadata" / "costume-validation.json"
ASSETS = {
    "zampano.png": (160, 3200),
    "zampano-tired.png": (80, 320),
    "zampanoCross.png": (160, 3200),
    "zampanoCross-tired.png": (80, 320),
    "zampanoKnight.png": (160, 3200),
    "zampanoKnight-tired.png": (80, 320),
}
PRESERVE = {"bagnaskiz.png", "sbrimbrulon.png", "jack.png", "watson.png", "confusione.png"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    plain = json.loads(PLAIN_VALIDATION.read_text(encoding="utf-8"))
    costume = json.loads(COSTUME_VALIDATION.read_text(encoding="utf-8"))
    if not plain.get("passed") or not costume.get("passed"):
        raise ValueError("runtime staging requires passing plain and costume validation")
    preserved_before = {name: digest(TARGET / name) for name in PRESERVE if (TARGET / name).exists()}
    if set(preserved_before) != PRESERVE:
        raise FileNotFoundError("accepted supporting sheets are incomplete")
    TARGET.mkdir(parents=True, exist_ok=True)
    records: dict[str, object] = {}
    for name, expected_size in ASSETS.items():
        source = SOURCE / name
        if not source.exists() or Image.open(source).size != expected_size:
            raise ValueError(f"invalid staged source {name}")
        shutil.copy2(source, TARGET / name)
        if digest(source) != digest(TARGET / name):
            raise ValueError(f"hash mismatch staging {name}")
        records[name] = {"size": list(expected_size), "sha256": digest(source)}
    preserved_after = {name: digest(TARGET / name) for name in PRESERVE}
    if preserved_after != preserved_before:
        raise ValueError("supporting sheets changed during staging")
    report = {
        "passed": True,
        "runtime_assets": records,
        "preserved_supporting_sheets": preserved_after,
        "target": "public/sprites",
    }
    (WORK / "metadata" / "runtime-staging.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("staged 6 validated Zampano sheets; preserved 5 supporting sheets")


if __name__ == "__main__":
    main()

