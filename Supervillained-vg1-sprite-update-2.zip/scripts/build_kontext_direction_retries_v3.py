"""Build NE and optional standing-S Kontext attempt-3 workflows."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WF = WORK / "workflows"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
E_REF = WORK / "canonical-inputs" / "zampano_E_v1_sdxl_640.png"
N_REF = WORK / "canonical-inputs" / "zampano_N_kontext_v1_sdxl_640.png"
FRONT_REF = REPO / "sprites-out" / "zampano" / "workflows" / "input" / "zampano_front_clean_sdxl_640.png"
S_GUIDE = WORK / "guides" / "update2_local_zampano_S_canonical_set-v1_sdxl_640.png"

SPECS = {
    "NE": {
        "seed": 611172820003,
        "refs": (N_REF, E_REF),
        "prompt": (
            "Starting primarily from the accepted rear-view dog in the FIRST reference, rotate only "
            "slightly toward his right into a strict rear three-quarter NE view facing upper-right. "
            "Most of the back must remain visible; show only a small right-side muzzle sliver pointing "
            "right. Never produce a left-facing or pure side-profile dog. Keep the exact compact low "
            "Maltese body, four-paw standing pose, very long shaggy coat, thick curled tail, short legs, "
            "and large rounded ears hanging down. No upright/pointed/triangular ears, sitting, shadow, "
            "props, text, red, orange or purple. Exact pale ivory, blue-gray and dark teal hard pixels "
            "on solid chroma green."
        ),
    },
    "S": {
        "seed": 611172840003,
        "refs": (FRONT_REF, S_GUIDE),
        "prompt": (
            "Create the exact same shaggy white Maltese in a strict symmetrical front S view, STANDING "
            "upright on all four clearly separated paws. Use the first reference for the source identity "
            "and large rounded floppy ears; use the second only for the grounded standing geometry. Never "
            "sit, crouch, hide paws, or make ears upright, pointed, triangular or corgi-like. Preserve the "
            "compact low body, long shaggy coat, short legs, pale ivory/blue-gray/dark-teal hard-pixel "
            "palette and full centered body on solid chroma green. No shadow, props, collar, tongue, text, "
            "red, orange or purple."
        ),
    },
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nodes(w: dict[str, object], t: str) -> list[dict[str, object]]:
    return [n for n in w["nodes"] if n.get("type") == t]


def prompt_node(w: dict[str, object]) -> dict[str, object]:
    return next(n for n in w["nodes"] if isinstance(n.get("widgets_values"), list) and len(n["widgets_values"]) >= 6 and isinstance(n["widgets_values"][1], str) and "flux1-dev-kontext" in n["widgets_values"][1])


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    manifest["requests"].setdefault("canonical/NE/kontext-attempt-2", {}).update(
        {"status": "failed_visual_review", "prompt_id": "34814a71...", "failure_reason": "Still faces left/profile; rear-3/4 and muzzle-right direction fail.", "actual_charge": 0}
    )
    manifest["requests"].setdefault("canonical/SE/kontext-attempt-2", {}).update(
        {"status": "accepted_candidate", "prompt_id": "9621a02a...", "accepted_output": "sprites-out/update2-local/raw/canonical/SE/kontext-attempt-2/9621a02a_000.png", "notes": "Usable standing front-right floppy-ear candidate; requires cleanup.", "actual_charge": 0}
    )
    manifest["requests"].setdefault("canonical/S/kontext-attempt-2", {}).update(
        {"status": "accepted_static_candidate", "prompt_id": "662e31e5...", "accepted_output": "sprites-out/update2-local/raw/canonical/S/kontext-attempt-2/662e31e5_000.png", "notes": "Excellent source identity/front/floppy ears but sitting; retain unless standing attempt 3 improves.", "actual_charge": 0}
    )
    for direction, spec in SPECS.items():
        source = WF / f"zampano_canonical_{direction}_kontext_attempt-2.json"
        workflow = copy.deepcopy(json.loads(source.read_text(encoding="utf-8")))
        refs = spec["refs"]
        for ref in refs:
            if not ref.exists():
                raise FileNotFoundError(ref)
        for node, ref in zip(nodes(workflow, "LoadImage"), refs):
            node["widgets_values"][0] = ref.name
        edit = prompt_node(workflow)
        edit["widgets_values"][0] = spec["prompt"]
        edit["widgets_values"][5] = spec["seed"]
        nodes(workflow, "SaveImage")[0]["widgets_values"][0] = f"update2-local-kontext/canonical_{direction}_attempt-3"
        out = WF / f"zampano_canonical_{direction}_kontext_attempt-3.json"
        out.write_text(json.dumps(workflow, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        manifest["requests"][f"canonical/{direction}/kontext-attempt-3"] = {
            "engine": "local-flux-kontext", "direction": direction, "attempt": 3,
            "seed": spec["seed"], "prompt": spec["prompt"],
            "reference_images": [ref.name for ref in refs],
            "reference_sha256": [digest(ref) for ref in refs],
            "workflow": str(out.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": digest(out), "status": "planned", "prompt_id": None, "actual_charge": 0,
        }
        print(out)
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

