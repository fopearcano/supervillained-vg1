"""Finalize the accepted attempt-2 E appearance into a native canonical sprite."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


WORK = Path(__file__).resolve().parent.parent
RAW = WORK / "raw" / "canonical" / "E" / "shaggy-sdxl-attempt-2" / "2e39f0b0_000.png"
NATIVE = WORK / "canonical-native" / "zampano_E_v1.png"
INPUTS = WORK / "canonical-inputs"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")
PALETTE = np.asarray(
    [(254, 249, 235), (166, 192, 191), (61, 92, 93), (204, 216, 210), (3, 40, 43), (3, 25, 27), (172, 196, 195), (2, 33, 35)],
    dtype=np.int32,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def largest(mask: np.ndarray) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    return labels == (1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA])))


def main() -> None:
    rgb = np.asarray(Image.open(RAW).convert("RGB"))
    r, g, b = (rgb[:, :, index].astype(np.int16) for index in range(3))
    chroma = (g > 105) & (g > r * 1.25) & (g > b * 1.25)
    mask = largest(~chroma)
    ys, xs = np.nonzero(mask)
    box = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
    x0, y0, x1, y1 = box
    crop_rgb, crop_mask = rgb[y0:y1, x0:x1].copy(), mask[y0:y1, x0:x1]

    # Remove source contamination before palette projection. These pixels are
    # recolored from their nearest non-contaminated neighbor rather than kept
    # as purple/red tongue or outline colors.
    cr, cg, cb = (crop_rgb[:, :, index].astype(np.int16) for index in range(3))
    contaminated = crop_mask & (((cb > cr * 1.12) & (cb > cg * 1.08)) | ((cr > cg * 1.35) & (cr > cb * 1.2)))
    if contaminated.any():
        clean = crop_mask & ~contaminated
        # Palette quantization below is the authoritative recolor; use pale fur
        # here so contaminated pixels cannot bias the result.
        crop_rgb[contaminated] = (204, 216, 210)

    factor = 9
    native_size = 40 * factor
    rgb_canvas = Image.new("RGB", (native_size, native_size), (0, 255, 0))
    mask_canvas = Image.new("L", (native_size, native_size), 0)
    px = (native_size - crop_rgb.shape[1]) // 2
    py = 36 * factor - (crop_rgb.shape[0] - 1)
    crop_image = Image.fromarray(crop_rgb, "RGB")
    crop_alpha = Image.fromarray(crop_mask.astype(np.uint8) * 255, "L")
    rgb_canvas.paste(crop_image, (px, py), crop_alpha)
    mask_canvas.paste(crop_alpha, (px, py))
    small_rgb = np.asarray(rgb_canvas.resize((40, 40), Image.Resampling.NEAREST))
    small_mask = np.asarray(mask_canvas.resize((40, 40), Image.Resampling.NEAREST)) > 0
    colors = np.zeros_like(small_rgb)
    pixels = small_rgb[small_mask].astype(np.int32)
    distance = ((pixels[:, None, :] - PALETTE[None, :, :]) ** 2).sum(axis=2)
    colors[small_mask] = PALETTE[np.argmin(distance, axis=1)].astype(np.uint8)
    native = Image.fromarray(np.dstack((colors, small_mask.astype(np.uint8) * 255)), "RGBA")
    NATIVE.parent.mkdir(parents=True, exist_ok=True)
    native.save(NATIVE)

    INPUTS.mkdir(parents=True, exist_ok=True)
    wan = Image.new("RGB", (832, 480), (0, 255, 0))
    scaled = native.resize((400, 400), Image.Resampling.NEAREST)
    wan.paste(scaled.convert("RGB"), (216, 40), scaled.getchannel("A"))
    wan_path = INPUTS / "zampano_E_v1_wan_832x480.png"
    wan.save(wan_path)
    sdxl = Image.new("RGB", (640, 640), (0, 255, 0))
    scaled = native.resize((640, 640), Image.Resampling.NEAREST)
    sdxl.paste(scaled.convert("RGB"), (0, 0), scaled.getchannel("A"))
    sdxl_path = INPUTS / "zampano_E_v1_sdxl_640.png"
    sdxl.save(sdxl_path)
    shutil.copy2(wan_path, COMFY_INPUT / wan_path.name)
    shutil.copy2(sdxl_path, COMFY_INPUT / sdxl_path.name)

    rgba = np.asarray(native)
    ys, xs = np.nonzero(rgba[:, :, 3])
    report = {
        "version": "v1",
        "direction": "E",
        "accepted_source": str(RAW.relative_to(WORK)).replace("\\", "/"),
        "accepted_source_sha256": digest(RAW),
        "raw_bbox": list(box),
        "integer_reduction_factor": factor,
        "native_path": str(NATIVE.relative_to(WORK)).replace("\\", "/"),
        "native_sha256": digest(NATIVE),
        "native_bbox": [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1],
        "native_width": int(xs.max()) - int(xs.min()) + 1,
        "anchor": [20, 36],
        "palette": ["#%02x%02x%02x" % tuple(color) for color in PALETTE],
        "alpha_values": [int(value) for value in np.unique(rgba[:, :, 3])],
        "hidden_rgb_zero": bool(np.all(rgba[rgba[:, :, 3] == 0, :3] == 0)),
        "wan_input": str(wan_path.relative_to(WORK)).replace("\\", "/"),
        "sdxl_input": str(sdxl_path.relative_to(WORK)).replace("\\", "/"),
    }
    path = WORK / "metadata" / "canonical-manifest.json"
    path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

