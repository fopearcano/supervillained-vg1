"""Build Cross and Knight sheets deterministically on the accepted plain body."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from PIL import Image


WORK = Path(__file__).resolve().parent.parent
CONFIG = json.loads((WORK / "config" / "actions.json").read_text(encoding="utf-8"))
PLAIN = WORK / "frames"
CROSS = WORK / "frames-cross"
KNIGHT = WORK / "frames-knight"
RUNTIME = WORK / "runtime"
AUTHORED = ("N", "NE", "E", "SE", "S")
DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
MIRRORS = {"NW": "NE", "W": "E", "SW": "SE"}
MAIN = ("idle", "walk", "run", "sniff", "pee", "poop", "eat", "bark", "fetch", "hurt")

RED = (212, 36, 36, 255)
DARK_RED = (132, 24, 28, 255)
TABARD = (244, 241, 232, 255)
STEEL = (170, 180, 196, 255)
STEEL_DARK = (90, 96, 112, 255)
STEEL_LIGHT = (228, 236, 244, 255)
BALL_COLORS = ((220, 242, 58), (152, 180, 24))


def mask_for(rgba: np.ndarray, action: str) -> np.ndarray:
    mask = rgba[:, :, 3] > 0
    if action == "fetch":
        ball = np.zeros(mask.shape, dtype=bool)
        for color in BALL_COLORS:
            ball |= np.all(rgba[:, :, :3] == color, axis=2)
        mask &= ~ball
    return mask


def bounds(mask: np.ndarray) -> tuple[int, int, int, int]:
    ys, xs = np.nonzero(mask)
    if not len(xs):
        raise ValueError("empty body mask")
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def nearest(mask: np.ndarray, x: int, y: int) -> tuple[int, int]:
    ys, xs = np.nonzero(mask)
    index = int(np.argmin((xs - x) ** 2 + (ys - y) ** 2))
    return int(xs[index]), int(ys[index])


def torso(mask: np.ndarray) -> tuple[int, int]:
    x0, y0, x1, y1 = bounds(mask)
    return (x0 + x1 - 1) // 2, y0 + round((y1 - y0) * 0.55)


def paint_cross(rgba: np.ndarray, allowed: np.ndarray, center: tuple[int, int]) -> None:
    cx, cy = nearest(allowed, *center)
    pixels: list[tuple[int, int]] = []
    for dx, dy in ((0, -2), (0, -1), (0, 0), (0, 1), (0, 2), (-2, -1), (-1, -1), (1, -1), (2, -1)):
        x, y = cx + dx, cy + dy
        if 0 <= x < 40 and 0 <= y < 40 and allowed[y, x]:
            rgba[y, x] = RED
            pixels.append((x, y))
    for x, y in pixels:
        if x + 1 < 40 and y + 1 < 40 and allowed[y + 1, x + 1] and tuple(rgba[y + 1, x + 1]) != RED:
            rgba[y + 1, x + 1] = DARK_RED


def cross_frame(plain: Image.Image, action: str) -> Image.Image:
    rgba = np.asarray(plain.convert("RGBA")).copy()
    body = mask_for(rgba, action)
    paint_cross(rgba, body, torso(body))
    rgba[:, :, 3] = np.asarray(plain.getchannel("A"))
    return Image.fromarray(rgba, "RGBA")


def knight_frame(plain: Image.Image, action: str, direction: str) -> Image.Image:
    rgba = np.asarray(plain.convert("RGBA")).copy()
    body = mask_for(rgba, action)
    x0, y0, x1, y1 = bounds(body)
    ys, xs = np.indices(body.shape)
    center = (x0 + x1 - 1) / 2
    half = max(3, round((x1 - x0) * (0.18 if direction not in ("N", "S") else 0.25)))
    tabard = (
        body
        & (ys >= y0 + round((y1 - y0) * 0.38))
        & (ys <= y0 + round((y1 - y0) * 0.78))
        & (np.abs(xs - center) <= half)
    )
    rgba[tabard] = TABARD
    paint_cross(rgba, tabard, torso(body))

    cx = (x0 + x1 - 1) // 2 if direction in ("N", "S") else x0 + round((x1 - x0) * 0.72)
    slip = 2 if action in ("sniff", "eat") else 0
    top = max(0, y0 - 2 + slip)
    width, height = (13, 11) if direction not in ("N", "S") else (12, 11)
    left = max(0, min(40 - width, cx - width // 2))
    right, bottom = left + width, min(40, top + height)
    for y in range(top, bottom):
        inset = 2 if y == top else 1 if y in (top + 1, bottom - 1) else 0
        for x in range(left + inset, right - inset):
            edge = x in (left + inset, right - inset - 1) or y in (top, bottom - 1)
            rgba[y, x] = STEEL_DARK if edge else STEEL
    slit_y = min(bottom - 2, top + (6 if slip else 5))
    for x in range(left + 2, right - 2):
        rgba[slit_y, x] = STEEL_DARK
    for x in range(left + 3, right - 3):
        rgba[min(bottom - 2, top + 2), x] = STEEL_LIGHT
    return Image.fromarray(rgba, "RGBA")


def target_bottom(action: str, phase: int) -> int:
    return 34 if action in ("run", "fetch") and phase == 2 else 36


def mirror(image: Image.Image, action: str, phase: int) -> Image.Image:
    flipped = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    rgba = np.asarray(flipped)
    x0, _, x1, y1 = bounds(mask_for(rgba, action))
    center = (x0 + x1 - 1) / 2
    if center < 19.5:
        dx = math.ceil(19.5 - center)
    elif center > 20.0:
        dx = math.floor(20.0 - center)
    else:
        dx = 0
    dy = target_bottom(action, phase) - (y1 - 1)
    result = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    result.alpha_composite(flipped, (dx, dy))
    return result


def assemble(folder: Path, main_name: str, tired_name: str) -> None:
    main = Image.new("RGBA", (160, 3200), (0, 0, 0, 0))
    row = 0
    for action in MAIN:
        for direction in DIRECTIONS:
            for phase in range(int(CONFIG[action]["frames"])):
                main.alpha_composite(Image.open(folder / f"{action}_{direction}_{phase}.png"), (phase * 40, row * 40))
            row += 1
    main.save(RUNTIME / main_name)
    tired = Image.new("RGBA", (80, 320), (0, 0, 0, 0))
    for row, direction in enumerate(DIRECTIONS):
        for phase in range(2):
            tired.alpha_composite(Image.open(folder / f"tired_{direction}_{phase}.png"), (phase * 40, row * 40))
    tired.save(RUNTIME / tired_name)


def validate() -> None:
    failures: list[str] = []
    reds = {RED[:3], DARK_RED[:3]}
    steels = {STEEL[:3], STEEL_DARK[:3], STEEL_LIGHT[:3]}
    for action, data in CONFIG.items():
        for direction in DIRECTIONS:
            for phase in range(int(data["frames"])):
                name = f"{action}_{direction}_{phase}.png"
                plain = np.asarray(Image.open(PLAIN / name).convert("RGBA"))
                cross = np.asarray(Image.open(CROSS / name).convert("RGBA"))
                knight = np.asarray(Image.open(KNIGHT / name).convert("RGBA"))
                pa, ca, ka = plain[:, :, 3] > 0, cross[:, :, 3] > 0, knight[:, :, 3] > 0
                if not np.array_equal(pa, ca):
                    failures.append(f"{name}: cross alpha")
                if not ({tuple(color) for color in cross[:, :, :3][ca]} & reds):
                    failures.append(f"{name}: cross color")
                outside_colors = {tuple(color) for color in knight[:, :, :3][ka & ~pa]}
                if outside_colors and not outside_colors <= steels:
                    failures.append(f"{name}: non-helm extension")
                colors = {tuple(color) for color in knight[:, :, :3][ka]}
                if TABARD[:3] not in colors or not colors & reds or not colors & steels:
                    failures.append(f"{name}: knight colors")
    report = {"passed": not failures, "failures": failures}
    (WORK / "metadata" / "costume-validation.json").write_text(json.dumps(report, indent=2) + "\n")
    if failures:
        raise ValueError(f"costume validation failed: {len(failures)}")


def main() -> None:
    missing = [
        f"{action}_{direction}_{phase}.png"
        for action, data in CONFIG.items()
        for direction in DIRECTIONS
        for phase in range(int(data["frames"]))
        if not (PLAIN / f"{action}_{direction}_{phase}.png").exists()
    ]
    if missing:
        raise FileNotFoundError(f"plain frames incomplete: {len(missing)} missing")
    for folder in (CROSS, KNIGHT, RUNTIME):
        folder.mkdir(parents=True, exist_ok=True)
    for action, data in CONFIG.items():
        for direction in AUTHORED:
            for phase in range(int(data["frames"])):
                plain = Image.open(PLAIN / f"{action}_{direction}_{phase}.png").convert("RGBA")
                cross_frame(plain, action).save(CROSS / f"{action}_{direction}_{phase}.png")
                knight_frame(plain, action, direction).save(KNIGHT / f"{action}_{direction}_{phase}.png")
        for target, source in MIRRORS.items():
            for phase in range(int(data["frames"])):
                mirror(Image.open(CROSS / f"{action}_{source}_{phase}.png"), action, phase).save(CROSS / f"{action}_{target}_{phase}.png")
                mirror(Image.open(KNIGHT / f"{action}_{source}_{phase}.png"), action, phase).save(KNIGHT / f"{action}_{target}_{phase}.png")
    assemble(CROSS, "zampanoCross.png", "zampanoCross-tired.png")
    assemble(KNIGHT, "zampanoKnight.png", "zampanoKnight-tired.png")
    validate()


if __name__ == "__main__":
    main()

