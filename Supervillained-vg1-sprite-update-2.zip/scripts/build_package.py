"""Build the final review ZIP after all assets and QA gates pass."""

from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

from PIL import Image


WORK = Path(__file__).resolve().parent.parent
REPO = Path(__file__).resolve().parents[3]
OUTPUT = REPO.parent / "Supervillained-vg1-sprite-update-2.zip"
UPDATE1 = REPO / "sprites-out" / "update2" / "source-main" / "update1" / "Supervillained-vg1-sprite-update" / "runtime" / "public" / "sprites"
ZAMPANO = (
    "zampano.png",
    "zampano-tired.png",
    "zampanoCross.png",
    "zampanoCross-tired.png",
    "zampanoKnight.png",
    "zampanoKnight-tired.png",
)
SUPPORTING = ("bagnaskiz.png", "sbrimbrulon.png", "jack.png", "watson.png", "confusione.png")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_tree(source: Path, destination: Path) -> None:
    if source.exists():
        shutil.copytree(source, destination, dirs_exist_ok=True)


def main() -> None:
    validation_path = WORK / "metadata" / "validation.json"
    costume_path = WORK / "metadata" / "costume-validation.json"
    if not validation_path.exists() or not costume_path.exists():
        raise FileNotFoundError("validation reports are incomplete")
    validation = json.loads(validation_path.read_text(encoding="utf-8"))
    costume = json.loads(costume_path.read_text(encoding="utf-8"))
    if not validation.get("passed") or not costume.get("passed"):
        raise ValueError("refusing to package failed validation")
    missing = [name for name in ZAMPANO if not (WORK / "runtime" / name).exists()]
    missing += [name for name in SUPPORTING if not (UPDATE1 / name).exists()]
    if missing:
        raise FileNotFoundError(f"runtime assets missing: {missing}")
    screenshots = list((WORK / "previews" / "in-game").glob("*.png"))
    if not screenshots:
        raise FileNotFoundError("in-game screenshots are required before packaging")

    with tempfile.TemporaryDirectory(prefix="package-", dir=WORK) as temp:
        root = Path(temp) / "Supervillained-vg1-sprite-update-2"
        sprites = root / "runtime" / "public" / "sprites"
        sprites.mkdir(parents=True)
        for name in ZAMPANO:
            shutil.copy2(WORK / "runtime" / name, sprites / name)
        for name in SUPPORTING:
            shutil.copy2(UPDATE1 / name, sprites / name)

        copy_tree(WORK / "frames", root / "maintenance-frames" / "plain")
        copy_tree(WORK / "frames-cross", root / "maintenance-frames" / "cross")
        copy_tree(WORK / "frames-knight", root / "maintenance-frames" / "knight")
        copy_tree(WORK / "previews", root / "previews")
        copy_tree(WORK / "workflows", root / "workflows" / "comfyui")
        copy_tree(WORK / "scripts", root / "workflows" / "scripts")
        copy_tree(WORK / "guides", root / "workflows" / "guides")
        copy_tree(WORK / "canonical-native", root / "workflows" / "canonical-native")

        metadata = root / "metadata"
        metadata.mkdir(parents=True)
        for name in (
            "generation-manifest.json",
            "canonical-manifest.json",
            "pose-guide-manifest.json",
            "selections.json",
            "pose-selections.json",
            "validation.json",
            "costume-validation.json",
        ):
            source = WORK / "metadata" / name
            if source.exists():
                shutil.copy2(source, metadata / name)

        assets: dict[str, object] = {"assets": {}, "retro_diffusion_spend_usd": 0}
        for path in sorted(sprites.glob("*.png")):
            image = Image.open(path)
            assets["assets"][path.name] = {
                "width": image.width,
                "height": image.height,
                "sha256": digest(path),
            }
        (metadata / "app-assets.json").write_text(json.dumps(assets, indent=2) + "\n", encoding="utf-8")

        reports = root / "reports"
        reports.mkdir(parents=True)
        shutil.copy2(WORK / "README.md", reports / "LOCAL-PIPELINE.md")
        integration = (
            "# SUPERVILLAINED sprite update 2\n\n"
            "Generated locally with Wan 2.2 Pixel Animate and SDXL/IP-Adapter/Canny. "
            "Retro Diffusion spend: $0.00.\n\n"
            "Copy `runtime/public/sprites/` into the game repository. The accompanying "
            "repository diff adds the sheet mappings, separate tired sheets, tired behavior, "
            "and ART NEW/OLD option. Run `npm test`, `npm run build`, `npm run smoke`, and "
            "`npm run playtest` after integration.\n"
        )
        (root / "README-INTEGRATION.md").write_text(integration, encoding="utf-8")

        sums: list[str] = []
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            sums.append(f"{digest(path)}  {path.relative_to(root).as_posix()}")
        (metadata / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

        with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(item for item in root.rglob("*") if item.is_file()):
                archive.write(path, path.relative_to(root).as_posix())
    print(OUTPUT)


if __name__ == "__main__":
    main()

