"""Create C:-only raw and native review contacts without loading ComfyUI."""

from __future__ import annotations

import argparse
from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
RAW = WORK / "raw"
OUT = WORK / "previews" / "batch-review"
DIRECTIONS = ("N", "NE", "E", "SE", "S")
POSE_ACTIONS = ("idle", "sniff", "pee", "poop", "eat", "bark", "hurt", "tired")
WAN_ACTIONS = ("walk", "run", "fetch")
PALETTE = np.asarray(
    [(254, 249, 235), (166, 192, 191), (61, 92, 93), (204, 216, 210), (3, 40, 43), (3, 25, 27), (172, 196, 195), (2, 33, 35)],
    dtype=np.int32,
)


def pose_path(action: str, direction: str, phase: int) -> Path | None:
    folder = RAW / action / direction / "sdxl-attempt-2" / f"phase-{phase}"
    paths = sorted(folder.glob("*.png"))
    return paths[0] if paths else None


def native_preview(path: Path) -> Image.Image:
    image = Image.open(path).convert("RGB")
    if image.size != (640, 640):
        raise ValueError(f"expected SDXL 640x640 output: {path} -> {image.size}")
    rgb = np.asarray(image.resize((40, 40), Image.Resampling.NEAREST)).copy()
    r, g, b = (rgb[:, :, index].astype(np.int16) for index in range(3))
    chroma = (g > 105) & (g > r * 1.25) & (g > b * 1.25)
    foreground = ~chroma
    colors = np.zeros_like(rgb, dtype=np.uint8)
    pixels = rgb[foreground].astype(np.int32)
    if len(pixels):
        distances = ((pixels[:, None, :] - PALETTE[None, :, :]) ** 2).sum(axis=2)
        colors[foreground] = PALETTE[np.argmin(distances, axis=1)].astype(np.uint8)
    return Image.fromarray(np.dstack((colors, foreground.astype(np.uint8) * 255)), "RGBA")


def largest_component(mask: np.ndarray) -> np.ndarray:
    height, width = mask.shape
    remaining = {int(y) * width + int(x) for y, x in np.argwhere(mask)}
    best: set[int] = set()
    while remaining:
        start = remaining.pop()
        component = {start}
        queue = deque((start,))
        while queue:
            value = queue.popleft()
            y, x = divmod(value, width)
            for neighbor in (value - width, value + width, value - 1, value + 1):
                ny, nx = divmod(neighbor, width)
                if 0 <= ny < height and 0 <= nx < width and abs(nx - x) + abs(ny - y) == 1 and neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    queue.append(neighbor)
        if len(component) > len(best):
            best = component
    output = np.zeros(mask.shape, dtype=bool)
    if best:
        values = np.fromiter(best, dtype=np.int64)
        output[values // width, values % width] = True
    return output


def native_wan(path: Path, direction: str, action: str = "walk") -> Image.Image:
    rgb = np.asarray(Image.open(path).convert("RGB"))
    r, g, b = (rgb[:, :, index].astype(np.int16) for index in range(3))
    chroma = (g > 105) & (g > r * 1.25) & (g > b * 1.25)
    foreground = ~chroma
    ball = np.zeros(chroma.shape, dtype=bool)
    if action == "fetch":
        ball = foreground & (r > 95) & (g > 105) & (b < 145) & (g > b * 1.35)
    dog = largest_component(foreground & ~ball)
    union = dog | ball
    ys, xs = np.nonzero(union)
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    crop_rgb = rgb[y0:y1, x0:x1]
    crop_dog = dog[y0:y1, x0:x1]
    crop_ball = ball[y0:y1, x0:x1]
    target_width = 36 if direction == "E" else 33 if direction in ("NE", "SE") else 30
    factor = max(6, min(16, round(crop_dog.shape[1] / target_width)))
    factor = max(factor, (max(crop_dog.shape) + 39) // 40)
    native_size = 40 * factor
    canvas_rgb = Image.new("RGB", (native_size, native_size), (0, 255, 0))
    canvas_mask = Image.new("L", (native_size, native_size), 0)
    dog_alpha = Image.fromarray(crop_dog.astype(np.uint8) * 255, "L")
    ball_alpha = Image.fromarray(crop_ball.astype(np.uint8) * 255, "L")
    alpha = Image.fromarray((crop_dog | crop_ball).astype(np.uint8) * 255, "L")
    px = (native_size - crop_rgb.shape[1]) // 2
    py = max(0, 36 * factor - (crop_rgb.shape[0] - 1))
    canvas_rgb.paste(Image.fromarray(crop_rgb, "RGB"), (px, py), alpha)
    canvas_mask.paste(dog_alpha, (px, py))
    canvas_ball = Image.new("L", (native_size, native_size), 0)
    canvas_ball.paste(ball_alpha, (px, py))
    small_rgb = np.asarray(canvas_rgb.resize((40, 40), Image.Resampling.NEAREST))
    foreground = np.asarray(canvas_mask.resize((40, 40), Image.Resampling.NEAREST)) > 0
    small_ball = np.asarray(canvas_ball.resize((40, 40), Image.Resampling.NEAREST)) > 0
    colors = np.zeros_like(small_rgb, dtype=np.uint8)
    pixels = small_rgb[foreground].astype(np.int32)
    if len(pixels):
        distances = ((pixels[:, None, :] - PALETTE[None, :, :]) ** 2).sum(axis=2)
        colors[foreground] = PALETTE[np.argmin(distances, axis=1)].astype(np.uint8)
    if action == "fetch" and small_ball.any():
        small_rgb = np.asarray(canvas_rgb.resize((40, 40), Image.Resampling.NEAREST))
        luminosity = small_rgb[small_ball].astype(np.int32).sum(axis=1)
        threshold = int(np.median(luminosity))
        colors[small_ball] = (152, 180, 24)
        for y, x in np.argwhere(small_ball)[luminosity >= threshold]:
            colors[y, x] = (220, 242, 58)
    output_alpha = (foreground | small_ball).astype(np.uint8) * 255
    return Image.fromarray(np.dstack((colors, output_alpha)), "RGBA")


def pose_contacts(action: str) -> bool:
    paths = {(direction, phase): pose_path(action, direction, phase) for direction in DIRECTIONS for phase in range(2)}
    complete = all(paths.values())
    raw_cell = 220
    raw = Image.new("RGB", (len(DIRECTIONS) * raw_cell, 2 * raw_cell), (24, 24, 24))
    native = Image.new("RGBA", (len(DIRECTIONS) * 160, 2 * 160), (0, 0, 0, 0))
    raw_draw = ImageDraw.Draw(raw)
    native_draw = ImageDraw.Draw(native)
    for column, direction in enumerate(DIRECTIONS):
        for phase in range(2):
            path = paths[(direction, phase)]
            if path:
                thumb = Image.open(path).convert("RGB").resize((raw_cell, raw_cell), Image.Resampling.NEAREST)
                raw.paste(thumb, (column * raw_cell, phase * raw_cell))
                small = native_preview(path).resize((160, 160), Image.Resampling.NEAREST)
                native.alpha_composite(small, (column * 160, phase * 160))
            else:
                raw_draw.rectangle(
                    (column * raw_cell, phase * raw_cell, (column + 1) * raw_cell - 1, (phase + 1) * raw_cell - 1),
                    outline=(220, 40, 40),
                    width=4,
                )
            raw_draw.rectangle((column * raw_cell, phase * raw_cell, (column + 1) * raw_cell - 1, phase * raw_cell + 20), fill=(0, 0, 0))
            raw_draw.text((column * raw_cell + 4, phase * raw_cell + 3), f"{action} {direction} p{phase}", fill=(255, 255, 255))
            native_draw.rectangle((column * 160, phase * 160, (column + 1) * 160 - 1, phase * 160 + 18), fill=(0, 0, 0, 255))
            native_draw.text((column * 160 + 3, phase * 160 + 2), f"{action} {direction} p{phase}", fill=(255, 255, 255, 255))
    OUT.mkdir(parents=True, exist_ok=True)
    raw.save(OUT / f"{action}-raw.png")
    native.save(OUT / f"{action}-native.png")
    return complete


def wan_contacts(action: str) -> int:
    written = 0
    for direction in DIRECTIONS:
        attempt = 3 if direction == "E" and action in ("walk", "run") else 4
        paths = sorted((RAW / action / direction / f"attempt-{attempt}").glob("*.png"))
        if not paths:
            continue
        columns = 5
        cell_w, cell_h = 208, 140
        rows = (len(paths) + columns - 1) // columns
        contact = Image.new("RGB", (columns * cell_w, rows * cell_h), (20, 20, 20))
        native_contact = Image.new("RGBA", (columns * 160, rows * 180), (0, 0, 0, 0))
        draw = ImageDraw.Draw(contact)
        native_draw = ImageDraw.Draw(native_contact)
        for index, path in enumerate(paths):
            thumb = Image.open(path).convert("RGB").resize((cell_w, 120), Image.Resampling.NEAREST)
            x, y = (index % columns) * cell_w, (index // columns) * cell_h
            contact.paste(thumb, (x, y + 20))
            draw.text((x + 4, y + 3), f"{index:02d}", fill=(255, 255, 255))
            native_frame = native_wan(path, direction, action).resize((160, 160), Image.Resampling.NEAREST)
            nx, ny = (index % columns) * 160, (index // columns) * 180
            native_contact.alpha_composite(native_frame, (nx, ny + 20))
            native_draw.rectangle((nx, ny, nx + 159, ny + 19), fill=(0, 0, 0, 255))
            native_draw.text((nx + 4, ny + 3), f"{index:02d}", fill=(255, 255, 255, 255))
        OUT.mkdir(parents=True, exist_ok=True)
        contact.save(OUT / f"{action}-{direction}-raw.png")
        native_contact.save(OUT / f"{action}-{direction}-native.png")
        written += 1
    return written


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--action", action="append")
    args = parser.parse_args()
    requested = set(args.action or POSE_ACTIONS + WAN_ACTIONS)
    completed: list[str] = []
    for action in POSE_ACTIONS:
        if action in requested and pose_contacts(action):
            completed.append(action)
    for action in WAN_ACTIONS:
        if action in requested:
            count = wan_contacts(action)
            if count == len(DIRECTIONS):
                completed.append(action)
    print("complete contacts:", ", ".join(completed) if completed else "none")


if __name__ == "__main__":
    main()

