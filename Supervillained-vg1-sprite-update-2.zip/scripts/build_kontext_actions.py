"""Build one phase-1 Kontext edit per action/direction; phase 0 is canonical."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WORKFLOWS = WORK / "workflows"
INPUTS = WORK / "canonical-inputs"
NATIVE = WORK / "canonical-native"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
KONTEXT_SELECTIONS = WORK / "metadata" / "kontext-selections.json"
TEMPLATE = WORKFLOWS / "zampano_bark_E_kontext_attempt-1.json"
DIRECTIONS = ("N", "NE", "E", "SE", "S")
ACTIONS = ("idle", "sniff", "pee", "poop", "eat", "bark", "hurt", "tired")

VIEWS = {
    "N": "strict rear N view facing directly away; no face or eyes become visible",
    "NE": "strict three-quarter rear NE view facing upper-right and mostly away",
    "E": "strict exact right-facing E side profile with one eye visible",
    "SE": "strict three-quarter front SE view facing lower-right",
    "S": "strict symmetrical front S view facing directly toward the camera",
}

ACTION_EDIT = {
    "idle": "make one subtle breathing/weight-shift pose; move the upper body by only a tiny amount while all four paws remain planted",
    "sniff": "lower the head and nose clearly toward the ground in a sniff pose while the paws and body anchor stay fixed",
    "pee": "lift one rear leg and tilt the hips into a clear tasteful dog urination pose while the other three paws remain grounded",
    "poop": "bend the hind legs, lower the hips and raise the tail into a clear tasteful dog squat pose",
    "eat": "lower the muzzle to the ground and show one clear chewing/eating key pose with no bowl or extra prop",
    "bark": "make one clear bark key pose: thrust the head and shoulders slightly forward/up, open the mouth when visible, and bounce the floppy ears slightly",
    "hurt": "recoil and crouch into one readable non-graphic hurt flinch pose",
    "tired": "lower the head and shoulders into one exhausted panting/breathing pose while every paw stays planted",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def nodes(workflow: dict[str, object], node_type: str) -> list[dict[str, object]]:
    return [node for node in workflow["nodes"] if node.get("type") == node_type]


def prompt_node(workflow: dict[str, object]) -> dict[str, object]:
    found = [
        node
        for node in workflow["nodes"]
        if isinstance(node.get("widgets_values"), list)
        and len(node["widgets_values"]) >= 6
        and isinstance(node["widgets_values"][1], str)
        and "flux1-dev-kontext" in node["widgets_values"][1]
    ]
    if len(found) != 1:
        raise ValueError("expected one Kontext prompt subgraph")
    return found[0]


def prompt(action: str, direction: str) -> str:
    rear_note = " For rear N, communicate the action through head, ears, shoulders, hips and legs without revealing the face." if direction == "N" else ""
    return (
        f"Edit this exact pixel-art Maltese dog into one action frame in {VIEWS[direction]}. "
        f"Only change the action: {ACTION_EDIT[action]}. Preserve the exact same direction, dog "
        "identity, compact low body, very long shaggy white coat, short legs, thick curled tail, "
        "head/body proportions, size, pose anchor, pale ivory and blue-gray colors, dark teal outline, "
        "hard square pixels, orthographic camera and chroma-green background. Keep the same large "
        "rounded floppy ears; never make them upright, pointed, triangular, fox-like or cat-like. "
        "One dog only, complete full body, no breed change, extra limbs, ground, shadow, text, props, "
        "collar, red, orange or purple."
        + rear_note
    )


def seed(action: str, direction: str) -> int:
    return 611173000000 + ACTIONS.index(action) * 1000 + DIRECTIONS.index(direction) * 10 + 1


def main() -> None:
    refs = {direction: INPUTS / f"zampano_{direction}_kontext_v1_sdxl_640.png" for direction in DIRECTIONS}
    natives = {direction: NATIVE / f"zampano_{direction}_kontext_v1.png" for direction in DIRECTIONS}
    missing = [str(path) for path in (*refs.values(), *natives.values()) if not path.exists()]
    if missing:
        raise FileNotFoundError(f"finalize Kontext canonicals first; {len(missing)} files missing")

    template = json.loads(TEMPLATE.read_text(encoding="utf-8"))
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    selections = (
        json.loads(KONTEXT_SELECTIONS.read_text(encoding="utf-8"))
        if KONTEXT_SELECTIONS.exists()
        else {}
    )
    plan: dict[str, object] = {"phase0": {}, "phase1": {}}
    for action in ACTIONS:
        for direction in DIRECTIONS:
            key = f"{action}/{direction}"
            plan["phase0"][key] = {
                "native": str(natives[direction].relative_to(REPO)).replace("\\", "/"),
                "sha256": digest(natives[direction]),
            }
            selections.setdefault(
                key,
                {
                    "phase0_native": str(natives[direction].relative_to(REPO)).replace("\\", "/"),
                    "phase1_attempt": 1,
                    "phase1_index": 0,
                    "reviewed": False,
                    "notes": "",
                },
            )
            if action == "bark" and direction == "E":
                raw = WORK / "raw" / "bark" / "E" / "kontext-attempt-1" / "270704bb_000.png"
                plan["phase1"][key] = {
                    "existing_candidate": str(raw.relative_to(REPO)).replace("\\", "/"),
                    "status": "accepted_candidate" if raw.exists() else "missing",
                }
                manifest["requests"].setdefault("bark/E/kontext-attempt-1", {}).update(
                    {
                        "engine": "local-flux-kontext",
                        "status": "accepted_candidate" if raw.exists() else "missing",
                        "prompt_id": "270704bb...",
                        "notes": "Identity/action candidate accepted; palette drift requires canonical cleanup.",
                        "actual_charge": 0,
                    }
                )
                continue

            workflow = copy.deepcopy(template)
            for node in nodes(workflow, "LoadImage"):
                node["widgets_values"][0] = refs[direction].name
            edit_prompt = prompt(action, direction)
            edit_seed = seed(action, direction)
            subgraph = prompt_node(workflow)
            subgraph["widgets_values"][0] = edit_prompt
            subgraph["widgets_values"][5] = edit_seed
            save = nodes(workflow, "SaveImage")[0]
            save["widgets_values"][0] = f"update2-local-kontext/{action}_{direction}_attempt-1"
            path = WORKFLOWS / f"zampano_{action}_{direction}_kontext_attempt-1.json"
            write_json(path, workflow)
            request_key = f"{action}/{direction}/kontext-attempt-1"
            request = {
                "engine": "local-flux-kontext",
                "action": action,
                "direction": direction,
                "attempt": 1,
                "seed": edit_seed,
                "prompt": edit_prompt,
                "reference_images": [refs[direction].name, refs[direction].name],
                "reference_sha256": digest(refs[direction]),
                "phase0_native": str(natives[direction].relative_to(REPO)).replace("\\", "/"),
                "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
                "workflow_sha256": digest(path),
                "status": "planned",
                "prompt_id": None,
                "actual_charge": 0,
            }
            manifest["requests"][request_key] = request
            plan["phase1"][key] = request

    write_json(MANIFEST, manifest)
    write_json(WORK / "metadata" / "kontext-action-plan.json", plan)
    write_json(KONTEXT_SELECTIONS, selections)
    print("wrote 39 Kontext action workflows; bark/E reuses accepted candidate")


if __name__ == "__main__":
    main()

