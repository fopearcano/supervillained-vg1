"""Build reproducible, local-only Wan workflows for the Zampano sprite rebuild."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image, ImageDraw


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(__file__).resolve().parents[3]
CONFIG = WORK / "config" / "actions.json"
TEMPLATE = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_run_E_wan_pass1_api.json"
ACCEPTED_E = WORK / "canonical-native" / "zampano_E_v1.png"
V2_FRAMES = REPO / "sprites-out" / "zampano" / "v2" / "frames"
CANONICAL = WORK / "canonical"
WORKFLOWS = WORK / "workflows"
METADATA = WORK / "metadata"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")

DIRECTIONS = {
    "N": "rear view facing directly away from the camera",
    "NE": "three-quarter rear view facing upper right",
    "E": "exact right-facing side profile",
    "SE": "three-quarter front view facing lower right",
    "S": "front view facing directly toward the camera",
}

ACTION_ORDER = (
    "idle",
    "walk",
    "run",
    "sniff",
    "pee",
    "poop",
    "eat",
    "bark",
    "fetch",
    "hurt",
    "tired",
)
WAN_ACTIONS = ("walk", "run", "fetch")

NEGATIVE = (
    "camera movement, pan, zoom, rotation, changing direction, changing scale, "
    "changing dog identity, changing breed, morphing, extra dog, duplicate dog, "
    "extra legs, missing legs, pointy upright ears, cat, human, realistic fur, "
    "3D render, smooth vector art, blur, antialiasing, background scenery, floor, "
    "ground, cast shadow, dust, collar, clothing, text, watermark"
)

BASE_SEED = 611172600000


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical_source(direction: str) -> Path:
    return ACCEPTED_E if direction == "E" else V2_FRAMES / f"run_{direction}_0.png"


def canonical_input(direction: str, install: bool) -> tuple[Path, str]:
    source = canonical_source(direction)
    if not source.exists():
        raise FileNotFoundError(source)
    frame = Image.open(source).convert("RGBA")
    if frame.size != (40, 40):
        raise ValueError(f"unexpected canonical reference size: {source} -> {frame.size}")

    scaled = frame.resize((400, 400), Image.Resampling.NEAREST)
    canvas = Image.new("RGB", (832, 480), (0, 255, 0))
    canvas.paste(scaled.convert("RGB"), (216, 40), scaled.getchannel("A"))
    filename = f"update2_local_zampano_{direction}_canonical_set-v1_wan_832x480.png"
    destination = CANONICAL / filename
    destination.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(destination)
    if install:
        COMFY_INPUT.mkdir(parents=True, exist_ok=True)
        shutil.copy2(destination, COMFY_INPUT / filename)
    return destination, filename


def prompt(action: str, action_prompt: str, view: str) -> str:
    ball_clause = (
        " The ball is exactly lime yellow-green with no trail or duplicate ball."
        if action == "fetch"
        else " No props."
    )
    return (
        "A seamless looping pixel art game-sprite animation of one small scruffy white "
        f"fluffy Maltese dog, Zampano, full body in {view}. {action_prompt}. "
        "Preserve the exact floppy-eared breed, long low body, coat markings, proportions, "
        "scale, screen position, lighting and outline in every frame. Locked orthographic "
        "camera, flat solid chroma-green background, no ground, no shadow, no text."
        + ball_clause
    )


def seed_for(action: str, direction: str, attempt: int) -> int:
    return (
        BASE_SEED
        + ACTION_ORDER.index(action) * 1000
        + tuple(DIRECTIONS).index(direction) * 10
        + attempt
    )


def build_workflow(
    template: dict[str, object],
    action: str,
    action_data: dict[str, object],
    direction: str,
    input_name: str,
    attempt: int,
) -> tuple[dict[str, object], int, str]:
    workflow = copy.deepcopy(template)
    seed = seed_for(action, direction, attempt)
    text = prompt(action, str(action_data["prompt"]), DIRECTIONS[direction])
    workflow["2"]["inputs"]["text"] = text
    workflow["3"]["inputs"]["text"] = NEGATIVE
    workflow["5"]["inputs"]["image"] = input_name
    workflow["11"]["inputs"]["noise_seed"] = seed
    workflow["16"]["inputs"]["noise_seed"] = seed
    workflow["18"]["inputs"]["filename_prefix"] = (
        f"update2-local/{action}_{direction}_attempt-{attempt}"
    )
    return workflow, seed, text


def build(batch: str, attempt: int, install_inputs: bool) -> None:
    actions = json.loads(CONFIG.read_text(encoding="utf-8"))
    template = json.loads(TEMPLATE.read_text(encoding="utf-8"))
    selected = (
        (("walk", "E"), ("run", "E"))
        if batch == "pilot"
        else tuple((action, direction) for action in WAN_ACTIONS for direction in DIRECTIONS)
    )

    canonical: dict[str, dict[str, object]] = {}
    for direction in DIRECTIONS:
        path, name = canonical_input(direction, install_inputs)
        source = canonical_source(direction)
        canonical[direction] = {
            "path": str(path.relative_to(REPO)).replace("\\", "/"),
            "filename": name,
            "sha256": sha256(path),
            "reference_source": str(source.relative_to(REPO)).replace("\\", "/"),
            "reference_only": direction != "E",
            "accepted_appearance_canonical": direction == "E",
        }

    manifest_path = METADATA / "generation-manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    else:
        manifest = {
            "pipeline": "local hybrid: Wan 2.2 Pixel Animate for motion and SDXL/IP-Adapter/Canny for pose actions",
            "hosted_services": False,
            "paid_calls": False,
            "models": {
                "high": "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
                "low": "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
                "high_lora": "Wan2.2-I2V-HIGH-4steps-lora-rank64-Seko-V1.safetensors",
                "low_lora": "Wan2.2-I2V-LOW-4steps-lora-rank64-Seko-V1.safetensors",
                "pixel_adapter": "wan2.2_animate_adapter_model.safetensors",
                "text_encoder": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
                "vae": "wan_2.1_vae.safetensors",
            },
            "settings": {
                "width": 832,
                "height": 480,
                "length": 17,
                "steps": 4,
                "cfg": 1.1,
                "sampler": "ddim",
                "scheduler": "simple",
                "shift": 5.0,
            },
            "canonical_inputs": {},
            "requests": {},
        }
    manifest["canonical_inputs"] = canonical

    for action, direction in selected:
        workflow, seed, text = build_workflow(
            template, action, actions[action], direction, canonical[direction]["filename"], attempt
        )
        path = WORKFLOWS / f"zampano_{action}_{direction}_attempt-{attempt}_api.json"
        write_json(path, workflow)
        key = f"{action}/{direction}/attempt-{attempt}"
        manifest["requests"][key] = {
            "action": action,
            "direction": direction,
            "attempt": attempt,
            "seed": seed,
            "prompt": text,
            "negative_prompt": NEGATIVE,
            "input_sha256": canonical[direction]["sha256"],
            "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": sha256(path),
            "output_prefix": f"update2-local/{action}_{direction}_attempt-{attempt}",
            "status": "planned",
            "prompt_id": None,
            "actual_charge": 0,
        }
    write_json(manifest_path, manifest)

    selection_path = METADATA / "selections.json"
    if selection_path.exists():
        selections = json.loads(selection_path.read_text(encoding="utf-8"))
    else:
        selections = {}
    for action, direction in selected:
        key = f"{action}/{direction}"
        selection = selections.setdefault(
            key,
            {
                "attempt": None,
                "indices": None,
                "required_frames": actions[action]["frames"],
                "reviewed": False,
                "notes": "",
            },
        )
        if not selection.get("reviewed"):
            selection["attempt"] = attempt
    write_json(selection_path, selections)
    canonical_contact(canonical)
    print(f"wrote {len(selected)} {batch} workflows; no inference was submitted")


def canonical_contact(canonical: dict[str, dict[str, object]]) -> None:
    scale = 2
    contact = Image.new("RGB", (416 * len(DIRECTIONS), 260), (24, 24, 24))
    draw = ImageDraw.Draw(contact)
    for index, direction in enumerate(DIRECTIONS):
        path = REPO / canonical[direction]["path"]
        image = Image.open(path).convert("RGB").resize((416, 240), Image.Resampling.NEAREST)
        x = index * 416
        contact.paste(image, (x, 20))
        draw.text((x + 6, 3), direction, fill=(255, 255, 255))
    preview = WORK / "previews" / "canonical-inputs.png"
    preview.parent.mkdir(parents=True, exist_ok=True)
    contact.resize((contact.width // scale, contact.height // scale), Image.Resampling.NEAREST).save(
        preview
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch", choices=("pilot", "full"), default="pilot")
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--install-inputs", action="store_true")
    args = parser.parse_args()
    if args.attempt < 1:
        parser.error("--attempt must be >= 1")
    build(args.batch, args.attempt, args.install_inputs)


if __name__ == "__main__":
    main()

