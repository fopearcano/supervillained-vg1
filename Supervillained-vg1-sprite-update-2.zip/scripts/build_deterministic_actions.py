"""Author deterministic two-frame actions from finalized Kontext canonicals.

This fallback never reads the rejected deterministic Update 2 frames. It uses only the
five accepted/normalized Kontext canonical direction bases and hard-pixel operations.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
SOURCE = WORK / "canonical-native"
OUT = WORK / "deterministic-actions"
FRAMES = OUT / "frames"
PREVIEWS = OUT / "previews"
METADATA = OUT / "metadata"
ACTIONS = ("idle", "sniff", "pee", "poop", "eat", "bark", "hurt", "tired")
AUTHORED = ("N", "NE", "E", "SE", "S")
DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
MIRRORS = {"NW": "NE", "W": "E", "SW": "SE"}
FPS = {"idle": 3, "sniff": 5, "pee": 6, "poop": 3, "eat": 8, "bark": 10, "hurt": 10, "tired": 4}
TARGET_WIDTH = {"N": (29, 32), "NE": (32, 35), "E": (34, 38), "SE": (32, 35), "S": (29, 32), "SW": (32, 35), "W": (34, 38), "NW": (32, 35)}
PALETTE = {
    (254, 249, 235), (166, 192, 191), (61, 92, 93), (204, 216, 210),
    (3, 40, 43), (3, 25, 27), (172, 196, 195), (2, 33, 35),
}
DARK = np.asarray((3, 25, 27, 255), dtype=np.uint8)
MID = np.asarray((61, 92, 93, 255), dtype=np.uint8)
LIGHT = np.asarray((204, 216, 210, 255), dtype=np.uint8)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_path(direction: str) -> Path:
    return SOURCE / f"zampano_{direction}_kontext_v1.png"


def load(direction: str) -> np.ndarray:
    path = canonical_path(direction)
    if not path.exists():
        raise FileNotFoundError(path)
    rgba = np.asarray(Image.open(path).convert("RGBA")).copy()
    if rgba.shape != (40, 40, 4):
        raise ValueError(f"bad canonical size: {path}")
    return rgba


def mask(rgba: np.ndarray) -> np.ndarray:
    return rgba[:, :, 3] > 0


def bbox(alpha: np.ndarray) -> tuple[int, int, int, int]:
    ys, xs = np.nonzero(alpha)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def head_mask(rgba: np.ndarray, direction: str) -> np.ndarray:
    alpha = mask(rgba)
    x0, y0, x1, y1 = bbox(alpha)
    ys, xs = np.indices(alpha.shape)
    split_y = y0 + round((y1 - y0) * (0.54 if direction in ("N", "S") else 0.62))
    if direction in ("E", "NE", "SE"):
        split_x = x0 + round((x1 - x0) * 0.43)
        return alpha & (ys <= split_y) & (xs >= split_x)
    return alpha & (ys <= split_y)


def upper_mask(rgba: np.ndarray) -> np.ndarray:
    alpha = mask(rgba)
    _, _, _, y1 = bbox(alpha)
    ys, _ = np.indices(alpha.shape)
    return alpha & (ys < y1 - 6)


def move_region(rgba: np.ndarray, region: np.ndarray, dx: int, dy: int, fill_neck: bool = True) -> np.ndarray:
    out = rgba.copy()
    original = rgba.copy()
    values = original[region].copy()
    points = np.argwhere(region)
    out[region] = 0
    moved = np.zeros(region.shape, dtype=bool)
    for (y, x), value in zip(points, values):
        nx, ny = int(x) + dx, int(y) + dy
        if 0 <= nx < 40 and 0 <= ny < 40:
            out[ny, nx] = value
            moved[ny, nx] = True
    if fill_neck and len(points):
        threshold = int(points[:, 0].min() + (points[:, 0].max() - points[:, 0].min()) * 0.65)
        holes = region & (np.indices(region.shape)[0] >= threshold) & ~(out[:, :, 3] > 0)
        out[holes] = original[holes]
    return out


def reanchor(rgba: np.ndarray) -> np.ndarray:
    alpha = mask(rgba)
    x0, y0, x1, y1 = bbox(alpha)
    center = (x0 + x1 - 1) / 2
    if center < 19.5:
        dx = math.ceil(19.5 - center)
    elif center > 20.0:
        dx = math.floor(20.0 - center)
    else:
        dx = 0
    dy = 36 - (y1 - 1)
    image = Image.fromarray(rgba, "RGBA")
    canvas = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    canvas.alpha_composite(image, (dx, dy))
    return np.asarray(canvas).copy()


def breathe(base: np.ndarray, amount: int = 1) -> np.ndarray:
    original = base.copy()
    result = move_region(base, upper_mask(base), 0, amount, fill_neck=True)
    _, _, _, y1 = bbox(mask(original))
    result[y1 - 6 : y1] = original[y1 - 6 : y1]
    return reanchor(result)


def lower_head(base: np.ndarray, direction: str, amount: int, forward: int = 0) -> np.ndarray:
    dx = forward if direction in ("E", "NE", "SE") else 0
    return reanchor(move_region(base, head_mask(base, direction), dx, amount, fill_neck=True))


def mouth(rgba: np.ndarray, direction: str, open_amount: int = 1) -> np.ndarray:
    out = rgba.copy()
    alpha = mask(out)
    x0, y0, x1, y1 = bbox(alpha)
    if direction == "N":
        return out
    if direction in ("E", "NE", "SE"):
        head = head_mask(out, direction)
        ys, xs = np.nonzero(head)
        y = int(np.median(ys)) + 1
        x = min(38, int(xs.max()))
        out[y, x] = DARK
        if open_amount > 1 and y + 1 < 39:
            out[y + 1, x] = DARK
            if x + 1 < 39:
                out[y + 1, x + 1] = MID
    else:
        x = (x0 + x1 - 1) // 2
        y = y0 + round((y1 - y0) * 0.40)
        out[y, x] = DARK
        if open_amount > 1:
            out[min(38, y + 1), x] = DARK
            out[min(38, y + 1), min(38, x + 1)] = MID
    return reanchor(out)


def lift_rear_leg(base: np.ndarray, direction: str, amount: int) -> np.ndarray:
    out = base.copy()
    alpha = mask(out)
    x0, y0, x1, y1 = bbox(alpha)
    ys, xs = np.indices(alpha.shape)
    if direction in ("E", "NE", "SE"):
        region = alpha & (ys >= y1 - 11) & (xs <= x0 + round((x1 - x0) * 0.42))
        dx = 0
    else:
        region = alpha & (ys >= y1 - 11) & (xs >= (x0 + x1) // 2)
        dx = 1
    result = move_region(out, region, dx, -amount, fill_neck=False)
    return reanchor(result)


def raise_tail(rgba: np.ndarray, direction: str, amount: int) -> np.ndarray:
    if direction not in ("E", "NE", "SE"):
        return rgba
    alpha = mask(rgba)
    x0, y0, x1, y1 = bbox(alpha)
    ys, xs = np.indices(alpha.shape)
    region = alpha & (xs <= x0 + round((x1 - x0) * 0.28)) & (ys <= y0 + round((y1 - y0) * 0.68))
    return reanchor(move_region(rgba, region, 0, -amount, fill_neck=True))


def squat(base: np.ndarray, amount: int) -> np.ndarray:
    return breathe(base, amount)


def recoil(base: np.ndarray, direction: str, amount: int) -> np.ndarray:
    dx = -amount if direction in ("E", "NE", "SE") else 0
    result = move_region(base, upper_mask(base), dx, amount, fill_neck=True)
    return reanchor(result)


def action_pair(base: np.ndarray, action: str, direction: str) -> tuple[np.ndarray, np.ndarray]:
    if action == "idle":
        return reanchor(base), breathe(base, 1)
    if action == "sniff":
        return lower_head(base, direction, 1), lower_head(base, direction, 3, 1)
    if action == "eat":
        return mouth(lower_head(base, direction, 2), direction, 1), mouth(lower_head(base, direction, 3, 1), direction, 2)
    if action == "pee":
        return lift_rear_leg(base, direction, 2), lift_rear_leg(base, direction, 4)
    if action == "poop":
        return raise_tail(squat(base, 1), direction, 1), raise_tail(squat(base, 3), direction, 2)
    if action == "bark":
        first = mouth(base, direction, 1)
        second = mouth(move_region(base, head_mask(base, direction), 1 if direction in ("E", "NE", "SE") else 0, -1), direction, 2)
        return reanchor(first), reanchor(second)
    if action == "hurt":
        return recoil(base, direction, 1), recoil(base, direction, 2)
    if action == "tired":
        return mouth(lower_head(base, direction, 2), direction, 1), mouth(breathe(lower_head(base, direction, 3), 1), direction, 2)
    raise KeyError(action)


def save_frame(rgba: np.ndarray, action: str, direction: str, phase: int) -> Path:
    FRAMES.mkdir(parents=True, exist_ok=True)
    path = FRAMES / f"{action}_{direction}_{phase}.png"
    Image.fromarray(rgba, "RGBA").save(path)
    return path


def mirror_frame(source: np.ndarray) -> np.ndarray:
    return reanchor(np.asarray(Image.fromarray(source, "RGBA").transpose(Image.Transpose.FLIP_LEFT_RIGHT)).copy())


def build(directions: tuple[str, ...]) -> None:
    provenance: dict[str, object] = {
        "method": "deterministic hard-pixel component transforms from finalized Kontext canonicals",
        "rejected_update2_frames_used": False,
        "model_role": "Local Flux Kontext produced canonical identity/direction bases; Wan is reserved for walk/run/fetch. Static two-frame actions are authored locally without model inference.",
        "sources": {},
        "operations": ["integer pixel translation", "region cut/move", "authored palette pixels", "nearest-only preview scaling", "local exact mirrors"],
    }
    for direction in directions:
        source = canonical_path(direction)
        provenance["sources"][direction] = {"path": str(source.relative_to(WORK)).replace("\\", "/"), "sha256": digest(source)}
        base = load(direction)
        for action in ACTIONS:
            first, second = action_pair(base, action, direction)
            save_frame(first, action, direction, 0)
            save_frame(second, action, direction, 1)

    if set(AUTHORED) <= set(directions):
        for action in ACTIONS:
            for target, source_direction in MIRRORS.items():
                for phase in range(2):
                    source = np.asarray(Image.open(FRAMES / f"{action}_{source_direction}_{phase}.png").convert("RGBA"))
                    save_frame(mirror_frame(source), action, target, phase)
    validation_directions = DIRECTIONS if set(AUTHORED) <= set(directions) else directions
    METADATA.mkdir(parents=True, exist_ok=True)
    (METADATA / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    validate(validation_directions)
    contacts(validation_directions)


def validate(directions: tuple[str, ...]) -> None:
    failures: list[str] = []
    results: dict[str, object] = {}
    for direction in directions:
        for action in ACTIONS:
            images = [np.asarray(Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA")) for phase in range(2)]
            diff = int(np.count_nonzero(np.any(images[0] != images[1], axis=2)))
            if diff < 3:
                failures.append(f"{action}/{direction}: phases differ by only {diff} pixels")
            for phase, rgba in enumerate(images):
                alpha_values = sorted(int(value) for value in np.unique(rgba[:, :, 3]))
                colors = {tuple(int(v) for v in color) for color in np.unique(rgba[rgba[:, :, 3] > 0, :3], axis=0)}
                hidden_zero = bool(np.all(rgba[rgba[:, :, 3] == 0, :3] == 0))
                x0, y0, x1, y1 = bbox(rgba[:, :, 3] > 0)
                center = (x0 + x1 - 1) / 2
                width_ok = TARGET_WIDTH[direction][0] <= x1 - x0 <= TARGET_WIDTH[direction][1]
                ok = alpha_values == [0, 255] and colors <= PALETTE and hidden_zero and y1 - 1 == 36 and center in (19.5, 20.0) and width_ok
                if not ok:
                    failures.append(f"{action}/{direction}/{phase}: mechanical validation")
                results[f"{action}_{direction}_{phase}.png"] = {"bbox": [x0, y0, x1, y1], "phase_diff_pixels": diff, "passed": ok}
    report = {"passed": not failures, "directions": list(directions), "frames": len(results), "failures": failures, "results": results, "visual_review_required": True}
    if set(DIRECTIONS) <= set(directions):
        mirror_failures: list[str] = []
        for action in ACTIONS:
            for target_direction, source_direction in MIRRORS.items():
                for phase in range(2):
                    source = np.asarray(Image.open(FRAMES / f"{action}_{source_direction}_{phase}.png").convert("RGBA"))
                    target_image = np.asarray(Image.open(FRAMES / f"{action}_{target_direction}_{phase}.png").convert("RGBA"))
                    if not np.array_equal(mirror_frame(source), target_image):
                        mirror_failures.append(f"{action}/{target_direction}/{phase}")
        report["mirror_failures"] = mirror_failures
        if mirror_failures:
            report["passed"] = False
            report["failures"].extend(f"mirror mismatch: {item}" for item in mirror_failures)
    (METADATA / "validation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if failures:
        print(f"validation warnings: {len(failures)}")


def contacts(directions: tuple[str, ...]) -> None:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    cell = 120
    contact = Image.new("RGBA", (len(directions) * 2 * cell, len(ACTIONS) * (cell + 20)), (0, 0, 0, 0))
    draw = ImageDraw.Draw(contact)
    for row, action in enumerate(ACTIONS):
        for direction_index, direction in enumerate(directions):
            for phase in range(2):
                frame = Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA").resize((cell, cell), Image.Resampling.NEAREST)
                x = (direction_index * 2 + phase) * cell
                y = row * (cell + 20) + 20
                contact.alpha_composite(frame, (x, y))
                draw.rectangle((x, y - 20, x + cell - 1, y - 1), fill=(0, 0, 0, 255))
                draw.text((x + 3, y - 18), f"{action} {direction} p{phase}", fill=(255, 255, 255, 255))
                gif = PREVIEWS / "gifs" / f"{action}_{direction}.gif"
                gif.parent.mkdir(parents=True, exist_ok=True)
                if phase == 0:
                    first = frame
                else:
                    first.save(gif, save_all=True, append_images=[frame], duration=round(1000 / FPS[action]), loop=0, disposal=2, transparency=0)
    contact.save(PREVIEWS / ("pilot-E-N-contact.png" if directions == ("E", "N") else "all-directions-contact.png"))


def main() -> None:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--pilot", action="store_true")
    group.add_argument("--full", action="store_true")
    parser.add_argument("--integrate-plain", action="store_true")
    args = parser.parse_args()
    directions = ("E", "N") if args.pilot or not args.full else AUTHORED
    build(directions)
    if args.integrate_plain:
        if not args.full:
            parser.error("--integrate-plain requires --full")
        report = json.loads((METADATA / "validation.json").read_text(encoding="utf-8"))
        if not report.get("passed") or report.get("frames") != 128:
            raise ValueError("refusing plain-frame integration before complete validation")
        destination = WORK / "frames"
        destination.mkdir(parents=True, exist_ok=True)
        for action in ACTIONS:
            for direction in DIRECTIONS:
                for phase in range(2):
                    source = FRAMES / f"{action}_{direction}_{phase}.png"
                    shutil.copy2(source, destination / source.name)
        (METADATA / "plain-integration.json").write_text(
            json.dumps({"installed_frames": 128, "destination": "frames/", "runtime_installed": False}, indent=2) + "\n",
            encoding="utf-8",
        )
    print(f"built {len(ACTIONS) * len(directions) * 2} deterministic authored frames")


if __name__ == "__main__":
    main()

