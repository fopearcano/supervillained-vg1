"""Build versioned Wan movement workflows from finalized Kontext canonicals."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WF = WORK / "workflows"
NATIVE = WORK / "canonical-native"
INPUTS = WORK / "canonical-inputs"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
SELECTIONS = WORK / "metadata" / "selections.json"
DIRECTIONS = ("N", "NE", "E", "SE", "S")
NEW_DIRECTIONS = ("N", "NE", "SE", "S")
ACTIONS = ("walk", "run", "fetch")
BALL_CENTER = {"N": (31, 15), "NE": (36, 15), "E": (36, 18), "SE": (36, 16), "S": (20, 18)}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def with_ball(native: Image.Image, direction: str) -> Image.Image:
    image = native.copy().convert("RGBA")
    cx, cy = BALL_CENTER[direction]
    draw = ImageDraw.Draw(image)
    dark, bright = "#98b418", "#dcf23a"
    draw.polygon(
        ((cx - 2, cy - 1), (cx - 1, cy - 2), (cx + 1, cy - 2), (cx + 2, cy - 1),
         (cx + 2, cy + 1), (cx + 1, cy + 2), (cx - 1, cy + 2), (cx - 2, cy + 1)),
        fill=dark,
    )
    draw.rectangle((cx - 1, cy - 1, cx, cy), fill=bright)
    return image


def wan_canvas(native: Image.Image) -> Image.Image:
    scaled = native.resize((400, 400), Image.Resampling.NEAREST)
    canvas = Image.new("RGB", (832, 480), (0, 255, 0))
    canvas.paste(scaled.convert("RGB"), (216, 40), scaled.getchannel("A"))
    return canvas


def prepare_inputs() -> tuple[dict[str, Path], dict[str, Path]]:
    INPUTS.mkdir(parents=True, exist_ok=True)
    plain: dict[str, Path] = {}
    balls: dict[str, Path] = {}
    for direction in DIRECTIONS:
        native = Image.open(NATIVE / f"zampano_{direction}_kontext_v1.png").convert("RGBA")
        plain_path = INPUTS / f"zampano_{direction}_kontext_v1_wan_832x480.png"
        wan_canvas(native).save(plain_path)
        ball_native = with_ball(native, direction)
        ball_native.save(INPUTS / f"zampano_{direction}_kontext_v1_ball-native.png")
        ball_path = INPUTS / f"zampano_{direction}_kontext_v1_ball_wan_832x480.png"
        wan_canvas(ball_native).save(ball_path)
        plain[direction], balls[direction] = plain_path, ball_path
    return plain, balls


def fetch_prompt(direction: str) -> str:
    views = {
        "N": "strict rear N view facing directly away",
        "NE": "strict three-quarter NE view facing upper-right",
        "E": "strict exact right-facing E profile",
        "SE": "strict three-quarter SE view facing lower-right",
        "S": "strict symmetrical front S view",
    }
    return (
        f"A seamless looping pixel-art fetch run of the exact same shaggy white Maltese in {views[direction]}, "
        "carrying the exact lime yellow-green ball from the input locked firmly at the muzzle in every frame. "
        "Fast four-phase bound: gather, push-off, airborne extension, landing. The single ball never disappears, "
        "moves away, drops or duplicates. Preserve exact direction, floppy ears, identity, proportions, palette, "
        "scale, anchor and hard pixels. Locked orthographic camera, chroma-green background, no ground or shadow."
    )


def main() -> None:
    plain, balls = prepare_inputs()
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    selections = json.loads(SELECTIONS.read_text(encoding="utf-8"))
    built: list[str] = []
    for action in ACTIONS:
        for direction in NEW_DIRECTIONS:
            template = WF / f"zampano_{action}_{direction}_attempt-3_api.json"
            workflow = copy.deepcopy(json.loads(template.read_text(encoding="utf-8")))
            source = balls[direction] if action == "fetch" else plain[direction]
            workflow["5"]["inputs"]["image"] = source.name
            seed = int(workflow["11"]["inputs"]["noise_seed"]) + 1
            workflow["11"]["inputs"]["noise_seed"] = seed
            workflow["16"]["inputs"]["noise_seed"] = seed
            if action == "fetch":
                workflow["2"]["inputs"]["text"] = fetch_prompt(direction)
                workflow["3"]["inputs"]["text"] += ", missing ball, disappearing ball, dropped ball, duplicate ball, ball away from muzzle"
            else:
                workflow["2"]["inputs"]["text"] += " Preserve the exact finalized Kontext canonical identity and direction from the input."
            workflow["18"]["inputs"]["filename_prefix"] = f"update2-local/{action}_{direction}_attempt-4"
            output = WF / f"zampano_{action}_{direction}_attempt-4_api.json"
            write_json(output, workflow)
            manifest["requests"][f"{action}/{direction}/attempt-4"] = {
                "action": action, "direction": direction, "attempt": 4,
                "engine": "local-wan-pixel-animate", "seed": seed,
                "prompt": workflow["2"]["inputs"]["text"],
                "negative_prompt": workflow["3"]["inputs"]["text"],
                "input": str(source.relative_to(REPO)).replace("\\", "/"),
                "input_sha256": digest(source),
                "workflow": str(output.relative_to(REPO)).replace("\\", "/"),
                "workflow_sha256": digest(output), "status": "planned",
                "prompt_id": None, "actual_charge": 0,
            }
            selection = selections.setdefault(f"{action}/{direction}", {"indices": None, "reviewed": False, "notes": ""})
            if not selection.get("reviewed"):
                selection["attempt"] = 4
                selection["indices"] = None
            built.append(str(output.relative_to(REPO)).replace("\\", "/"))

    accepted = {
        "walk/E/attempt-3": ("967cf30c-d6a3-45e8-9528-97ad117caaae", "accepted_motion_candidate", [1, 4, 8, 12]),
        "run/E/attempt-3": ("7a849e46-effe-4e11-a75e-d6d3640dd6e1", "accepted_motion_candidate", [1, 3, 5, 9]),
        "fetch/E/attempt-4": ("21373eb9-ef82-49a9-8fda-fb28097177c8", "accepted_motion_candidate", None),
    }
    for key, (prompt_id, status, candidates) in accepted.items():
        manifest["requests"].setdefault(key, {}).update(
            {"status": status, "prompt_id": prompt_id, "selection_candidates": candidates, "actual_charge": 0}
        )
        action, direction, attempt_text = key.split("/")
        selection = selections.setdefault(f"{action}/{direction}", {"indices": None, "reviewed": False, "notes": ""})
        if not selection.get("reviewed"):
            selection["attempt"] = int(attempt_text.removeprefix("attempt-"))
    write_json(MANIFEST, manifest)
    write_json(SELECTIONS, selections)
    write_json(WORK / "metadata" / "wan-movement-plan.json", {"workflows": built, "launch_authorized": False})
    print(f"wrote {len(built)} Wan movement workflows; no inference submitted")


if __name__ == "__main__":
    main()

