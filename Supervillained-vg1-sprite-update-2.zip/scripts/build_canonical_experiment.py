"""Build the E-profile shaggy standing canonical SDXL experiment."""

from __future__ import annotations

import copy
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(__file__).resolve().parents[3]
TEMPLATE = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_tired_E_sdxl_api.json"
UPDATE1 = (
    REPO
    / "sprites-out"
    / "update2"
    / "source-main"
    / "update1"
    / "Supervillained-vg1-sprite-update"
    / "runtime"
    / "public"
    / "sprites"
    / "zampano.png"
)
OLD_INPUTS = REPO / "sprites-out" / "zampano" / "workflows" / "input"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")
SEED = 611172799001


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    guide_dir = WORK / "guides"
    workflow_dir = WORK / "workflows"
    metadata_dir = WORK / "metadata"
    guide_dir.mkdir(parents=True, exist_ok=True)
    workflow_dir.mkdir(parents=True, exist_ok=True)

    sheet = Image.open(UPDATE1).convert("RGBA")
    neutral = sheet.crop((0, 2 * 40, 40, 3 * 40))
    large = neutral.resize((640, 640), Image.Resampling.NEAREST)
    green = Image.new("RGB", (640, 640), (0, 255, 0))
    green.paste(large.convert("RGB"), (0, 0), large.getchannel("A"))
    neutral_name = "update2_local_zampano_E_neutral_composition_sdxl.png"
    neutral_path = guide_dir / neutral_name
    green.save(neutral_path)
    shutil.copy2(neutral_path, COMFY_INPUT / neutral_name)

    for name in ("zampano_E_gather_wan_832x480.png", "zampano_front_clean_sdxl_640.png"):
        shutil.copy2(OLD_INPUTS / name, COMFY_INPUT / name)

    workflow = copy.deepcopy(json.loads(TEMPLATE.read_text(encoding="utf-8")))
    workflow["4"]["inputs"]["image"] = neutral_name
    workflow["8"]["inputs"]["image"] = neutral_name
    workflow["17"]["inputs"]["image"] = "zampano_front_clean_sdxl_640.png"
    workflow["18"]["inputs"].update(
        {"weight": 0.35, "start_at": 0.0, "end_at": 0.8, "weight_type": "style transfer precise"}
    )
    workflow["19"] = {
        "class_type": "LoadImage",
        "inputs": {"image": "zampano_E_gather_wan_832x480.png"},
    }
    workflow["20"] = {
        "class_type": "IPAdapterAdvanced",
        "inputs": {
            "model": ["18", 0],
            "ipadapter": ["3", 1],
            "image": ["19", 0],
            "weight": 0.65,
            "weight_type": "style transfer precise",
            "combine_embeds": "concat",
            "start_at": 0.0,
            "end_at": 0.9,
            "embeds_scaling": "K+V w/ C penalty",
        },
    }
    workflow["5"]["inputs"].update(
        {
            "model": ["20", 0],
            "image": ["4", 0],
            "weight": 0.55,
            "weight_type": "composition precise",
            "start_at": 0.0,
            "end_at": 0.85,
        }
    )
    prompt = (
        "pixel art game sprite of Zampano, one small scruffy white long-haired Maltese dog, "
        "complete full body visible in exact right-facing side profile, standing naturally on all "
        "four paws. Long shaggy white coat hangs from the chest, belly and legs; rounded floppy "
        "ears frame the face; compact low body, short legs, dark teal outline and pale blue-gray "
        "fur shadows. Preserve the source dog's identity and proportions. Centered isolated "
        "character occupying about half the canvas on flat solid chroma green, hard square pixels, "
        "limited colors, no ground and no shadow"
    )
    negative = (
        "short-haired dog, smooth coat, tall dog, skinny dog, long legs, pointy ears, upright ears, "
        "cat, puppy, changing identity, extra dog, extra legs, missing legs, sitting, running, "
        "jumping, cropped body, portrait, close-up, realistic, photograph, 3d, vector art, blur, "
        "antialiasing, scenery, floor, ground, cast shadow, collar, clothing, text, watermark"
    )
    workflow["6"]["inputs"]["text"] = prompt
    workflow["7"]["inputs"]["text"] = negative
    workflow["11"]["inputs"].update({"strength": 0.9, "end_percent": 0.82})
    workflow["13"]["inputs"].update({"seed": SEED, "steps": 28, "denoise": 0.55})
    workflow["16"]["inputs"]["filename_prefix"] = "update2-local-sdxl/canonical_E_shaggy_attempt-1"
    path = workflow_dir / "zampano_canonical_E_shaggy_sdxl_attempt-1_api.json"
    path.write_text(json.dumps(workflow, indent=2) + "\n", encoding="utf-8")

    manifest_path = metadata_dir / "generation-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["requests"]["canonical/E/shaggy/sdxl-attempt-1"] = {
        "engine": "local-sdxl-ipadapter-canny",
        "seed": SEED,
        "prompt": prompt,
        "negative_prompt": negative,
        "denoise": 0.55,
        "composition_input": str(neutral_path.relative_to(REPO)).replace("\\", "/"),
        "composition_sha256": sha256(neutral_path),
        "appearance_inputs": [
            "sprites-out/zampano/workflows/input/zampano_E_gather_wan_832x480.png",
            "sprites-out/zampano/workflows/input/zampano_front_clean_sdxl_640.png",
        ],
        "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
        "workflow_sha256": sha256(path),
        "status": "planned",
        "prompt_id": None,
        "actual_charge": 0,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()

