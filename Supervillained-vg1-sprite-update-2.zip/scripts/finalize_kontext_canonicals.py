"""Clean accepted Kontext direction bases into exact native envelopes and 640 refs."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
RAW = WORK / "raw" / "canonical"
NATIVE = WORK / "canonical-native"
INPUTS = WORK / "canonical-inputs"
PREVIEWS = WORK / "previews" / "batch-review"
PALETTE = np.asarray(
    [(254, 249, 235), (166, 192, 191), (61, 92, 93), (204, 216, 210), (3, 40, 43), (3, 25, 27), (172, 196, 195), (2, 33, 35)],
    dtype=np.int32,
)
DIRECTIONS = ("N", "NE", "E", "SE", "S")
TARGET = {"N": (30, 31), "NE": (33, 30), "E": (36, 30), "SE": (33, 30), "S": (30, 31)}
RAW_SPECS = {
    "N": RAW / "N" / "kontext-attempt-2",
    "NE": RAW / "NE" / "kontext-attempt-3",
    "SE": RAW / "SE" / "kontext-attempt-2",
    "S": RAW / "S" / "kontext-attempt-3",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def largest_component(mask: np.ndarray) -> np.ndarray:
    height, width = mask.shape
    remaining = {int(y) * width + int(x) for y, x in np.argwhere(mask)}
    best: set[int] = set()
    while remaining:
        start = remaining.pop()
        component = {start}
        queue = deque((start,))
        while queue:
            value = queue.popleft()
            y, x = divmod(value, width)
            for neighbor in (value - width, value + width, value - 1, value + 1):
                ny, nx = divmod(neighbor, width)
                if 0 <= ny < height and 0 <= nx < width and abs(nx - x) + abs(ny - y) == 1 and neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    queue.append(neighbor)
        if len(component) > len(best):
            best = component
    output = np.zeros(mask.shape, dtype=bool)
    if best:
        values = np.fromiter(best, dtype=np.int64)
        output[values // width, values % width] = True
    return output


def clean(path: Path, direction: str) -> Image.Image:
    rgb = np.asarray(Image.open(path).convert("RGB"))
    r, g, b = (rgb[:, :, index].astype(np.int16) for index in range(3))
    chroma = (g > 105) & (g > r * 1.25) & (g > b * 1.25)
    subject = largest_component(~chroma)
    ys, xs = np.nonzero(subject)
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    crop_rgb = Image.fromarray(rgb[y0:y1, x0:x1], "RGB")
    crop_alpha = Image.fromarray(subject[y0:y1, x0:x1].astype(np.uint8) * 255, "L")
    width, height = TARGET[direction]
    resized_rgb = np.asarray(crop_rgb.resize((width, height), Image.Resampling.NEAREST))
    resized_mask = np.asarray(crop_alpha.resize((width, height), Image.Resampling.NEAREST)) > 0
    colors = np.zeros_like(resized_rgb, dtype=np.uint8)
    pixels = resized_rgb[resized_mask].astype(np.int32)
    distances = ((pixels[:, None, :] - PALETTE[None, :, :]) ** 2).sum(axis=2)
    colors[resized_mask] = PALETTE[np.argmin(distances, axis=1)].astype(np.uint8)
    sprite = Image.fromarray(np.dstack((colors, resized_mask.astype(np.uint8) * 255)), "RGBA")
    canvas = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    canvas.alpha_composite(sprite, ((40 - width) // 2, 36 - (height - 1)))
    return canvas


def on_green(native: Image.Image) -> Image.Image:
    scaled = native.resize((640, 640), Image.Resampling.NEAREST)
    green = Image.new("RGB", (640, 640), (0, 255, 0))
    green.paste(scaled.convert("RGB"), (0, 0), scaled.getchannel("A"))
    return green


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--direction", action="append", choices=DIRECTIONS)
    args = parser.parse_args()
    selected = tuple(args.direction or DIRECTIONS)
    NATIVE.mkdir(parents=True, exist_ok=True)
    INPUTS.mkdir(parents=True, exist_ok=True)
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    manifest_path = WORK / "metadata" / "kontext-canonical-manifest.json"
    if manifest_path.exists():
        records = json.loads(manifest_path.read_text(encoding="utf-8")).get("directions", {})
    else:
        records = {}
    native_images: dict[str, Image.Image] = {}
    if "E" in selected:
        native_images["E"] = Image.open(NATIVE / "zampano_E_v1.png").convert("RGBA")
    for direction in selected:
        if direction == "E":
            continue
        folder = RAW_SPECS[direction]
        paths = sorted(folder.glob("*.png"))
        if not paths:
            raise FileNotFoundError(f"missing Kontext canonical output: {folder}")
        native_images[direction] = clean(paths[0], direction)
        records[direction] = {
            "source": str(paths[0].relative_to(WORK)).replace("\\", "/"),
            "source_sha256": digest(paths[0]),
        }

    contact = Image.new("RGBA", (len(selected) * 160, 180), (0, 0, 0, 0))
    draw = ImageDraw.Draw(contact)
    for index, direction in enumerate(selected):
        native = native_images[direction]
        native_path = NATIVE / f"zampano_{direction}_kontext_v1.png"
        native.save(native_path)
        ref_path = INPUTS / f"zampano_{direction}_kontext_v1_sdxl_640.png"
        on_green(native).save(ref_path)
        rgba = np.asarray(native)
        ys, xs = np.nonzero(rgba[:, :, 3])
        records.setdefault(direction, {})
        records[direction].update(
            {
                "native": str(native_path.relative_to(WORK)).replace("\\", "/"),
                "native_sha256": digest(native_path),
                "reference_640": str(ref_path.relative_to(WORK)).replace("\\", "/"),
                "reference_sha256": digest(ref_path),
                "bbox": [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1],
                "anchor": [20, 36],
                "alpha_values": [int(value) for value in np.unique(rgba[:, :, 3])],
                "hidden_rgb_zero": bool(np.all(rgba[rgba[:, :, 3] == 0, :3] == 0)),
            }
        )
        contact.alpha_composite(native.resize((160, 160), Image.Resampling.NEAREST), (index * 160, 20))
        draw.rectangle((index * 160, 0, index * 160 + 159, 19), fill=(0, 0, 0, 255))
        draw.text((index * 160 + 4, 3), direction, fill=(255, 255, 255, 255))
    label = "-".join(selected)
    contact.save(PREVIEWS / f"kontext-canonicals-{label}-native.png")
    manifest_path.write_text(
        json.dumps({"version": 1, "directions": records}, indent=2) + "\n",
        encoding="utf-8",
    )
    print("finalized Kontext canonical(s): " + ", ".join(selected))


if __name__ == "__main__":
    main()

