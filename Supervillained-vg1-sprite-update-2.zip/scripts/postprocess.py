"""Review helpers, hard-pixel cleanup, mirroring, assembly, and validation."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = WORK.parents[1]
CONFIG = json.loads((WORK / "config" / "actions.json").read_text(encoding="utf-8"))
SELECTIONS = WORK / "metadata" / "selections.json"
POSE_SELECTIONS = WORK / "metadata" / "pose-selections.json"
KONTEXT_SELECTIONS = WORK / "metadata" / "kontext-selections.json"
RAW = WORK / "raw"
FRAMES = WORK / "frames"
PREVIEWS = WORK / "previews"
RUNTIME = WORK / "runtime"
VALIDATION = WORK / "metadata" / "validation.json"

AUTHORED = ("N", "NE", "E", "SE", "S")
DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
MIRRORS = {"NW": "NE", "W": "E", "SW": "SE"}
MAIN_ACTIONS = ("idle", "walk", "run", "sniff", "pee", "poop", "eat", "bark", "fetch", "hurt")

PALETTE = np.asarray(
    [
        (254, 249, 235),
        (166, 192, 191),
        (61, 92, 93),
        (204, 216, 210),
        (3, 40, 43),
        (3, 25, 27),
        (172, 196, 195),
        (2, 33, 35),
    ],
    dtype=np.int32,
)
BALL = np.asarray([(220, 242, 58), (152, 180, 24)], dtype=np.uint8)
TARGET_WIDTH = {"N": 30, "NE": 33, "E": 36, "SE": 33, "S": 30}


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def alpha_bbox(image: Image.Image) -> tuple[int, int, int, int]:
    alpha = np.asarray(image.getchannel("A"))
    ys, xs = np.nonzero(alpha)
    if not len(xs):
        raise ValueError("empty alpha mask")
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def largest_component(mask: np.ndarray) -> np.ndarray:
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    if count <= 1:
        return mask.astype(bool)
    largest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == largest


def raw_paths(action: str, direction: str, attempt: int) -> list[Path]:
    folder = RAW / action / direction / f"attempt-{attempt}"
    return sorted(folder.glob("*.png"))


def pose_raw_paths(action: str, direction: str, phase: int, attempt: int) -> list[Path]:
    folders = (
        RAW / action / direction / f"sdxl-attempt-{attempt}" / f"phase-{phase}",
        RAW / action / direction / f"phase-{phase}" / f"sdxl-attempt-{attempt}",
    )
    for folder in folders:
        paths = sorted(folder.glob("*.png"))
        if paths:
            return paths
    return []


def kontext_raw_paths(action: str, direction: str, attempt: int) -> list[Path]:
    return sorted((RAW / action / direction / f"kontext-attempt-{attempt}").glob("*.png"))


def contacts() -> None:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    written = 0
    folders = sorted({path.parent for path in RAW.rglob("*.png")})
    for folder in folders:
        paths = sorted(folder.glob("*.png"))
        thumbs = [
            Image.open(path).convert("RGB").resize((208, 120), Image.Resampling.NEAREST)
            for path in paths
        ]
        columns = 5
        rows = math.ceil(len(thumbs) / columns)
        contact = Image.new("RGB", (columns * 208, rows * 140), (20, 20, 20))
        draw = ImageDraw.Draw(contact)
        for index, thumb in enumerate(thumbs):
            x = (index % columns) * 208
            y = (index // columns) * 140
            contact.paste(thumb, (x, y + 20))
            draw.text((x + 5, y + 4), f"{index:02d}", fill=(255, 255, 255))
        label = "_".join(folder.relative_to(RAW).parts)
        output = PREVIEWS / "raw-contacts" / f"{label}.png"
        output.parent.mkdir(parents=True, exist_ok=True)
        contact.save(output)
        written += 1
    pose_actions = ("idle", "sniff", "pee", "poop", "eat", "bark", "hurt", "tired")
    cell = 160
    grid = Image.new("RGB", (len(AUTHORED) * cell, len(pose_actions) * 2 * cell), (18, 18, 18))
    draw = ImageDraw.Draw(grid)
    pose_count = 0
    for action_index, action in enumerate(pose_actions):
        for phase in range(2):
            for direction_index, direction in enumerate(AUTHORED):
                paths = pose_raw_paths(action, direction, phase, 2)
                if not paths:
                    continue
                image = Image.open(paths[0]).convert("RGB").resize((cell, cell), Image.Resampling.NEAREST)
                x = direction_index * cell
                y = (action_index * 2 + phase) * cell
                grid.paste(image, (x, y))
                draw.rectangle((x, y, x + cell - 1, y + 18), fill=(0, 0, 0))
                draw.text((x + 4, y + 3), f"{action} {direction} p{phase}", fill=(255, 255, 255))
                pose_count += 1
    if pose_count:
        grid.save(PREVIEWS / "pose-output-review.png")
    print(f"wrote {written} raw contact sheets")


def raw_masks(rgb: np.ndarray, action: str) -> tuple[np.ndarray, np.ndarray]:
    r, g, b = (rgb[:, :, channel].astype(np.int16) for channel in range(3))
    chroma = (g > 105) & (g > r * 1.25) & (g > b * 1.25)
    foreground = ~chroma
    dog = largest_component(foreground)

    ys, xs = np.nonzero(dog)
    if not len(xs):
        raise ValueError("no subject found after chroma removal")
    lower_cut = int(ys.min() + (ys.max() - ys.min() + 1) * 0.55)
    shadow_color = (
        (r >= 38)
        & (r <= 100)
        & (g >= 100)
        & (g <= 175)
        & (b >= 105)
        & (b <= 185)
    )
    candidates = (dog & shadow_color).astype(np.uint8)
    candidates[:lower_cut] = 0
    count, labels, stats, _ = cv2.connectedComponentsWithStats(candidates, 8)
    for component in range(1, count):
        _, _, width, height, area = (int(value) for value in stats[component])
        if area >= 80 and width >= height * 1.35:
            dog[labels == component] = False
    dog = largest_component(dog)

    ball = np.zeros(dog.shape, dtype=bool)
    if action == "fetch":
        ball_color = (r > 95) & (g > 105) & (b < 145) & (g > b * 1.35)
        ball_color &= foreground
        # The ball may touch the muzzle or be a nearby component. Color is the
        # stable discriminator; morphology closes one-pixel video gaps.
        ball = cv2.morphologyEx(
            ball_color.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)
        ).astype(bool)
        ball &= cv2.dilate(dog.astype(np.uint8), np.ones((41, 41), np.uint8)).astype(bool)
        dog &= ~ball
        dog = largest_component(dog)
    return dog, ball


def nearest_colors(rgb: np.ndarray, mask: np.ndarray) -> np.ndarray:
    output = np.zeros_like(rgb, dtype=np.uint8)
    pixels = rgb[mask].astype(np.int32)
    if len(pixels):
        distance = ((pixels[:, None, :] - PALETTE[None, :, :]) ** 2).sum(axis=2)
        output[mask] = PALETTE[np.argmin(distance, axis=1)].astype(np.uint8)
    return output


def target_bottom(action: str, phase: int) -> int:
    airborne = CONFIG[action].get("airborne_phases", [])
    return 34 if phase in airborne else 36


def clean_frame(path: Path, action: str, direction: str, phase: int) -> Image.Image:
    rgb = np.asarray(Image.open(path).convert("RGB"))
    dog, ball = raw_masks(rgb, action)
    if rgb.shape[:2] == (640, 640):
        # SDXL guides are composed on an exact 640px canvas. Preserve that
        # composition and reduce by a fixed integer 16x; crop-based scaling
        # would silently change body proportions from one pose to the next.
        canvas_rgb = Image.fromarray(rgb, "RGB")
        canvas_dog = Image.fromarray(dog.astype(np.uint8) * 255, "L")
        canvas_ball = Image.fromarray(ball.astype(np.uint8) * 255, "L")
    else:
        union = dog | ball
        ys, xs = np.nonzero(union)
        x0, x1 = int(xs.min()), int(xs.max()) + 1
        y0, y1 = int(ys.min()), int(ys.max()) + 1
        crop_rgb = rgb[y0:y1, x0:x1]
        crop_dog = dog[y0:y1, x0:x1]
        crop_ball = ball[y0:y1, x0:x1]

        factor = max(6, min(16, round(crop_dog.shape[1] / TARGET_WIDTH[direction])))
        factor = max(factor, math.ceil(max(crop_rgb.shape[:2]) / 40))
        if factor > 16:
            raise ValueError(f"{path}: generated subject is too large for integer reduction")
        native_size = 40 * factor
        canvas_rgb = Image.new("RGB", (native_size, native_size), (0, 255, 0))
        canvas_dog = Image.new("L", (native_size, native_size), 0)
        canvas_ball = Image.new("L", (native_size, native_size), 0)
        px = (native_size - crop_rgb.shape[1]) // 2
        py = target_bottom(action, phase) * factor - (crop_rgb.shape[0] - 1)
        if py < 0:
            raise ValueError(f"{path}: subject cannot be grounded in {native_size}px canvas")
        crop_image = Image.fromarray(crop_rgb, "RGB")
        dog_image = Image.fromarray(crop_dog.astype(np.uint8) * 255, "L")
        ball_image = Image.fromarray(crop_ball.astype(np.uint8) * 255, "L")
        canvas_rgb.paste(
            crop_image,
            (px, py),
            Image.fromarray(union[y0:y1, x0:x1].astype(np.uint8) * 255),
        )
        canvas_dog.paste(dog_image, (px, py))
        canvas_ball.paste(ball_image, (px, py))

    small_rgb = np.asarray(canvas_rgb.resize((40, 40), Image.Resampling.NEAREST))
    small_dog = np.asarray(canvas_dog.resize((40, 40), Image.Resampling.NEAREST)) > 0
    small_ball = np.asarray(canvas_ball.resize((40, 40), Image.Resampling.NEAREST)) > 0
    colors = nearest_colors(small_rgb, small_dog)
    if action == "fetch" and small_ball.any():
        luminance = small_rgb[small_ball].astype(np.int32).sum(axis=1)
        threshold = int(np.median(luminance))
        colors[small_ball] = BALL[1]
        ball_points = np.argwhere(small_ball)
        for y, x in ball_points[luminance >= threshold]:
            colors[y, x] = BALL[0]
    alpha = (small_dog | small_ball).astype(np.uint8) * 255
    image = Image.fromarray(np.dstack((colors, alpha)), "RGBA")

    # Reanchor on the body, never the fetch ball.
    ys, xs = np.nonzero(small_dog)
    center = (int(xs.min()) + int(xs.max())) // 2
    bottom = int(ys.max())
    dx = 20 - center
    dy = target_bottom(action, phase) - bottom
    anchored = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    anchored.alpha_composite(image, (dx, dy))
    return anchored


def clean_kontext_frame(path: Path, action: str, direction: str) -> Image.Image:
    rgb = np.asarray(Image.open(path).convert("RGB"))
    dog, _ = raw_masks(rgb, action)
    ys, xs = np.nonzero(dog)
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    crop_rgb = Image.fromarray(rgb[y0:y1, x0:x1], "RGB")
    crop_mask = Image.fromarray(dog[y0:y1, x0:x1].astype(np.uint8) * 255, "L")
    target_width = TARGET_WIDTH[direction]
    target_height = max(18, min(36, round((y1 - y0) * target_width / max(1, x1 - x0))))
    resized_rgb = np.asarray(crop_rgb.resize((target_width, target_height), Image.Resampling.NEAREST))
    resized_mask = np.asarray(crop_mask.resize((target_width, target_height), Image.Resampling.NEAREST)) > 0
    colors = nearest_colors(resized_rgb, resized_mask)
    sprite = Image.fromarray(
        np.dstack((colors, resized_mask.astype(np.uint8) * 255)), "RGBA"
    )
    canvas = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    canvas.alpha_composite(
        sprite,
        ((40 - target_width) // 2, 36 - (target_height - 1)),
    )
    return canvas


def body_bbox(image: Image.Image, action: str) -> tuple[int, int, int, int]:
    rgba = np.asarray(image.convert("RGBA"))
    mask = rgba[:, :, 3] > 0
    if action == "fetch":
        rgb = rgba[:, :, :3]
        ball = np.all(rgb == BALL[0], axis=2) | np.all(rgb == BALL[1], axis=2)
        mask &= ~ball
    ys, xs = np.nonzero(mask)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def mirrored(source: Image.Image, action: str, phase: int) -> Image.Image:
    flipped = source.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    x0, _, x1, y1 = body_bbox(flipped, action)
    dx = 20 - ((x0 + x1 - 1) // 2)
    dy = target_bottom(action, phase) - (y1 - 1)
    output = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    output.alpha_composite(flipped, (dx, dy))
    return output


def finalize() -> None:
    selections = json.loads(SELECTIONS.read_text(encoding="utf-8"))
    FRAMES.mkdir(parents=True, exist_ok=True)
    processed = 0
    for key, selection in selections.items():
        if not selection.get("reviewed"):
            continue
        action, direction = key.split("/")
        if direction not in AUTHORED:
            continue
        indices = selection.get("indices")
        attempt = selection.get("attempt")
        required = int(CONFIG[action]["frames"])
        if not isinstance(indices, list) or len(indices) != required or not attempt:
            raise ValueError(f"{key}: reviewed selection must contain {required} indices and attempt")
        paths = raw_paths(action, direction, int(attempt))
        if not paths:
            raise FileNotFoundError(f"{key}: no raw frames for attempt {attempt}")
        for phase, index in enumerate(indices):
            if not isinstance(index, int) or index < 0 or index >= len(paths):
                raise IndexError(f"{key}: invalid raw index {index}")
            clean_frame(paths[index], action, direction, phase).save(
                FRAMES / f"{action}_{direction}_{phase}.png"
            )
        processed += 1

    if POSE_SELECTIONS.exists():
        pose_selections = json.loads(POSE_SELECTIONS.read_text(encoding="utf-8"))
        for key, selection in pose_selections.items():
            if not selection.get("reviewed"):
                continue
            action, direction, phase_text = key.split("/")
            phase = int(phase_text.removeprefix("phase-"))
            attempt = selection.get("attempt")
            index = selection.get("index")
            if not attempt or not isinstance(index, int):
                raise ValueError(f"{key}: reviewed SDXL selection needs attempt and index")
            paths = pose_raw_paths(action, direction, phase, int(attempt))
            if not paths:
                raise FileNotFoundError(f"{key}: no SDXL raw frames for attempt {attempt}")
            if index < 0 or index >= len(paths):
                raise IndexError(f"{key}: invalid SDXL output index {index}")
            clean_frame(paths[index], action, direction, phase).save(
                FRAMES / f"{action}_{direction}_{phase}.png"
            )
            processed += 1

    if KONTEXT_SELECTIONS.exists():
        kontext_selections = json.loads(KONTEXT_SELECTIONS.read_text(encoding="utf-8"))
        for key, selection in kontext_selections.items():
            if not selection.get("reviewed"):
                continue
            action, direction = key.split("/")
            attempt = selection.get("phase1_attempt")
            index = selection.get("phase1_index")
            phase0 = REPO / str(selection.get("phase0_native", ""))
            if not phase0.exists() or not attempt or not isinstance(index, int):
                raise ValueError(f"{key}: reviewed Kontext selection is incomplete")
            paths = kontext_raw_paths(action, direction, int(attempt))
            if index < 0 or index >= len(paths):
                raise IndexError(f"{key}: invalid Kontext output index {index}")
            Image.open(phase0).convert("RGBA").save(FRAMES / f"{action}_{direction}_0.png")
            clean_kontext_frame(paths[index], action, direction).save(
                FRAMES / f"{action}_{direction}_1.png"
            )
            processed += 1

    for action, action_data in CONFIG.items():
        count = int(action_data["frames"])
        if not all((FRAMES / f"{action}_{direction}_{phase}.png").exists() for direction in AUTHORED for phase in range(count)):
            continue
        for target, source in MIRRORS.items():
            for phase in range(count):
                image = Image.open(FRAMES / f"{action}_{source}_{phase}.png").convert("RGBA")
                mirrored(image, action, phase).save(FRAMES / f"{action}_{target}_{phase}.png")
        preview_action(action)

    assemble_if_complete()
    validate()
    print(f"finalized {processed} reviewed authored direction sets")


def preview_action(action: str) -> None:
    count = int(CONFIG[action]["frames"])
    gif_frames: list[Image.Image] = []
    for phase in range(count):
        grid = Image.new("RGBA", (640, 320), (0, 0, 0, 0))
        for index, direction in enumerate(DIRECTIONS):
            frame = Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA")
            grid.alpha_composite(
                frame.resize((160, 160), Image.Resampling.NEAREST),
                ((index % 4) * 160, (index // 4) * 160),
            )
        gif_frames.append(grid)
    output = PREVIEWS / "animations" / f"{action}.gif"
    output.parent.mkdir(parents=True, exist_ok=True)
    duration = round(1000 / int(CONFIG[action]["fps"]))
    gif_frames[0].save(
        output,
        save_all=True,
        append_images=gif_frames[1:],
        duration=duration,
        loop=0 if CONFIG[action]["loop"] else 1,
        disposal=2,
        transparency=0,
    )


def assemble_if_complete() -> None:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    main_complete = all(
        (FRAMES / f"{action}_{direction}_{phase}.png").exists()
        for action in MAIN_ACTIONS
        for direction in DIRECTIONS
        for phase in range(int(CONFIG[action]["frames"]))
    )
    if main_complete:
        sheet = Image.new("RGBA", (160, 3200), (0, 0, 0, 0))
        row = 0
        for action in MAIN_ACTIONS:
            for direction in DIRECTIONS:
                for phase in range(int(CONFIG[action]["frames"])):
                    frame = Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA")
                    sheet.alpha_composite(frame, (phase * 40, row * 40))
                row += 1
        sheet.save(RUNTIME / "zampano.png")

    tired_complete = all(
        (FRAMES / f"tired_{direction}_{phase}.png").exists()
        for direction in DIRECTIONS
        for phase in range(2)
    )
    if tired_complete:
        sheet = Image.new("RGBA", (80, 320), (0, 0, 0, 0))
        for row, direction in enumerate(DIRECTIONS):
            for phase in range(2):
                frame = Image.open(FRAMES / f"tired_{direction}_{phase}.png").convert("RGBA")
                sheet.alpha_composite(frame, (phase * 40, row * 40))
        sheet.save(RUNTIME / "zampano-tired.png")


def validate() -> None:
    failures: list[str] = []
    frame_results: dict[str, object] = {}
    allowed = {tuple(color) for color in PALETTE.tolist()}
    ball_allowed = {tuple(color) for color in BALL.tolist()}
    for path in sorted(FRAMES.glob("*.png")):
        image = Image.open(path).convert("RGBA")
        rgba = np.asarray(image)
        action, direction, phase_text = path.stem.rsplit("_", 2)
        phase = int(phase_text)
        alpha_values = sorted(int(value) for value in np.unique(rgba[:, :, 3]))
        colors = {
            tuple(int(value) for value in color)
            for color in np.unique(rgba[rgba[:, :, 3] > 0, :3], axis=0)
        }
        palette_ok = colors <= (allowed | (ball_allowed if action == "fetch" else set()))
        hidden_ok = bool(np.all(rgba[rgba[:, :, 3] == 0, :3] == 0))
        box = body_bbox(image, action)
        bottom_ok = box[3] - 1 == target_bottom(action, phase)
        center_x = (box[0] + box[2] - 1) / 2
        center_ok = center_x in (19.5, 20.0)
        width = box[2] - box[0]
        width_band = (29, 32) if direction in ("N", "S") else (32, 35) if direction in ("NE", "SE", "SW", "NW") else (34, 38)
        width_ok = width_band[0] <= width <= width_band[1]
        ball_colors = {
            tuple(int(value) for value in color)
            for color in np.unique(rgba[rgba[:, :, 3] > 0, :3], axis=0)
            if tuple(int(value) for value in color) in ball_allowed
        }
        fetch_ok = action != "fetch" or ball_colors == ball_allowed
        result = {
            "size": list(image.size),
            "alpha": alpha_values,
            "palette_ok": palette_ok,
            "hidden_rgb_zero": hidden_ok,
            "body_bbox": list(box),
            "body_width": width,
            "width_band": list(width_band),
            "width_ok": width_ok,
            "bottom_ok": bottom_ok,
            "center_ok": center_ok,
            "fetch_colors_ok": fetch_ok,
        }
        frame_results[path.name] = result
        if image.size != (40, 40) or alpha_values not in ([0, 255], [255]) or not palette_ok or not hidden_ok or not bottom_ok or not center_ok or not width_ok or not fetch_ok:
            failures.append(path.name)

    mirror_failures: list[str] = []
    for action, data in CONFIG.items():
        for target, source in MIRRORS.items():
            for phase in range(int(data["frames"])):
                source_path = FRAMES / f"{action}_{source}_{phase}.png"
                target_path = FRAMES / f"{action}_{target}_{phase}.png"
                if not source_path.exists() or not target_path.exists():
                    continue
                expected = np.asarray(
                    mirrored(Image.open(source_path).convert("RGBA"), action, phase)
                )
                if not np.array_equal(expected, np.asarray(Image.open(target_path).convert("RGBA"))):
                    mirror_failures.append(target_path.name)

    expected_frames = [
        f"{action}_{direction}_{phase}.png"
        for action, data in CONFIG.items()
        for direction in DIRECTIONS
        for phase in range(int(data["frames"]))
    ]
    missing_frames = [name for name in expected_frames if not (FRAMES / name).exists()]

    sheets: dict[str, object] = {}
    sheet_failures: list[str] = []
    for name, size in (("zampano.png", (160, 3200)), ("zampano-tired.png", (80, 320))):
        path = RUNTIME / name
        if path.exists():
            image = Image.open(path).convert("RGBA")
            sheets[name] = {"size": list(image.size), "size_ok": image.size == size}
            if image.size != size:
                sheet_failures.append(f"{name}: size")
        else:
            sheet_failures.append(f"{name}: missing")

    main_path = RUNTIME / "zampano.png"
    if main_path.exists() and Image.open(main_path).size == (160, 3200):
        sheet = np.asarray(Image.open(main_path).convert("RGBA"))
        row = 0
        for action in MAIN_ACTIONS:
            count = int(CONFIG[action]["frames"])
            for direction in DIRECTIONS:
                for phase in range(count):
                    frame_path = FRAMES / f"{action}_{direction}_{phase}.png"
                    if frame_path.exists():
                        cell = sheet[row * 40 : (row + 1) * 40, phase * 40 : (phase + 1) * 40]
                        if not np.array_equal(cell, np.asarray(Image.open(frame_path).convert("RGBA"))):
                            sheet_failures.append(f"zampano.png: cell {action}/{direction}/{phase}")
                unused = sheet[row * 40 : (row + 1) * 40, count * 40 :]
                if unused.size and np.any(unused):
                    sheet_failures.append(f"zampano.png: nonzero unused {action}/{direction}")
                row += 1

    tired_path = RUNTIME / "zampano-tired.png"
    if tired_path.exists() and Image.open(tired_path).size == (80, 320):
        sheet = np.asarray(Image.open(tired_path).convert("RGBA"))
        for row, direction in enumerate(DIRECTIONS):
            for phase in range(2):
                frame_path = FRAMES / f"tired_{direction}_{phase}.png"
                if frame_path.exists():
                    cell = sheet[row * 40 : (row + 1) * 40, phase * 40 : (phase + 1) * 40]
                    if not np.array_equal(cell, np.asarray(Image.open(frame_path).convert("RGBA"))):
                        sheet_failures.append(f"zampano-tired.png: cell {direction}/{phase}")

    write_json(
        VALIDATION,
        {
            "passed": not failures and not mirror_failures and not missing_frames and not sheet_failures,
            "partial": bool(missing_frames),
            "expected_frames": len(expected_frames),
            "frames_checked": len(frame_results),
            "missing_frames": missing_frames,
            "frame_failures": failures,
            "mirror_failures": mirror_failures,
            "sheet_failures": sheet_failures,
            "sheets": sheets,
            "frames": frame_results,
            "visual_review_required": True,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("contacts", "finalize", "validate"))
    args = parser.parse_args()
    if args.command == "contacts":
        contacts()
    elif args.command == "finalize":
        finalize()
    else:
        validate()


if __name__ == "__main__":
    main()

