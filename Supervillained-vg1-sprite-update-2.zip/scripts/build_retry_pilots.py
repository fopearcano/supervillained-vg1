"""Build versioned C:-only retry pilots after visual QA failures."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WORKFLOWS = WORK / "workflows"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
CANONICAL_NATIVE = WORK / "canonical-native" / "zampano_E_v1.png"
CANONICAL_INPUTS = WORK / "canonical-inputs"
DIRECTIONS = ("N", "NE", "E", "SE", "S")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def build_pose_retry(action: str, phase: int, denoise: float) -> tuple[Path, dict[str, object]]:
    source = WORKFLOWS / f"zampano_{action}_E_{phase}_sdxl_attempt-2_api.json"
    workflow = json.loads(source.read_text(encoding="utf-8"))
    guide_name = str(workflow["8"]["inputs"]["image"])
    workflow["4"]["inputs"]["image"] = guide_name
    workflow["17"]["inputs"]["image"] = "update2_local_zampano_E_canonical_set-v1_sdxl_640.png"
    workflow["18"]["inputs"].update(
        {"weight": 0.65, "weight_type": "style transfer precise", "end_at": 0.9}
    )
    workflow["5"]["inputs"].update(
        {"image": ["4", 0], "weight": 0.45, "weight_type": "composition precise", "end_at": 0.85}
    )
    workflow["11"]["inputs"].update({"strength": 0.8, "end_percent": 0.85})
    seed = int(workflow["13"]["inputs"]["seed"]) + 1
    workflow["13"]["inputs"].update({"seed": seed, "denoise": denoise, "steps": 28})
    if action == "bark":
        phase_direction = (
            "pre-bark key pose with the head pulled slightly back and mouth closed"
            if phase == 0
            else "impact bark key pose with head thrust forward and mouth clearly open"
        )
    else:
        phase_direction = (
            "eating key pose with muzzle lowered toward the ground"
            if phase == 0
            else "second eating key pose with muzzle still down and a visibly different chewing motion"
        )
    workflow["6"]["inputs"]["text"] += f". REQUIRED POSE: {phase_direction}; obey the action guide silhouette"
    workflow["7"]["inputs"]["text"] += ", neutral standing pose, no action, identical phase"
    workflow["16"]["inputs"]["filename_prefix"] = f"update2-local-sdxl/{action}_E_{phase}_attempt-3"
    output = WORKFLOWS / f"zampano_{action}_E_{phase}_sdxl_attempt-3_api.json"
    write_json(output, workflow)
    return output, {
        "action": action,
        "direction": "E",
        "phase": phase,
        "attempt": 3,
        "engine": "local-sdxl-ipadapter-canny",
        "seed": seed,
        "prompt": workflow["6"]["inputs"]["text"],
        "negative_prompt": workflow["7"]["inputs"]["text"],
        "denoise": denoise,
        "controlnet_strength": 0.8,
        "identity_ipadapter_weight": 0.65,
        "composition_ipadapter_weight": 0.45,
        "vae_composition_input": guide_name,
        "workflow": str(output.relative_to(REPO)).replace("\\", "/"),
        "workflow_sha256": digest(output),
        "status": "planned",
        "prompt_id": None,
        "actual_charge": 0,
    }


def make_ball_input() -> tuple[Path, Path]:
    native = Image.open(CANONICAL_NATIVE).convert("RGBA")
    draw = ImageDraw.Draw(native)
    dark = "#98b418"
    bright = "#dcf23a"
    # Attached to the right-facing muzzle; dark edge surrounds a bright 2x2 core.
    draw.polygon(((34, 17), (35, 16), (37, 16), (38, 17), (38, 19), (37, 20), (35, 20), (34, 19)), fill=dark)
    draw.rectangle((35, 17, 36, 18), fill=bright)
    native_path = CANONICAL_INPUTS / "zampano_E_v1_ball-native.png"
    CANONICAL_INPUTS.mkdir(parents=True, exist_ok=True)
    native.save(native_path)

    scaled = native.resize((400, 400), Image.Resampling.NEAREST)
    wan = Image.new("RGB", (832, 480), (0, 255, 0))
    wan.paste(scaled.convert("RGB"), (216, 40), scaled.getchannel("A"))
    wan_path = CANONICAL_INPUTS / "zampano_E_v1_ball_wan_832x480.png"
    wan.save(wan_path)
    return native_path, wan_path


def build_fetch_retry() -> tuple[Path, dict[str, object]]:
    native_path, wan_path = make_ball_input()
    source = WORKFLOWS / "zampano_fetch_E_attempt-3_api.json"
    workflow = json.loads(source.read_text(encoding="utf-8"))
    workflow["5"]["inputs"]["image"] = wan_path.name
    seed = int(workflow["11"]["inputs"]["noise_seed"]) + 1
    workflow["11"]["inputs"]["noise_seed"] = seed
    workflow["16"]["inputs"]["noise_seed"] = seed
    workflow["2"]["inputs"]["text"] = (
        "A seamless looping pixel art game-sprite animation of the exact same small shaggy white "
        "Maltese dog in strict right-facing profile, carrying the exact lime yellow-green ball from "
        "the input locked firmly in his mouth for every frame. Fast four-phase bounding fetch run: "
        "gather, push-off, airborne extension, landing. The single ball never moves away from the "
        "muzzle, never disappears and never duplicates. Preserve breed, floppy ears, proportions, "
        "scale, position, lighting and outline. Locked camera, chroma-green background, no ground or shadow."
    )
    workflow["3"]["inputs"]["text"] += ", missing ball, disappearing ball, dropped ball, duplicate ball, ball away from mouth"
    workflow["18"]["inputs"]["filename_prefix"] = "update2-local/fetch_E_attempt-4"
    output = WORKFLOWS / "zampano_fetch_E_attempt-4_api.json"
    write_json(output, workflow)
    return output, {
        "action": "fetch",
        "direction": "E",
        "attempt": 4,
        "engine": "local-wan-pixel-animate",
        "seed": seed,
        "prompt": workflow["2"]["inputs"]["text"],
        "negative_prompt": workflow["3"]["inputs"]["text"],
        "input": str(wan_path.relative_to(REPO)).replace("\\", "/"),
        "input_sha256": digest(wan_path),
        "native_input": str(native_path.relative_to(REPO)).replace("\\", "/"),
        "workflow": str(output.relative_to(REPO)).replace("\\", "/"),
        "workflow_sha256": digest(output),
        "status": "planned",
        "prompt_id": None,
        "actual_charge": 0,
    }


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    pose_reason = (
        "Visual QA failed: phase pair remains an effectively static neutral pose with no readable "
        "requested action; canonical VAE input and low denoise overwhelmed the action guide."
    )
    for action in ("bark", "eat"):
        for direction in DIRECTIONS:
            for phase in range(2):
                key = f"{action}/{direction}/phase-{phase}/sdxl-attempt-2"
                if key in manifest["requests"]:
                    manifest["requests"][key]["status"] = "failed_visual_review"
                    manifest["requests"][key]["failure_reason"] = pose_reason

    for action, denoise in (("bark", 0.58), ("eat", 0.60)):
        for phase in range(2):
            _, request = build_pose_retry(action, phase, denoise)
            manifest["requests"][f"{action}/E/phase-{phase}/sdxl-attempt-3"] = request

    fetch_key = "fetch/E/attempt-3"
    if fetch_key in manifest["requests"]:
        manifest["requests"][fetch_key].update(
            {
                "status": "failed_visual_review",
                "prompt_id": "6c173776-66b3-4be7-bc5d-8b04022eff24",
                "failure_reason": "All 17 frames omit the ball; motion reads as walk/step with no clear airborne fetch cycle; body/head proportions drift.",
            }
        )
    _, fetch_request = build_fetch_retry()
    manifest["requests"]["fetch/E/attempt-4"] = fetch_request
    write_json(MANIFEST, manifest)
    write_json(
        WORK / "metadata" / "retry-pilots.json",
        {
            "workflows": [
                "workflows/zampano_bark_E_0_sdxl_attempt-3_api.json",
                "workflows/zampano_bark_E_1_sdxl_attempt-3_api.json",
                "workflows/zampano_eat_E_0_sdxl_attempt-3_api.json",
                "workflows/zampano_eat_E_1_sdxl_attempt-3_api.json",
                "workflows/zampano_fetch_E_attempt-4_api.json",
            ],
            "launch_authorized": False,
            "visual_review_required": True,
        },
    )
    print("wrote 5 versioned retry pilots; no inference submitted")


if __name__ == "__main__":
    main()

