"""Build deterministic S run/fetch cycles from the finalized S canonical."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from build_deterministic_actions import PALETTE, bbox, breathe, load, mask, move_region, upper_mask


WORK = Path(__file__).resolve().parent.parent
OUT = WORK / "deterministic-dynamic"
FRAMES = OUT / "frames"
PREVIEWS = OUT / "previews"
METADATA = OUT / "metadata"
BALL_COLORS = {(220, 242, 58), (152, 180, 24)}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def anchor(rgba: np.ndarray, bottom: int) -> np.ndarray:
    x0, y0, x1, y1 = bbox(mask(rgba))
    center = (x0 + x1 - 1) / 2
    dx = 0 if center in (19.5, 20.0) else round(19.5 - center)
    dy = bottom - (y1 - 1)
    canvas = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    canvas.alpha_composite(Image.fromarray(rgba, "RGBA"), (dx, dy))
    return np.asarray(canvas).copy()


def lower_legs(rgba: np.ndarray) -> np.ndarray:
    alpha = mask(rgba)
    x0, y0, x1, y1 = bbox(alpha)
    ys, xs = np.indices(alpha.shape)
    return alpha & (ys >= y1 - 11) & (xs >= x0 + 3) & (xs < x1 - 3)


def landing_legs(rgba: np.ndarray) -> np.ndarray:
    alpha = mask(rgba)
    x0, y0, x1, y1 = bbox(alpha)
    ys, xs = np.indices(alpha.shape)
    center = (x0 + x1) // 2
    return alpha & (ys >= y1 - 10) & (np.abs(xs - center) >= 2)


def run_cycle(base: np.ndarray) -> list[np.ndarray]:
    # Gather: compact torso with paws locked.
    gather = breathe(base, 2)
    # Push: lift the torso while retaining grounded lower rows.
    push = move_region(base, upper_mask(base), 0, -1, fill_neck=True)
    push = anchor(push, 36)
    # Airborne: tuck both lower legs then lift the complete body two pixels.
    tucked = move_region(base, lower_legs(base), 0, -2, fill_neck=False)
    airborne = anchor(tucked, 34)
    # Landing: lower shoulders and spread visible front/rear leg pixels by one.
    landing = breathe(base, 1)
    leg_mask = landing_legs(landing)
    x0, _, x1, _ = bbox(mask(landing))
    center = (x0 + x1) // 2
    left = leg_mask & (np.indices(leg_mask.shape)[1] < center)
    right = leg_mask & (np.indices(leg_mask.shape)[1] >= center)
    landing = move_region(landing, left, -1, 0, fill_neck=False)
    landing = move_region(landing, right, 1, 0, fill_neck=False)
    landing = anchor(landing, 36)
    return [gather, push, airborne, landing]


def add_ball(rgba: np.ndarray) -> np.ndarray:
    image = Image.fromarray(rgba, "RGBA")
    alpha = mask(rgba)
    _, y0, _, y1 = bbox(alpha)
    cx, cy = 20, y0 + max(7, round((y1 - y0) * 0.30))
    draw = ImageDraw.Draw(image)
    draw.polygon(((cx - 2, cy - 1), (cx - 1, cy - 2), (cx + 1, cy - 2), (cx + 2, cy - 1), (cx + 2, cy + 1), (cx + 1, cy + 2), (cx - 1, cy + 2), (cx - 2, cy + 1)), fill="#98b418")
    draw.rectangle((cx - 1, cy - 1, cx, cy), fill="#dcf23a")
    return np.asarray(image).copy()


def validate(run: list[np.ndarray], fetch: list[np.ndarray]) -> dict[str, object]:
    failures: list[str] = []
    results: dict[str, object] = {}
    source_palette = set(PALETTE)
    for action, frames in (("run", run), ("fetch", fetch)):
        for index, rgba in enumerate(frames):
            alpha = rgba[:, :, 3]
            colors = {tuple(int(v) for v in color) for color in np.unique(rgba[alpha > 0, :3], axis=0)}
            body_colors = colors - BALL_COLORS
            x0, y0, x1, y1 = bbox(alpha > 0)
            expected_bottom = 34 if index == 2 else 36
            ball_ok = action != "fetch" or BALL_COLORS <= colors
            ok = (
                rgba.shape == (40, 40, 4)
                and sorted(int(v) for v in np.unique(alpha)) == [0, 255]
                and body_colors <= source_palette
                and bool(np.all(rgba[alpha == 0, :3] == 0))
                and y1 - 1 == expected_bottom
                and 29 <= x1 - x0 <= 34
                and ball_ok
            )
            if not ok:
                failures.append(f"{action}_S_{index}.png")
            results[f"{action}_S_{index}.png"] = {"bbox": [x0, y0, x1, y1], "ball_ok": ball_ok, "passed": ok}
        if len({hashlib.sha256(frame.tobytes()).hexdigest() for frame in frames}) != 4:
            failures.append(f"{action}: phases are not unique")
    return {"passed": not failures, "failures": failures, "results": results, "visual_review_required": True}


def main() -> None:
    base = load("S")
    run = run_cycle(base)
    fetch = [add_ball(frame) for frame in run]
    for folder in (FRAMES, PREVIEWS, METADATA):
        folder.mkdir(parents=True, exist_ok=True)
    for action, frames in (("run", run), ("fetch", fetch)):
        for index, rgba in enumerate(frames):
            Image.fromarray(rgba, "RGBA").save(FRAMES / f"{action}_S_{index}.png")
        large = [Image.fromarray(frame, "RGBA").resize((200, 200), Image.Resampling.NEAREST) for frame in frames]
        contact = Image.new("RGBA", (800, 220), (0, 0, 0, 0))
        draw = ImageDraw.Draw(contact)
        for index, frame in enumerate(large):
            contact.alpha_composite(frame, (index * 200, 20))
            draw.rectangle((index * 200, 0, index * 200 + 199, 19), fill=(0, 0, 0, 255))
            draw.text((index * 200 + 4, 3), f"{action} S phase {index}", fill=(255, 255, 255, 255))
        contact.save(PREVIEWS / f"{action}-S-contact.png")
        large[0].save(PREVIEWS / f"{action}-S.gif", save_all=True, append_images=large[1:], duration=77, loop=0, disposal=2, transparency=0)
    report = validate(run, fetch)
    (METADATA / "validation.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    provenance = {
        "source": "canonical-native/zampano_S_kontext_v1.png",
        "source_sha256": digest(WORK / "canonical-native" / "zampano_S_kontext_v1.png"),
        "rejected_update2_frames_used": False,
        "method": "hard-pixel component transforms; fetch is the same run body with exact two-color muzzle ball",
        "runtime_installed": False,
    }
    (METADATA / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    if not report["passed"]:
        raise ValueError(f"validation failed: {report['failures']}")
    print("built deterministic S run/fetch pilots")


if __name__ == "__main__":
    main()

