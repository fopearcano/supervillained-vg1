"""Build versioned Kontext direction retries after visual QA failures."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


WORK = Path(__file__).resolve().parent.parent
REPO = WORK.parents[1]
WORKFLOWS = WORK / "workflows"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
E_REF = WORK / "canonical-inputs" / "zampano_E_v1_sdxl_640.png"
N_REF = WORK / "canonical-inputs" / "zampano_N_kontext_v1_sdxl_640.png"
GUIDES = WORK / "guides"

SPECS = {
    "NE": {
        "seed": 611172820002,
        "refs": (E_REF, N_REF),
        "prompt": (
            "Create the exact midpoint view between these two references: the same dog standing on "
            "all four paws in a strict three-quarter rear NE view facing upper-right, mostly showing "
            "his back with only a small right-side sliver of muzzle. Preserve the exact compact low "
            "Maltese proportions, very long shaggy coat, thick curled tail, short legs, and the same "
            "large rounded ears hanging down on both sides. Never use a pure side profile, front view, "
            "upright ears, pointed ears, triangular ears, fox/cat ears or a sitting pose. Exact pale "
            "ivory, blue-gray and dark teal hard-pixel palette, complete centered body on chroma green, "
            "four paws grounded, no shadow, props, text, red, orange or purple."
        ),
    },
    "SE": {
        "seed": 611172830002,
        "refs": (E_REF, GUIDES / "update2_local_zampano_SE_canonical_set-v1_sdxl_640.png"),
        "prompt": (
            "Edit the same exact shaggy Maltese into a strict three-quarter front SE view, STANDING "
            "on all four paws. The body and muzzle must point lower-right; never face or look left and "
            "never sit. Preserve the accepted E dog's compact low proportions, very long shaggy white "
            "coat, thick curled tail, short legs, and large rounded floppy ears hanging down. Never make "
            "ears upright, pointed, triangular, fox-like or cat-like. Exact pale ivory, blue-gray and "
            "dark teal hard-pixel palette, complete centered body on chroma green, no shadow, tongue, "
            "red, orange, purple, props or text."
        ),
    },
    "S": {
        "seed": 611172840002,
        "refs": (E_REF, GUIDES / "update2_local_zampano_S_canonical_set-v1_sdxl_640.png"),
        "prompt": (
            "Edit the same exact shaggy Maltese into a strict symmetrical front S view, STANDING on "
            "all four paws and facing directly toward the camera. Preserve the accepted E dog's compact "
            "low proportions, very long shaggy white coat, short legs, thick curled tail, and especially "
            "two large rounded ears that hang down symmetrically beside the face. Ears must never be "
            "upright, pointed, triangular, fox-like, cat-like or corgi-like; never sit. Exact pale ivory, "
            "blue-gray and dark teal hard-pixel palette, complete centered body on chroma green, no "
            "shadow, tongue, red, orange, purple, props or text."
        ),
    },
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nodes(workflow: dict[str, object], kind: str) -> list[dict[str, object]]:
    return [node for node in workflow["nodes"] if node.get("type") == kind]


def prompt_node(workflow: dict[str, object]) -> dict[str, object]:
    return next(
        node
        for node in workflow["nodes"]
        if isinstance(node.get("widgets_values"), list)
        and len(node["widgets_values"]) >= 6
        and isinstance(node["widgets_values"][1], str)
        and "flux1-dev-kontext" in node["widgets_values"][1]
    )


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    failures = {
        "NE": ("6b04bfcb...", "Remained essentially E/right side profile; no three-quarter rear geometry."),
        "SE": ("5991e965...", "Sitting pose with muzzle facing left/opposite target; black-eye/red-tongue palette contamination."),
        "S": ("091e03d3...", "Front view but wrong corgi-like breed with large upright triangular ears and sitting pose."),
    }
    for direction, spec in SPECS.items():
        old_key = f"canonical/{direction}/kontext-attempt-1"
        manifest["requests"].setdefault(old_key, {}).update(
            {
                "status": "failed_visual_review",
                "prompt_id": failures[direction][0],
                "failure_reason": failures[direction][1],
                "actual_charge": 0,
            }
        )
        template = WORKFLOWS / f"zampano_canonical_{direction}_kontext_attempt-1.json"
        workflow = copy.deepcopy(json.loads(template.read_text(encoding="utf-8")))
        load_nodes = nodes(workflow, "LoadImage")
        if len(load_nodes) != 2:
            raise ValueError(f"{direction}: expected two reference nodes")
        for node, ref in zip(load_nodes, spec["refs"]):
            if not ref.exists():
                raise FileNotFoundError(ref)
            node["widgets_values"][0] = ref.name
        edit = prompt_node(workflow)
        edit["widgets_values"][0] = spec["prompt"]
        edit["widgets_values"][5] = spec["seed"]
        nodes(workflow, "SaveImage")[0]["widgets_values"][0] = f"update2-local-kontext/canonical_{direction}_attempt-2"
        output = WORKFLOWS / f"zampano_canonical_{direction}_kontext_attempt-2.json"
        output.write_text(json.dumps(workflow, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        key = f"canonical/{direction}/kontext-attempt-2"
        manifest["requests"][key] = {
            "engine": "local-flux-kontext",
            "direction": direction,
            "attempt": 2,
            "seed": spec["seed"],
            "prompt": spec["prompt"],
            "reference_images": [ref.name for ref in spec["refs"]],
            "reference_sha256": [digest(ref) for ref in spec["refs"]],
            "workflow": str(output.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": digest(output),
            "status": "planned",
            "prompt_id": None,
            "actual_charge": 0,
        }
        print(output)
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

