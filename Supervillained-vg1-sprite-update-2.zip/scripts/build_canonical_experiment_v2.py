"""Build canonical E experiment 2 with stronger source appearance transfer."""

from __future__ import annotations

import copy
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(__file__).resolve().parents[3]
TEMPLATE = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_tired_E_sdxl_api.json"
UPDATE1 = (
    REPO
    / "sprites-out"
    / "update2"
    / "source-main"
    / "update1"
    / "Supervillained-vg1-sprite-update"
    / "runtime"
    / "public"
    / "sprites"
    / "zampano.png"
)
OLD_INPUTS = REPO / "sprites-out" / "zampano" / "workflows" / "input"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")
SEED = 611172799002


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    guides = WORK / "guides"
    workflows = WORK / "workflows"
    metadata = WORK / "metadata" / "generation-manifest.json"
    guides.mkdir(parents=True, exist_ok=True)

    update1 = Image.open(UPDATE1).convert("RGBA")
    neutral = update1.crop((0, 2 * 40, 40, 3 * 40)).resize((640, 640), Image.Resampling.NEAREST)
    neutral_green = Image.new("RGB", (640, 640), (0, 255, 0))
    neutral_green.paste(neutral.convert("RGB"), (0, 0), neutral.getchannel("A"))
    guide_name = "update2_local_zampano_E_neutral_canny_sdxl.png"
    guide_path = guides / guide_name
    neutral_green.save(guide_path)

    source = Image.open(OLD_INPUTS / "zampano_E_gather_wan_832x480.png").convert("RGB")
    left = (source.width - source.height) // 2
    source = source.crop((left, 0, left + source.height, source.height))
    source = source.resize((640, 640), Image.Resampling.NEAREST)
    source_name = "update2_local_zampano_E_source_profile_sdxl_640.png"
    source_path = guides / source_name
    source.save(source_path)

    shutil.copy2(guide_path, COMFY_INPUT / guide_name)
    shutil.copy2(source_path, COMFY_INPUT / source_name)
    shutil.copy2(
        OLD_INPUTS / "zampano_front_clean_sdxl_640.png",
        COMFY_INPUT / "zampano_front_clean_sdxl_640.png",
    )

    workflow = copy.deepcopy(json.loads(TEMPLATE.read_text(encoding="utf-8")))
    workflow["4"]["inputs"]["image"] = source_name
    workflow["8"]["inputs"]["image"] = guide_name
    workflow["17"]["inputs"]["image"] = "zampano_front_clean_sdxl_640.png"
    workflow["18"]["inputs"].update(
        {"weight": 0.35, "weight_type": "style transfer precise", "end_at": 0.85}
    )
    workflow["19"] = {"class_type": "LoadImage", "inputs": {"image": source_name}}
    workflow["20"] = {
        "class_type": "IPAdapterAdvanced",
        "inputs": {
            "model": ["18", 0],
            "ipadapter": ["3", 1],
            "image": ["19", 0],
            "weight": 0.65,
            "weight_type": "style transfer precise",
            "combine_embeds": "concat",
            "start_at": 0.0,
            "end_at": 0.95,
            "embeds_scaling": "K+V w/ C penalty",
        },
    }
    workflow["5"]["inputs"].update(
        {
            "model": ["20", 0],
            "image": ["4", 0],
            "weight": 0.6,
            "weight_type": "composition precise",
            "start_at": 0.0,
            "end_at": 0.9,
        }
    )
    prompt = (
        "pixel art game sprite of Zampano, the exact same small scruffy long-haired white Maltese "
        "dog as the source reference, complete full body in exact right-facing side profile, "
        "standing naturally on all four paws. Very long shaggy white coat with hanging chest, belly "
        "and leg fur, broad rounded floppy ears hanging beside the face, compact low body and short "
        "legs. Strict pale cream, blue-gray and very dark teal pixel palette; outlines and shadows "
        "are dark teal only, absolutely no purple, magenta or red. Centered isolated character on "
        "flat chroma green, hard square pixels, no floor, no ground and no cast shadow"
    )
    negative = (
        "purple, violet, magenta, red, pink, brown outline, short-haired dog, smooth coat, tall dog, "
        "skinny dog, long legs, pointy ears, upright ears, cat, puppy, extra dog, extra legs, missing "
        "legs, sitting, running, jumping, portrait, close-up, realistic, photograph, 3d, vector art, "
        "blur, antialiasing, scenery, floor, ground, cast shadow, collar, clothes, text, watermark"
    )
    workflow["6"]["inputs"]["text"] = prompt
    workflow["7"]["inputs"]["text"] = negative
    workflow["11"]["inputs"].update({"strength": 0.55, "end_percent": 0.8})
    workflow["13"]["inputs"].update({"seed": SEED, "steps": 30, "denoise": 0.7})
    workflow["16"]["inputs"]["filename_prefix"] = "update2-local-sdxl/canonical_E_shaggy_attempt-2"
    path = workflows / "zampano_canonical_E_shaggy_sdxl_attempt-2_api.json"
    path.write_text(json.dumps(workflow, indent=2) + "\n", encoding="utf-8")

    manifest = json.loads(metadata.read_text(encoding="utf-8"))
    manifest["requests"]["canonical/E/shaggy/sdxl-attempt-2"] = {
        "engine": "local-sdxl-ipadapter-canny",
        "seed": SEED,
        "prompt": prompt,
        "negative_prompt": negative,
        "denoise": 0.7,
        "controlnet_strength": 0.55,
        "composition_input": str(source_path.relative_to(REPO)).replace("\\", "/"),
        "composition_sha256": digest(source_path),
        "canny_guide": str(guide_path.relative_to(REPO)).replace("\\", "/"),
        "canny_guide_sha256": digest(guide_path),
        "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
        "workflow_sha256": digest(path),
        "status": "planned",
        "prompt_id": None,
        "actual_charge": 0,
    }
    metadata.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()

