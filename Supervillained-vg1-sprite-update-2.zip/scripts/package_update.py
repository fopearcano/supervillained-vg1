"""Build the validated SUPERVILLAINED sprite update 2 release archive.

This script deliberately packages only reviewed, final artifacts. It never includes raw
model output or the original source images. The existing release ZIP is left untouched until
the new archive has passed the validation, secret scan, manifest, and ZIP integrity gates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import zipfile


WORK = Path(__file__).resolve().parents[1]
REPO = WORK.parents[1]
DEFAULT_OUTPUT = REPO.parent / "Supervillained-vg1-sprite-update-2.zip"

DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
ACTIONS = {
    "idle": 2,
    "walk": 4,
    "run": 4,
    "sniff": 2,
    "pee": 2,
    "poop": 2,
    "eat": 2,
    "bark": 2,
    "fetch": 4,
    "hurt": 2,
    "tired": 2,
}

GENERATED_SPRITES = (
    "zampano.png",
    "zampano-tired.png",
    "zampanoCross.png",
    "zampanoCross-tired.png",
    "zampanoKnight.png",
    "zampanoKnight-tired.png",
)
SUPPORTING_SPRITES = (
    "bagnaskiz.png",
    "sbrimbrulon.png",
    "jack.png",
    "watson.png",
    "confusione.png",
)
REQUIRED_SPRITES = GENERATED_SPRITES + SUPPORTING_SPRITES
OPTIONAL_SPRITES = ("runIcon.png",)

EXPECTED_SIZES = {
    "zampano.png": (160, 3200),
    "zampano-tired.png": (80, 320),
    "zampanoCross.png": (160, 3200),
    "zampanoCross-tired.png": (80, 320),
    "zampanoKnight.png": (160, 3200),
    "zampanoKnight-tired.png": (80, 320),
    "bagnaskiz.png": (160, 1600),
    "sbrimbrulon.png": (160, 1600),
    "jack.png": (160, 1600),
    "watson.png": (160, 1600),
    "confusione.png": (160, 1600),
}

TEXT_SUFFIXES = {".json", ".md", ".py", ".txt", ".ts", ".js", ".mjs", ".yaml", ".yml"}
FORBIDDEN_PATH_PARTS = {
    "raw",
    "pixel-art-characters",
    "pixelart-characters-variations",
    "source-images",
    "secrets",
}
SECRET_PATTERNS = (
    ("Retro Diffusion key", re.compile(r"rdpk-[A-Za-z0-9_-]{8,}")),
    ("image base64 payload", re.compile(r"data:image/[A-Za-z0-9.+-]+;base64,", re.IGNORECASE)),
    ("long base64 payload", re.compile(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{512,}={0,2}(?![A-Za-z0-9+/])")),
    (
        "unredacted API key assignment",
        re.compile(r"(?:RD_API_KEY|api[_-]?key)\s*[:=]\s*[\"']?(?!redacted|none|null|false)[A-Za-z0-9_-]{16,}", re.IGNORECASE),
    ),
)


class PackageError(RuntimeError):
    """A release gate failed."""


def load_json(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise PackageError(f"missing required file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise PackageError(f"invalid JSON in {path}: {exc}") from exc


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise PackageError(f"not a valid PNG: {path}")
    return struct.unpack(">II", header[16:24])


def git_value(*args: str) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=REPO,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def expected_frames() -> set[str]:
    return {
        f"{action}_{direction}_{phase}.png"
        for action, count in ACTIONS.items()
        for direction in DIRECTIONS
        for phase in range(count)
    }


def require_visual_validation() -> dict[str, object]:
    data = load_json(WORK / "metadata" / "validation.json")
    if not isinstance(data, dict):
        raise PackageError("metadata/validation.json must contain a JSON object")
    if data.get("passed") is not True:
        raise PackageError("mechanical validation has not passed")
    if data.get("partial") is not False:
        raise PackageError("validation is partial; the complete asset set is required")
    visual = data.get("visual_review")
    visual_passed = data.get("visual_review_passed") is True or (
        isinstance(visual, dict) and visual.get("passed") is True
    )
    if not visual_passed:
        raise PackageError("native frames and synchronized previews need recorded visual approval")
    expected = expected_frames()
    actual = {path.name for path in (WORK / "frames").glob("*.png")}
    missing = sorted(expected - actual)
    unexpected = sorted(actual - expected)
    if missing or unexpected:
        raise PackageError(
            f"maintenance frame set is not exact: missing={missing[:8]} unexpected={unexpected[:8]}"
        )
    if data.get("frames_checked") != len(expected):
        raise PackageError(
            f"validation checked {data.get('frames_checked')!r} frames; expected {len(expected)}"
        )
    return data


def require_runtime_sprites() -> list[Path]:
    repo_sprites = REPO / "public" / "sprites"
    generated = WORK / "runtime" / "public" / "sprites"
    result: list[Path] = []
    for name in REQUIRED_SPRITES:
        path = repo_sprites / name
        if not path.is_file():
            raise PackageError(f"integrated runtime sprite is missing: {path}")
        expected = EXPECTED_SIZES[name]
        actual = png_size(path)
        if actual != expected:
            raise PackageError(f"{name} is {actual[0]}x{actual[1]}; expected {expected[0]}x{expected[1]}")
        if name in GENERATED_SPRITES:
            built = generated / name
            if not built.is_file():
                raise PackageError(f"generated release sprite is missing: {built}")
            if sha256(path) != sha256(built):
                raise PackageError(f"repository and generated copies differ: {name}")
        result.append(path)
    for name in OPTIONAL_SPRITES:
        path = repo_sprites / name
        if path.is_file():
            result.append(path)
    return result


def require_nonempty(path: Path, pattern: str = "*") -> list[Path]:
    if not path.is_dir():
        raise PackageError(f"missing required directory: {path}")
    files = sorted(item for item in path.rglob(pattern) if item.is_file())
    if not files:
        raise PackageError(f"required directory is empty: {path}")
    return files


def safe_relative(path: Path, root: Path) -> Path:
    resolved = path.resolve()
    try:
        relative = resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise PackageError(f"file escapes its allowed root: {path}") from exc
    lowered = {part.lower() for part in relative.parts}
    blocked = lowered & FORBIDDEN_PATH_PARTS
    if blocked:
        raise PackageError(f"forbidden source/raw path selected for packaging: {relative} ({sorted(blocked)})")
    return relative


def scan_text(path: Path) -> None:
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise PackageError(f"text artifact is not UTF-8: {path}") from exc
    for label, pattern in SECRET_PATTERNS:
        if pattern.search(text):
            raise PackageError(f"{label} found in package artifact: {path}")


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise PackageError(f"missing package source: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    scan_text(destination)


def copy_tree(source: Path, destination: Path, *, suffixes: set[str] | None = None) -> None:
    files = require_nonempty(source)
    for path in files:
        relative = safe_relative(path, source)
        if suffixes is not None and path.suffix.lower() not in suffixes:
            continue
        copy_file(path, destination / relative)


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def asset_role(name: str) -> str:
    if name.endswith("-tired.png"):
        return "auxiliary tired animation sheet"
    if name.startswith("zampano"):
        return "ten-animation character sheet"
    if name == "runIcon.png":
        return "optional touch RUN icon"
    return "accepted Update 1 supporting character sheet"


def make_app_assets(sprite_paths: list[Path], head: str, branch: str) -> dict[str, object]:
    assets = []
    for path in sorted(sprite_paths, key=lambda item: item.name.lower()):
        width, height = png_size(path)
        assets.append(
            {
                "bytes": path.stat().st_size,
                "path": f"runtime/public/sprites/{path.name}",
                "role": asset_role(path.name),
                "sha256": sha256(path),
                "size": [width, height],
            }
        )
    return {
        "schema": 1,
        "project": "SUPERVILLAINED",
        "update": 2,
        "generation": "fully local ComfyUI; no paid or hosted inference",
        "repository": {"branch": branch, "head": head},
        "assets": assets,
    }


def make_readme(head: str, branch: str, sprite_paths: list[Path]) -> str:
    names = "\n".join(f"- `{path.name}`" for path in sorted(sprite_paths, key=lambda p: p.name.lower()))
    return f"""# SUPERVILLAINED sprite update 2

This archive contains the complete character-art update built locally with ComfyUI. No paid or
hosted generation was used. It targets repository branch `{branch}` at `{head}`.

## Install

Copy `runtime/public/sprites/` over the repository's `public/sprites/` directory. The associated
source changes add the Cross/Knight sheets, separate tired sheets, robust auxiliary-sheet loading,
exhausted movement handling, and ART NEW/OLD support. The repository remains the source of truth.

Runtime files:

{names}

## Verification

- `metadata/validation.json` contains the mechanical and visual-review result.
- `metadata/app-assets.json` records dimensions, sizes, hashes, repository head, and asset roles.
- `metadata/SHA256SUMS.txt` covers every other file in this archive.
- `frames/` contains the individual 40x40 maintenance frames.
- `workflows/` and `scripts/` contain sanitized local ComfyUI reproduction material.
- `previews/`, `reports/`, and `screenshots/` contain the review evidence.

After installation run `npm test`, `npm run build`, `npm run smoke`, and `npm run playtest`.
Use `?debug=sprites&char=zampano`, `zampanoCross`, and `zampanoKnight` for sprite inspection.
"""


def build_stage(stage: Path, validation: dict[str, object], sprite_paths: list[Path]) -> None:
    head = git_value("rev-parse", "HEAD")
    branch = git_value("branch", "--show-current")

    for sprite in sprite_paths:
        copy_file(sprite, stage / "runtime" / "public" / "sprites" / sprite.name)

    metadata = WORK / "metadata"
    for path in require_nonempty(metadata, "*.json"):
        copy_file(path, stage / "metadata" / path.name)
    write_json(stage / "metadata" / "validation.json", validation)
    write_json(stage / "metadata" / "app-assets.json", make_app_assets(sprite_paths, head, branch))

    copy_tree(WORK / "frames", stage / "frames", suffixes={".png"})
    copy_tree(WORK / "workflows", stage / "workflows", suffixes={".json"})
    copy_tree(WORK / "scripts", stage / "scripts", suffixes={".py"})
    copy_tree(WORK / "config", stage / "config", suffixes={".json"})
    copy_tree(WORK / "previews", stage / "previews")
    copy_tree(WORK / "screenshots", stage / "screenshots", suffixes={".png"})

    reports = WORK / "reports"
    if reports.is_dir() and any(path.is_file() for path in reports.rglob("*")):
        copy_tree(reports, stage / "reports")
    else:
        (stage / "reports").mkdir(parents=True, exist_ok=True)
        (stage / "reports" / "BUILD-REPORT.md").write_text(
            "# Build report\n\n"
            f"Repository: `{branch}` at `{head}`.\n\n"
            f"Validated maintenance frames: {validation.get('frames_checked')}.\n\n"
            "Generation used local ComfyUI only; recorded hosted spend is $0.00.\n",
            encoding="utf-8",
        )

    (stage / "README-INTEGRATION.md").write_text(
        make_readme(head, branch, sprite_paths), encoding="utf-8"
    )

    for path in sorted(item for item in stage.rglob("*") if item.is_file()):
        safe_relative(path, stage)
        scan_text(path)

    sums_path = stage / "metadata" / "SHA256SUMS.txt"
    lines = []
    for path in sorted(
        (item for item in stage.rglob("*") if item.is_file() and item != sums_path),
        key=lambda item: item.relative_to(stage).as_posix(),
    ):
        lines.append(f"{sha256(path)}  {path.relative_to(stage).as_posix()}")
    sums_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def zip_stage(stage: Path, output: Path) -> tuple[Path, list[str]]:
    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temp_name = tempfile.mkstemp(
        prefix=f".{output.stem}-", suffix=".tmp.zip", dir=output.parent
    )
    os.close(handle)
    temp = Path(temp_name)
    names: list[str] = []
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(
                (item for item in stage.rglob("*") if item.is_file()),
                key=lambda item: item.relative_to(stage).as_posix(),
            ):
                name = path.relative_to(stage).as_posix()
                archive.write(path, name)
                names.append(name)
        with zipfile.ZipFile(temp, "r") as archive:
            if archive.testzip() is not None:
                raise PackageError("new ZIP failed its CRC integrity check")
            if sorted(archive.namelist()) != sorted(names):
                raise PackageError("new ZIP listing differs from the staged file set")
        return temp, names
    except Exception:
        temp.unlink(missing_ok=True)
        raise


def install_zip(temp: Path, output: Path) -> Path | None:
    backup: Path | None = None
    if output.exists():
        old_hash = sha256(output)[:12]
        backup = output.with_name(f"{output.stem}.previous-{old_hash}{output.suffix}")
        if not backup.exists():
            shutil.copy2(output, backup)
    os.replace(temp, output)
    return backup


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="run every release gate and build a temporary stage without replacing the ZIP",
    )
    args = parser.parse_args()

    validation = require_visual_validation()
    sprite_paths = require_runtime_sprites()
    require_nonempty(WORK / "previews")
    require_nonempty(WORK / "screenshots", "*.png")
    require_nonempty(WORK / "workflows", "*.json")
    require_nonempty(WORK / "scripts", "*.py")

    with tempfile.TemporaryDirectory(prefix=".package-update2-", dir=WORK) as temp_dir:
        stage = Path(temp_dir) / "Supervillained-vg1-sprite-update-2"
        stage.mkdir()
        build_stage(stage, validation, sprite_paths)
        temp_zip, names = zip_stage(stage, args.output)
        if args.check_only:
            temp_zip.unlink(missing_ok=True)
            print(f"package checks passed ({len(names)} files); ZIP was not replaced")
            return
        backup = install_zip(temp_zip, args.output)

    print(f"wrote {args.output} ({len(names)} files, sha256 {sha256(args.output)})")
    if backup:
        print(f"preserved previous archive as {backup}")


if __name__ == "__main__":
    main()
