"""Integrate approved dynamic selections and build/validate the complete plain sheets."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image

from review_outputs import native_wan


WORK = Path(__file__).resolve().parent.parent
RAW = WORK / "raw"
FRAMES = WORK / "frames"
RUNTIME = WORK / "runtime"
PREVIEWS = WORK / "previews" / "animations"
CONFIG = json.loads((WORK / "config" / "actions.json").read_text(encoding="utf-8"))
SELECTIONS = WORK / "metadata" / "selections.json"
PROPOSALS = WORK / "metadata" / "wan-proposed-selections.json"
DETERMINISTIC = WORK / "deterministic-dynamic" / "frames"
VALIDATION = WORK / "metadata" / "validation.json"
AUTHORED = ("N", "NE", "E", "SE", "S")
DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
MIRRORS = {"NW": "NE", "W": "E", "SW": "SE"}
MAIN_ACTIONS = ("idle", "walk", "run", "sniff", "pee", "poop", "eat", "bark", "fetch", "hurt")
PALETTE = {(254, 249, 235), (166, 192, 191), (61, 92, 93), (204, 216, 210), (3, 40, 43), (3, 25, 27), (172, 196, 195), (2, 33, 35)}
BALL = {(220, 242, 58), (152, 180, 24)}
WIDTH_BANDS = {"N": (29, 32), "NE": (32, 35), "E": (34, 38), "SE": (32, 35), "S": (29, 32), "SW": (32, 35), "W": (34, 38), "NW": (32, 35)}


def attempt(action: str, direction: str) -> int:
    return 3 if direction == "E" and action in ("walk", "run") else 4


def raw_path(action: str, direction: str, index: int) -> Path:
    paths = sorted((RAW / action / direction / f"attempt-{attempt(action, direction)}").glob("*.png"))
    if index >= len(paths):
        raise IndexError(f"{action}/{direction}: raw index {index} unavailable")
    return paths[index]


def body_mask(rgba: np.ndarray, action: str) -> np.ndarray:
    result = rgba[:, :, 3] > 0
    if action == "fetch":
        ball = np.zeros(result.shape, dtype=bool)
        for color in BALL:
            ball |= np.all(rgba[:, :, :3] == color, axis=2)
        result &= ~ball
    return result


def bbox(alpha: np.ndarray) -> tuple[int, int, int, int]:
    ys, xs = np.nonzero(alpha)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def desired_bottom(action: str, phase: int) -> int:
    return 34 if action in ("run", "fetch") and phase == 2 else 36


def reanchor(image: Image.Image, action: str, phase: int) -> Image.Image:
    rgba = np.asarray(image.convert("RGBA"))
    x0, y0, x1, y1 = bbox(body_mask(rgba, action))
    center = (x0 + x1 - 1) / 2
    if center < 19.5:
        dx = math.ceil(19.5 - center)
    elif center > 20.0:
        dx = math.floor(20.0 - center)
    else:
        dx = 0
    dy = desired_bottom(action, phase) - (y1 - 1)
    result = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    result.alpha_composite(image, (dx, dy))
    return result


def mirror(image: Image.Image, action: str, phase: int) -> Image.Image:
    return reanchor(image.transpose(Image.Transpose.FLIP_LEFT_RIGHT), action, phase)


def normalize_width(image: Image.Image, action: str, direction: str) -> Image.Image:
    rgba = np.asarray(image.convert("RGBA"))
    body = body_mask(rgba, action)
    x0, _, x1, _ = bbox(body)
    width = x1 - x0
    low, high = WIDTH_BANDS[direction]
    if low <= width <= high:
        return image
    target = low if width < low else high
    alpha = rgba[:, :, 3] > 0
    ux0, uy0, ux1, uy1 = bbox(alpha)
    crop = image.crop((ux0, uy0, ux1, uy1))
    resized_width = max(1, round(crop.width * target / width))
    resized = crop.resize((resized_width, crop.height), Image.Resampling.NEAREST)
    canvas = Image.new("RGBA", (40, 40), (0, 0, 0, 0))
    canvas.alpha_composite(resized, ((40 - resized.width) // 2, uy0))
    return canvas


def integrate() -> dict[str, object]:
    proposal = json.loads(PROPOSALS.read_text(encoding="utf-8"))["selections"]
    selections = json.loads(SELECTIONS.read_text(encoding="utf-8"))
    FRAMES.mkdir(parents=True, exist_ok=True)
    provenance: dict[str, object] = {}
    for action in ("walk", "run", "fetch"):
        for direction in AUTHORED:
            indices = proposal[action][direction]
            for phase, index in enumerate(indices):
                if direction == "S" and action in ("run", "fetch"):
                    source = DETERMINISTIC / f"{action}_S_{phase}.png"
                    frame = Image.open(source).convert("RGBA")
                    source_kind = "deterministic-S-fallback"
                else:
                    source = raw_path(action, direction, index)
                    frame = native_wan(source, direction, action)
                    source_kind = "wan-selected"
                frame = normalize_width(frame, action, direction)
                frame = reanchor(frame, action, phase)
                frame.save(FRAMES / f"{action}_{direction}_{phase}.png")
                provenance[f"{action}/{direction}/{phase}"] = {
                    "source": str(source.relative_to(WORK)).replace("\\", "/"),
                    "source_kind": source_kind,
                    "raw_index": index,
                }
            key = f"{action}/{direction}"
            selection = selections.setdefault(key, {})
            selection.update(
                {
                    "attempt": attempt(action, direction) if not (direction == "S" and action in ("run", "fetch")) else None,
                    "indices": indices,
                    "reviewed": True,
                    "notes": "Approved by parent visual review; S run/fetch use accepted deterministic bobbing fallback." if direction == "S" and action in ("run", "fetch") else "Approved synchronized selection.",
                }
            )

        for target, source_direction in MIRRORS.items():
            for phase in range(4):
                source = Image.open(FRAMES / f"{action}_{source_direction}_{phase}.png").convert("RGBA")
                mirror(source, action, phase).save(FRAMES / f"{action}_{target}_{phase}.png")
    json.loads(PROPOSALS.read_text(encoding="utf-8"))["approved"] = True
    approved = json.loads(PROPOSALS.read_text(encoding="utf-8"))
    approved["approved"] = True
    approved["approval_note"] = "Exact proposals approved by parent visual review."
    PROPOSALS.write_text(json.dumps(approved, indent=2) + "\n", encoding="utf-8")
    SELECTIONS.write_text(json.dumps(selections, indent=2) + "\n", encoding="utf-8")
    (WORK / "metadata" / "dynamic-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    return provenance


def assemble() -> None:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    main = Image.new("RGBA", (160, 3200), (0, 0, 0, 0))
    row = 0
    for action in MAIN_ACTIONS:
        for direction in DIRECTIONS:
            count = int(CONFIG[action]["frames"])
            for phase in range(count):
                main.alpha_composite(Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA"), (phase * 40, row * 40))
            row += 1
    main.save(RUNTIME / "zampano.png")
    tired = Image.new("RGBA", (80, 320), (0, 0, 0, 0))
    for row, direction in enumerate(DIRECTIONS):
        for phase in range(2):
            tired.alpha_composite(Image.open(FRAMES / f"tired_{direction}_{phase}.png").convert("RGBA"), (phase * 40, row * 40))
    tired.save(RUNTIME / "zampano-tired.png")


def previews() -> None:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    for action, data in CONFIG.items():
        count, fps = int(data["frames"]), int(data["fps"])
        phases: list[Image.Image] = []
        for phase in range(count):
            grid = Image.new("RGBA", (640, 320), (0, 0, 0, 0))
            for index, direction in enumerate(DIRECTIONS):
                frame = Image.open(FRAMES / f"{action}_{direction}_{phase}.png").convert("RGBA").resize((160, 160), Image.Resampling.NEAREST)
                grid.alpha_composite(frame, ((index % 4) * 160, (index // 4) * 160))
            phases.append(grid)
        phases[0].save(PREVIEWS / f"{action}.gif", save_all=True, append_images=phases[1:], duration=round(1000 / fps), loop=0 if data["loop"] else 1, disposal=2, transparency=0)


def validate() -> dict[str, object]:
    failures: list[str] = []
    expected = [f"{action}_{direction}_{phase}.png" for action, data in CONFIG.items() for direction in DIRECTIONS for phase in range(int(data["frames"]))]
    results: dict[str, object] = {}
    for name in expected:
        action, direction, phase_text = name[:-4].rsplit("_", 2)
        phase = int(phase_text)
        path = FRAMES / name
        if not path.exists():
            failures.append(f"missing {name}")
            continue
        rgba = np.asarray(Image.open(path).convert("RGBA"))
        alpha = rgba[:, :, 3]
        colors = {tuple(int(v) for v in color) for color in np.unique(rgba[alpha > 0, :3], axis=0)}
        body = body_mask(rgba, action)
        x0, y0, x1, y1 = bbox(body)
        center = (x0 + x1 - 1) / 2
        allowed = PALETTE | (BALL if action == "fetch" else set())
        ball_ok = action != "fetch" or BALL <= colors
        ok = (
            rgba.shape == (40, 40, 4)
            and sorted(int(v) for v in np.unique(alpha)) == [0, 255]
            and colors <= allowed
            and bool(np.all(rgba[alpha == 0, :3] == 0))
            and y1 - 1 == desired_bottom(action, phase)
            and center in (19.5, 20.0)
            and WIDTH_BANDS[direction][0] <= x1 - x0 <= WIDTH_BANDS[direction][1]
            and ball_ok
        )
        if not ok:
            failures.append(name)
        results[name] = {"bbox": [x0, y0, x1, y1], "ball_ok": ball_ok, "passed": ok}
    for action, data in CONFIG.items():
        for target, source_direction in MIRRORS.items():
            for phase in range(int(data["frames"])):
                source = Image.open(FRAMES / f"{action}_{source_direction}_{phase}.png").convert("RGBA")
                target_image = np.asarray(Image.open(FRAMES / f"{action}_{target}_{phase}.png").convert("RGBA"))
                if not np.array_equal(np.asarray(mirror(source, action, phase)), target_image):
                    failures.append(f"mirror {action}/{target}/{phase}")
    sheets = {"zampano.png": (160, 3200), "zampano-tired.png": (80, 320)}
    for name, size in sheets.items():
        path = RUNTIME / name
        if not path.exists() or Image.open(path).size != size:
            failures.append(f"sheet {name}")
    report = {"passed": not failures, "expected_frames": len(expected), "frames_checked": len(results), "failures": failures, "results": results, "sheets": {name: list(size) for name, size in sheets.items()}, "visual_review": "approved dynamic proposals; deterministic static pilot approved; final all-direction GIF review still required before repository runtime install"}
    VALIDATION.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main() -> None:
    integrate()
    assemble()
    previews()
    report = validate()
    if not report["passed"]:
        raise ValueError(f"plain validation failed: {len(report['failures'])} failures")
    print("integrated approved dynamics and validated complete plain sheets")


if __name__ == "__main__":
    main()

