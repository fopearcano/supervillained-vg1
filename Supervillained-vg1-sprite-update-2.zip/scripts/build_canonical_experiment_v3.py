"""Version canonical E experiment 3 from the source-like attempt-2 graph."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path(__file__).resolve().parents[3]
SOURCE = WORK / "workflows" / "zampano_canonical_E_shaggy_sdxl_attempt-2_api.json"
OUTPUT = WORK / "workflows" / "zampano_canonical_E_shaggy_sdxl_attempt-3_api.json"
MANIFEST = WORK / "metadata" / "generation-manifest.json"
SEED = 611172799003


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    workflow = json.loads(SOURCE.read_text(encoding="utf-8"))
    prompt = (
        "pixel art game sprite of Zampano, the exact same small scruffy long-haired white Maltese "
        "dog as the source reference, complete full body in strict exact right-facing side profile. "
        "The head, muzzle and body all point directly right; exactly one eye is visible; mouth fully "
        "closed with no tongue. Standing naturally on all four paws. Very long shaggy white coat "
        "hangs from chest, belly and legs; broad rounded floppy ears hang beside the face; compact low "
        "body and short legs. Strict pale cream, blue-gray and dark teal pixel palette; every outline "
        "is dark teal, never black, purple, magenta or red. Centered isolated character on flat chroma "
        "green, hard square pixels, no floor, no ground and no cast shadow"
    )
    negative = (
        "three-quarter view, 3/4 view, front-facing head, looking at viewer, two visible eyes, open "
        "mouth, tongue, teeth, purple, violet, magenta, red, pink, pure black outline, short-haired "
        "dog, smooth coat, tall dog, skinny dog, long legs, pointy ears, upright ears, cat, puppy, "
        "extra dog, extra legs, missing legs, sitting, running, jumping, portrait, close-up, realistic, "
        "photograph, 3d, vector art, blur, antialiasing, scenery, floor, ground, cast shadow, collar, "
        "clothes, text, watermark"
    )
    workflow["6"]["inputs"]["text"] = prompt
    workflow["7"]["inputs"]["text"] = negative
    workflow["11"]["inputs"].update({"strength": 0.72, "end_percent": 0.84})
    workflow["13"]["inputs"].update({"seed": SEED, "steps": 30, "denoise": 0.62})
    workflow["16"]["inputs"]["filename_prefix"] = "update2-local-sdxl/canonical_E_shaggy_attempt-3"
    OUTPUT.write_text(json.dumps(workflow, indent=2) + "\n", encoding="utf-8")

    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    request = dict(manifest["requests"]["canonical/E/shaggy/sdxl-attempt-2"])
    request.update(
        {
            "seed": SEED,
            "prompt": prompt,
            "negative_prompt": negative,
            "denoise": 0.62,
            "controlnet_strength": 0.72,
            "workflow": str(OUTPUT.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": digest(OUTPUT),
            "status": "planned",
            "prompt_id": None,
        }
    )
    manifest["requests"]["canonical/E/shaggy/sdxl-attempt-3"] = request
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()

