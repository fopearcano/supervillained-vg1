"""Build N/NE/SE/S canonical-view workflows from the accepted E appearance."""

from __future__ import annotations

import copy
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image


WORK = Path(__file__).resolve().parent.parent
REPO = Path(__file__).resolve().parents[3]
TEMPLATE = REPO / "sprites-out" / "zampano" / "workflows" / "zampano_tired_E_sdxl_api.json"
UPDATE1 = REPO / "sprites-out" / "update2" / "source-main" / "update1" / "Supervillained-vg1-sprite-update" / "runtime" / "public" / "sprites" / "zampano.png"
FRONT = REPO / "sprites-out" / "zampano" / "workflows" / "input" / "zampano_front_clean_sdxl_640.png"
APPEARANCE = WORK / "canonical-inputs" / "zampano_E_v1_sdxl_640.png"
COMFY_INPUT = Path(r"E:\CodexComfyUI\workspace\input")
DIRECTIONS = {
    "N": "strict rear view facing directly away; face and eyes are not visible",
    "NE": "strict three-quarter rear view facing upper right; mostly the back and right side are visible",
    "SE": "strict three-quarter front view facing lower right; body and muzzle point diagonally right",
    "S": "strict front view facing directly toward the camera; body is symmetrical",
}
ROWS = {"N": 0, "NE": 1, "SE": 3, "S": 4}
BASE_SEED = 611172810000


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    guides = WORK / "guides"
    workflows = WORK / "workflows"
    manifest_path = WORK / "metadata" / "generation-manifest.json"
    guides.mkdir(parents=True, exist_ok=True)
    sheet = Image.open(UPDATE1).convert("RGBA")
    shutil.copy2(APPEARANCE, COMFY_INPUT / APPEARANCE.name)
    shutil.copy2(FRONT, COMFY_INPUT / FRONT.name)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    template = json.loads(TEMPLATE.read_text(encoding="utf-8"))

    for index, (direction, view) in enumerate(DIRECTIONS.items()):
        neutral = sheet.crop((0, ROWS[direction] * 40, 40, ROWS[direction] * 40 + 40))
        large = neutral.resize((640, 640), Image.Resampling.NEAREST)
        green = Image.new("RGB", (640, 640), (0, 255, 0))
        green.paste(large.convert("RGB"), (0, 0), large.getchannel("A"))
        guide_name = f"zampano_{direction}_canonical_guide_v1_sdxl_640.png"
        guide_path = guides / guide_name
        green.save(guide_path)
        shutil.copy2(guide_path, COMFY_INPUT / guide_name)

        workflow = copy.deepcopy(template)
        workflow["4"]["inputs"]["image"] = guide_name
        workflow["8"]["inputs"]["image"] = guide_name
        workflow["17"]["inputs"]["image"] = APPEARANCE.name
        workflow["18"]["inputs"].update(
            {"weight": 0.65, "weight_type": "style transfer precise", "end_at": 0.9}
        )
        workflow["19"] = {"class_type": "LoadImage", "inputs": {"image": FRONT.name}}
        workflow["20"] = {
            "class_type": "IPAdapterAdvanced",
            "inputs": {
                "model": ["18", 0],
                "ipadapter": ["3", 1],
                "image": ["19", 0],
                "weight": 0.35,
                "weight_type": "style transfer precise",
                "combine_embeds": "concat",
                "start_at": 0.0,
                "end_at": 0.85,
                "embeds_scaling": "K+V w/ C penalty",
            },
        }
        workflow["5"]["inputs"].update(
            {
                "model": ["20", 0],
                "image": ["4", 0],
                "weight": 0.62,
                "weight_type": "composition precise",
                "end_at": 0.9,
            }
        )
        prompt = (
            "pixel art game sprite of Zampano, the exact same small scruffy long-haired white Maltese "
            f"dog as the appearance reference, complete full body in {view}. Standing naturally on all "
            "four paws with compact low body, short legs, long shaggy white coat and broad rounded floppy "
            "ears. Preserve the E canonical breed, head/body proportions, coat, lighting and dark-teal "
            "outline. Strict pale cream, blue-gray and dark teal palette with no purple, red or pure black. "
            "Centered isolated character on flat chroma green, hard square pixels, no ground or shadow"
        )
        negative = (
            "wrong facing, side profile, rotated camera, open mouth, tongue, purple, magenta, red, pure "
            "black outline, short-haired dog, smooth coat, tall dog, pointy ears, upright ears, cat, extra "
            "dog, extra legs, missing legs, sitting, running, jumping, portrait, realistic, photograph, 3d, "
            "vector art, blur, antialiasing, scenery, floor, ground, cast shadow, text, watermark"
        )
        seed = BASE_SEED + index + 1
        workflow["6"]["inputs"]["text"] = prompt
        workflow["7"]["inputs"]["text"] = negative
        workflow["11"]["inputs"].update({"strength": 0.72, "end_percent": 0.86})
        workflow["13"]["inputs"].update({"seed": seed, "steps": 30, "denoise": 0.66})
        workflow["16"]["inputs"]["filename_prefix"] = f"update2-local-sdxl/canonical_{direction}_attempt-1"
        path = workflows / f"zampano_canonical_{direction}_sdxl_attempt-1_api.json"
        path.write_text(json.dumps(workflow, indent=2) + "\n", encoding="utf-8")
        manifest["requests"][f"canonical/{direction}/sdxl-attempt-1"] = {
            "engine": "local-sdxl-ipadapter-canny",
            "seed": seed,
            "prompt": prompt,
            "negative_prompt": negative,
            "denoise": 0.66,
            "controlnet_strength": 0.72,
            "appearance_reference": str(APPEARANCE.relative_to(REPO)).replace("\\", "/"),
            "appearance_sha256": digest(APPEARANCE),
            "direction_guide": str(guide_path.relative_to(REPO)).replace("\\", "/"),
            "direction_guide_sha256": digest(guide_path),
            "workflow": str(path.relative_to(REPO)).replace("\\", "/"),
            "workflow_sha256": digest(path),
            "status": "planned",
            "prompt_id": None,
            "actual_charge": 0,
        }
        print(path)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

