"""Render unapproved synchronized Wan/deterministic selection pilots."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw

from review_outputs import native_wan


WORK = Path(__file__).resolve().parent.parent
RAW = WORK / "raw"
OUT = WORK / "previews" / "wan-selection-pilots"
DETERMINISTIC = WORK / "deterministic-dynamic" / "frames"
DIRECTIONS = ("N", "NE", "E", "SE", "S")
FPS = {"walk": 9, "run": 13, "fetch": 13}
PROPOSALS = {
    "walk": {"N": [1, 4, 8, 13], "NE": [1, 4, 8, 13], "E": [1, 4, 8, 12], "SE": [1, 4, 8, 12], "S": [1, 5, 10, 15]},
    "run": {"N": [1, 4, 8, 13], "NE": [1, 4, 8, 13], "E": [1, 3, 5, 9], "SE": [1, 5, 11, 15], "S": [0, 1, 2, 3]},
    "fetch": {"N": [1, 4, 8, 13], "NE": [1, 4, 8, 13], "E": [1, 4, 6, 8], "SE": [1, 3, 4, 6], "S": [0, 1, 2, 3]},
}


def attempt(action: str, direction: str) -> int:
    return 3 if direction == "E" and action in ("walk", "run") else 4


def raw_path(action: str, direction: str, index: int) -> Path:
    paths = sorted((RAW / action / direction / f"attempt-{attempt(action, direction)}").glob("*.png"))
    if index >= len(paths):
        raise IndexError(f"{action}/{direction}: {index} >= {len(paths)}")
    return paths[index]


def native(action: str, direction: str, phase: int, index: int) -> Image.Image:
    if direction == "S" and action in ("run", "fetch"):
        return Image.open(DETERMINISTIC / f"{action}_S_{phase}.png").convert("RGBA")
    return native_wan(raw_path(action, direction, index), direction, action)


def raw_thumb(action: str, direction: str, phase: int, index: int) -> Image.Image:
    if direction == "S" and action in ("run", "fetch"):
        frame = native(action, direction, phase, index).resize((120, 120), Image.Resampling.NEAREST)
        canvas = Image.new("RGB", (208, 120), (20, 20, 20))
        canvas.paste(frame.convert("RGB"), (44, 0), frame.getchannel("A"))
        return canvas
    return Image.open(raw_path(action, direction, index)).convert("RGB").resize((208, 120), Image.Resampling.NEAREST)


def build_action(action: str) -> None:
    raw_gif: list[Image.Image] = []
    native_gif: list[Image.Image] = []
    for phase in range(4):
        raw_grid = Image.new("RGB", (len(DIRECTIONS) * 208, 140), (20, 20, 20))
        raw_draw = ImageDraw.Draw(raw_grid)
        native_grid = Image.new("RGBA", (len(DIRECTIONS) * 160, 180), (0, 0, 0, 0))
        native_draw = ImageDraw.Draw(native_grid)
        for column, direction in enumerate(DIRECTIONS):
            index = PROPOSALS[action][direction][phase]
            raw_grid.paste(raw_thumb(action, direction, phase, index), (column * 208, 20))
            raw_draw.rectangle((column * 208, 0, column * 208 + 207, 19), fill=(0, 0, 0))
            raw_draw.text((column * 208 + 4, 3), f"{direction} p{phase} raw {index}", fill=(255, 255, 255))
            frame = native(action, direction, phase, index).resize((160, 160), Image.Resampling.NEAREST)
            native_grid.alpha_composite(frame, (column * 160, 20))
            native_draw.rectangle((column * 160, 0, column * 160 + 159, 19), fill=(0, 0, 0, 255))
            native_draw.text((column * 160 + 3, 3), f"{direction} p{phase} {index}", fill=(255, 255, 255, 255))
        raw_gif.append(raw_grid)
        native_gif.append(native_grid)
    duration = round(1000 / FPS[action])
    raw_gif[0].save(OUT / f"{action}-authored-raw.gif", save_all=True, append_images=raw_gif[1:], duration=duration, loop=0, disposal=2)
    native_gif[0].save(OUT / f"{action}-authored-native.gif", save_all=True, append_images=native_gif[1:], duration=duration, loop=0, disposal=2, transparency=0)
    raw_contact = Image.new("RGB", (raw_gif[0].width, raw_gif[0].height * 4), (20, 20, 20))
    native_contact = Image.new("RGBA", (native_gif[0].width, native_gif[0].height * 4), (0, 0, 0, 0))
    for phase in range(4):
        raw_contact.paste(raw_gif[phase], (0, phase * raw_gif[phase].height))
        native_contact.alpha_composite(native_gif[phase], (0, phase * native_gif[phase].height))
    raw_contact.save(OUT / f"{action}-authored-raw-contact.png")
    native_contact.save(OUT / f"{action}-authored-native-contact.png")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for action in PROPOSALS:
        build_action(action)
    (WORK / "metadata" / "wan-proposed-selections.json").write_text(
        json.dumps({"approved": False, "selections": PROPOSALS, "notes": "Proposal only; selections.json is unchanged."}, indent=2) + "\n",
        encoding="utf-8",
    )
    print("wrote synchronized proposal contacts/GIFs; no selections approved")


if __name__ == "__main__":
    main()

