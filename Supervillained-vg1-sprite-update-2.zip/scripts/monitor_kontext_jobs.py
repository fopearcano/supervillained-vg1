"""Monitor already-submitted local ComfyUI jobs and recover their outputs to C:.

This script never submits prompts.  It only talks to the loopback ComfyUI REST
API, polls job history, downloads the single SaveImage result for each recorded
prompt id, and updates the sanitized C:-side job ledger atomically.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


WORK = Path(__file__).resolve().parent.parent
DEFAULT_LEDGER = WORK / "metadata" / "kontext-jobs.json"
DEFAULT_BASE_URL = "http://127.0.0.1:8190"
TERMINAL = {"completed", "error", "cancelled_not_run"}


class MonitorError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    with temp.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)


def load_ledger(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise MonitorError(f"cannot read job ledger {path}: {exc}") from exc
    if not isinstance(value, dict) or not isinstance(value.get("jobs"), dict):
        raise MonitorError(f"invalid job ledger: {path}")
    for key, job in value["jobs"].items():
        if not isinstance(key, str) or not isinstance(job, dict):
            raise MonitorError(f"invalid job entry: {key!r}")
        prompt_id = job.get("prompt_id")
        if not isinstance(prompt_id, str) or not prompt_id:
            raise MonitorError(f"{key}: missing prompt_id")
        output_dir = job.get("output_dir")
        if not isinstance(output_dir, str) or not output_dir:
            raise MonitorError(f"{key}: missing output_dir")
        target = (WORK / output_dir).resolve()
        try:
            target.relative_to(WORK.resolve())
        except ValueError as exc:
            raise MonitorError(f"{key}: output_dir escapes workspace") from exc
    return value


def validate_base_url(value: str) -> str:
    parsed = urllib.parse.urlparse(value.rstrip("/"))
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise MonitorError("base URL must be loopback HTTP")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment or parsed.username or parsed.password:
        raise MonitorError("base URL must not include credentials, path, query, or fragment")
    return value.rstrip("/")


def request_bytes(url: str, timeout: float = 60) -> bytes:
    request = urllib.request.Request(url, method="GET", headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, OSError) as exc:
        raise MonitorError(f"loopback request failed: {type(exc).__name__}: {exc}") from exc


def history(base_url: str, prompt_id: str) -> dict[str, Any] | None:
    body = request_bytes(base_url + "/history/" + urllib.parse.quote(prompt_id), timeout=20)
    try:
        value = json.loads(body)
    except json.JSONDecodeError as exc:
        raise MonitorError("ComfyUI history returned non-JSON data") from exc
    record = value.get(prompt_id) if isinstance(value, dict) else None
    return record if isinstance(record, dict) else None


def output_image(record: dict[str, Any]) -> dict[str, str]:
    outputs = record.get("outputs")
    if not isinstance(outputs, dict):
        raise MonitorError("completed job has no outputs object")
    images: list[dict[str, str]] = []
    for node in outputs.values():
        if not isinstance(node, dict) or not isinstance(node.get("images"), list):
            continue
        for image in node["images"]:
            if not isinstance(image, dict) or not isinstance(image.get("filename"), str):
                continue
            images.append(
                {
                    "filename": image["filename"],
                    "subfolder": str(image.get("subfolder", "")),
                    "type": str(image.get("type", "output")),
                }
            )
    if len(images) != 1:
        raise MonitorError(f"expected exactly one SaveImage output, got {len(images)}")
    return images[0]


def event_times(record: dict[str, Any]) -> tuple[str | None, str | None]:
    status = record.get("status") if isinstance(record.get("status"), dict) else {}
    messages = status.get("messages") if isinstance(status.get("messages"), list) else []
    started_ms: int | None = None
    completed_ms: int | None = None
    for message in messages:
        if not isinstance(message, list) or len(message) < 2 or not isinstance(message[1], dict):
            continue
        timestamp = message[1].get("timestamp")
        if not isinstance(timestamp, (int, float)):
            continue
        if message[0] == "execution_start":
            started_ms = int(timestamp)
        elif message[0] == "execution_success":
            completed_ms = int(timestamp)
    def stamp(value: int | None) -> str | None:
        return datetime.fromtimestamp(value / 1000, timezone.utc).isoformat(timespec="milliseconds") if value else None
    return stamp(started_ms), stamp(completed_ms)


def execution_error(record: dict[str, Any]) -> str | None:
    status = record.get("status") if isinstance(record.get("status"), dict) else {}
    status_text = str(status.get("status_str", "")).lower()
    messages = status.get("messages") if isinstance(status.get("messages"), list) else []
    for message in messages:
        if isinstance(message, list) and message and message[0] == "execution_error":
            detail = message[1] if len(message) > 1 and isinstance(message[1], dict) else {}
            return str(detail.get("exception_message") or detail.get("exception_type") or "ComfyUI execution error")[:1000]
    if status_text in {"error", "failed"}:
        return f"ComfyUI status: {status_text}"
    return None


def completed(record: dict[str, Any]) -> bool:
    status = record.get("status") if isinstance(record.get("status"), dict) else {}
    return bool(status.get("completed")) or str(status.get("status_str", "")).lower() == "success"


def recover_output(base_url: str, key: str, job: dict[str, Any], record: dict[str, Any]) -> dict[str, Any]:
    image = output_image(record)
    suffix = Path(image["filename"]).suffix.lower()
    if suffix not in {".png", ".jpg", ".jpeg", ".webp"}:
        raise MonitorError(f"{key}: unexpected output extension {suffix}")
    output_dir = (WORK / str(job["output_dir"])).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / ("kontext_000" + suffix)
    temp = target.with_suffix(target.suffix + f".{os.getpid()}.part")
    query = urllib.parse.urlencode(image)
    request = urllib.request.Request(base_url + "/view?" + query, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=120) as response, temp.open("xb") as handle:
            while chunk := response.read(1024 * 1024):
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
        if temp.stat().st_size == 0:
            raise MonitorError(f"{key}: downloaded output is empty")
        incoming_hash = sha256(temp)
        if target.exists():
            existing_hash = sha256(target)
            if existing_hash != incoming_hash:
                raise MonitorError(f"{key}: refusing to overwrite mismatched output {target}")
            temp.unlink()
        else:
            os.replace(temp, target)
        started_at, completed_at = event_times(record)
        relative = target.relative_to(WORK).as_posix()
        return {
            "status": "completed",
            "started_at": started_at,
            "completed_at": completed_at or utc_now(),
            "output": relative,
            "output_sha256": incoming_hash,
            "output_bytes": target.stat().st_size,
            "source_image": image,
        }
    except Exception:
        temp.unlink(missing_ok=True)
        raise


def counts(jobs: dict[str, Any]) -> dict[str, int]:
    values = list(jobs.values())
    return {
        "completed": sum(job.get("status") == "completed" for job in values),
        "running": sum(job.get("status") == "running" for job in values),
        "queued": sum(job.get("status") == "queued" for job in values),
        "error": sum(job.get("status") == "error" for job in values),
        "cancelled": sum(job.get("status") == "cancelled_not_run" for job in values),
        "total": len(values),
    }


def cancel_remaining(ledger_path: Path, reason: str) -> dict[str, int]:
    ledger = load_ledger(ledger_path)
    cancelled_at = utc_now()
    for job in ledger["jobs"].values():
        if job.get("status") == "completed":
            continue
        job.update(
            {
                "status": "cancelled_not_run",
                "cancelled_at": cancelled_at,
                "cancel_reason": reason,
            }
        )
        job.pop("error", None)
        job.pop("failed_at", None)
    ledger["updated_at"] = cancelled_at
    atomic_write(ledger_path, ledger)
    return counts(ledger["jobs"])


def monitor(ledger_path: Path, base_url: str, poll: float, timeout: float, progress_interval: float) -> None:
    ledger = load_ledger(ledger_path)
    jobs = ledger["jobs"]
    deadline = time.monotonic() + timeout
    last_progress = 0.0
    last_counts: dict[str, int] | None = None
    while True:
        changed = False
        for key, job in jobs.items():
            if job.get("status") in TERMINAL:
                continue
            record = history(base_url, str(job["prompt_id"]))
            if record is None:
                continue
            error = execution_error(record)
            if error:
                job.update({"status": "error", "error": error, "failed_at": utc_now()})
                ledger["updated_at"] = utc_now()
                atomic_write(ledger_path, ledger)
                raise MonitorError(f"{key}: {error}")
            if completed(record):
                job.update(recover_output(base_url, key, job, record))
                job.pop("error", None)
                changed = True
                ledger["updated_at"] = utc_now()
                atomic_write(ledger_path, ledger)
                current = counts(jobs)
                print(f"completed {key} ({current['completed']}/{current['total']})", flush=True)
            elif job.get("status") != "running":
                job["status"] = "running"
                job["observed_running_at"] = utc_now()
                changed = True
        if changed:
            ledger["updated_at"] = utc_now()
            atomic_write(ledger_path, ledger)
        current = counts(jobs)
        if current["completed"] == current["total"]:
            print(json.dumps(current, sort_keys=True), flush=True)
            return
        if current["error"]:
            raise MonitorError(f"job ledger contains {current['error']} error(s)")
        now = time.monotonic()
        if last_counts != current or now - last_progress >= progress_interval:
            print(json.dumps(current, sort_keys=True), flush=True)
            last_progress = now
            last_counts = current
        if now >= deadline:
            raise MonitorError(f"timed out after {timeout:g}s with {current['completed']}/{current['total']} complete")
        time.sleep(poll)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", type=Path, default=DEFAULT_LEDGER)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--poll", type=float, default=3.0)
    parser.add_argument("--timeout", type=float, default=4 * 60 * 60)
    parser.add_argument("--progress-interval", type=float, default=30.0)
    parser.add_argument("--cancel-remaining", action="store_true")
    parser.add_argument("--cancel-reason", default="queue cancelled after visual review")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    try:
        if args.poll <= 0 or args.timeout <= 0 or args.progress_interval <= 0:
            raise MonitorError("poll, timeout, and progress interval must be positive")
        if args.cancel_remaining:
            print(json.dumps(cancel_remaining(args.ledger.resolve(), args.cancel_reason), sort_keys=True))
            return
        monitor(args.ledger.resolve(), validate_base_url(args.base_url), args.poll, args.timeout, args.progress_interval)
    except (MonitorError, OSError, ValueError) as exc:
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
