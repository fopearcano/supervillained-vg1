# SUPERVILLAINED sprite update 2

This archive contains the complete character-art update built locally with ComfyUI. No paid or
hosted generation was used. It targets repository branch `claude/gallant-pascal-wjy5l2` at `8d066425cced354314ea6fb3ba612351f9296174`.

## Install

Copy `runtime/public/sprites/` over the repository's `public/sprites/` directory. The associated
source changes add the Cross/Knight sheets, separate tired sheets, robust auxiliary-sheet loading,
exhausted movement handling, and ART NEW/OLD support. The repository remains the source of truth.

Runtime files:

- `bagnaskiz.png`
- `confusione.png`
- `jack.png`
- `runIcon.png`
- `sbrimbrulon.png`
- `watson.png`
- `zampano-tired.png`
- `zampano.png`
- `zampanoCross-tired.png`
- `zampanoCross.png`
- `zampanoKnight-tired.png`
- `zampanoKnight.png`

## Verification

- `metadata/validation.json` contains the mechanical and visual-review result.
- `metadata/app-assets.json` records dimensions, sizes, hashes, repository head, and asset roles.
- `metadata/SHA256SUMS.txt` covers every other file in this archive.
- `frames/` contains the individual 40x40 maintenance frames.
- `workflows/` and `scripts/` contain sanitized local ComfyUI reproduction material.
- `previews/`, `reports/`, and `screenshots/` contain the review evidence.

After installation run `npm test`, `npm run build`, `npm run smoke`, and `npm run playtest`.
Use `?debug=sprites&char=zampano`, `zampanoCross`, and `zampanoKnight` for sprite inspection.
