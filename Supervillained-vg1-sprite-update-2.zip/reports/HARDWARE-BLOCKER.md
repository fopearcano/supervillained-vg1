# Local generation hardware blocker

Recorded: 2026-11-17 23:49 Europe/Rome

## Resolution

Historical incident only. After a true cold boot on 2026-11-18 the volume and local ComfyUI
returned to stable operation. The required local generation was completed and every fetched
output used in the release was copied and validated on `C:`. The archive does not require the
affected volume at install time. The device incident remains documented here because it caused
the interrupted attempts and informed the C:-only recovery workflow.

The local ComfyUI batch was stopped after Windows reported repeated I/O failures for the NVMe volume mounted as `E:` (`MEFISTOFELE`). This volume contains the active ComfyUI workspace and part of the model inventory.

Observed evidence:

- ComfyUI failed while reading a model tensor with `HostBuffer.read_file_slice failed`.
- Python and Git subsequently failed to read files under `E:\CodexComfyUI\workspace` with `OSError: [Errno 22] Invalid argument` / status `0xC0000006` (`STATUS_IN_PAGE_ERROR`).
- Windows System log emitted repeated `disk` event 51 warnings for `\Device\Harddisk1\DR1`.
- Windows emitted NTFS event 140: transaction-log flush failed for `E:` because the device did not exist.
- Windows emitted NTFS event 50: delayed write failed for `E:\$Mft`; data may have been lost.
- The affected device was identified in the event as `Samsung SSD 990 PRO 2TB`, NVMe, firmware `8B2QJXD7`.
- ComfyUI stopped listening on `127.0.0.1:8190`, and restart failed because `main.py` could no longer be read.
- The Samsung device disappeared from `Get-Disk` while the stale `E:` volume object remained visible.

Safety response:

- Stopped all writes to `E:`.
- Did not run CHKDSK, remount, reset, firmware update, or other repair operations.
- Preserved the game repository changes, workflows, manifests, accepted E canonical, and fetched generation outputs on `C:`.
- No paid Retro Diffusion request was made; spend remains `$0.00`.

Resume requirement:

After the drive has been safely backed up and restored to stable operation, restart the local ComfyUI at `127.0.0.1:8190` and resume the exact 95-workflow local batch with `scripts/run_local_batch.py --resume`.
