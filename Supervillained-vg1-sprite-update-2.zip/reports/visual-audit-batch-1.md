# Local batch visual audit — attempt set 1

No selection was marked reviewed or accepted by this audit.

## SDXL attempt 2

### Bark — failed

All N/NE/E/SE/S phase pairs remain effectively static neutral poses. There is no readable
head thrust or open-mouth bark. Cross-direction body/head proportions also remain inconsistent
(especially the blocky, short-coated SE silhouette).

Retry: action guide as VAE/composition input; accepted canonical only as IP-Adapter identity;
denoise `0.58`, Canny `0.8`, composition IP `0.45`, identity IP `0.65`.

### Eat — failed

All direction/phase pairs remain neutral. Neither phase lowers the muzzle or produces a distinct
chewing motion. The visual result is nearly the same as bark.

Retry: action guide as VAE/composition input; accepted canonical only as identity; denoise `0.60`,
Canny `0.8`, composition IP `0.45`, identity IP `0.65`.

## Wan attempt 3

### Fetch E — failed

All 17 frames omit the required ball. Motion reads as a walk/step rather than a four-phase fetch
bound, with no clear airborne phase and visible body/head proportion drift.

Retry: a versioned canonical input with the exact `#dcf23a` / `#98b418` ball already attached to
the muzzle, an explicit bounding-run prompt, and missing/disappearing/dropped/duplicate ball
negatives.

### Walk E — conditional pass

Identity is stable enough and several distinct leg poses are available, though the motion is
subtle and crouchy. First loop candidates: `[1,4,8,12]`; alternate evenly timed candidates:
`[1,5,9,13]`. Foot sliding and the loop seam still require review.

### Run E — pass candidate

Frames 1–9 contain a readable gather, extension, flight and landing sequence. Frames 10–16
become upright/deformed and should not be used. First loop candidates: `[1,3,5,9]`; frame 8 is
an alternate landing. Detached generated shadow/line pixels must be removed in cleanup.

## Review evidence

Raw and 40px nearest/palette previews are under `previews/batch-review/`.

