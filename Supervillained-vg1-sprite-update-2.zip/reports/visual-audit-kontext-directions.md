# Kontext direction-canonical visual audit

## Accepted candidate

- **N attempt 2** (`e4e68595_000.png`): readable direct rear view, face hidden, large rounded
  hanging ears, four grounded paws. Accepted for palette/envelope cleanup. Native normalized
  result is 30×31 at anchor `(20,36)`.

## Rejected attempts

- **N attempt 1** (`c7c4d8ca_000.png`): rear direction readable, but both ears are upright
  and pointy; fails Maltese identity.
- **NE attempt 1** (`6b04bfcb_000.png`): remains essentially a right-facing side profile;
  three-quarter rear geometry is absent.
- **SE attempt 1** (`5991e965_000.png`): seated, muzzle points left/opposite the requested
  lower-right direction, and black-eye/red-tongue colors contaminate the palette.
- **S attempt 1** (`091e03d3_000.png`): front direction is readable, but the dog is seated
  with large upright triangular/corgi-like ears; wrong breed and silhouette.

## Versioned retries

- NE attempt 2 uses accepted E plus cleaned accepted N as the two references.
- SE attempt 2 uses accepted E plus the normalized v2 SE reference-only guide.
- S attempt 2 uses accepted E plus the normalized v2 S reference-only guide.

No rejected direction output is eligible for final sheets or action generation.

## Accepted canonical set v1

- **N:** attempt 2. Strong rear view and floppy ears.
- **NE:** attempt 3. Best available source-like standing/right-facing view, but it reads more
  side-on than an ideal rear three-quarter view.
- **E:** accepted cleaned appearance canonical v1.
- **SE:** attempt 2. Usable standing front-right view with floppy ears.
- **S:** attempt 3. Excellent source identity, front direction and floppy ears, but it remains
  seated. This is an unavoidable static-base limitation and action edits must be checked for
  pose continuity.

All five were normalized to the requested directional envelopes, exact eight-color palette,
binary alpha, zero hidden RGB and anchor `(20,36)`. Review contact:
`previews/batch-review/kontext-canonicals-N-NE-E-SE-S-native.png`.

