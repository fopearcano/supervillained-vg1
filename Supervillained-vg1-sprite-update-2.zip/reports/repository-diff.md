# Repository changes left for review

Base: `8d066425cced354314ea6fb3ba612351f9296174` on `claude/gallant-pascal-wjy5l2`.

## Runtime and integration

- Replaced `public/sprites/zampano.png` and `public/sprites/zampano-tired.png`.
- Added the Cross/Knight main and tired sheets under `public/sprites/`.
- Added Cross/Knight manifest mappings and identical plain/Cross/Knight animation contracts.
- Refactored main/auxiliary sheet loading with per-animation fallback and a synchronous procedural-cast path.
- Added an explicit procedural tired pose and corrected exhausted-moving animation priority.
- Preserved ART NEW/OLD behavior and all five accepted supporting sheets.

## Tests, docs, and QA

- Updated `ASSETS.md`.
- Added `tests/manifest.test.ts`; expanded sprite/settings tests.
- Extended `scripts/screenshot.mjs` with Cross/Knight, ART toggle, and tired-state scenarios.
- Updated/generated QA screenshots under `docs/screens/`.

## Pre-existing untracked inputs preserved

- `pixel-art-characters/`
- `pixelart-characters-variations/`
- `sprites-out/` (expanded with the new reproducibility workspace)
- `starting-prompt.txt`

No source image was overwritten. No commit or push was made.
