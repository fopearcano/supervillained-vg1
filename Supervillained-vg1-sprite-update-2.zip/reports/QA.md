# SUPERVILLAINED sprite update 2 QA

Date: 2026-11-18 (Europe/Rome)

## Repository

- Branch: `claude/gallant-pascal-wjy5l2`
- Base HEAD: `8d066425cced354314ea6fb3ba612351f9296174`
- No commit or push was made.
- `git diff --check`: passed.

## Asset gates

- Plain maintenance inventory: 224/224 exact 40x40 frames.
- Main sheets: 160x3200; tired sheets: 80x320.
- Binary alpha, zero hidden RGB, strict eight-color plain palette, anchors, width bands, ground contact, mirrors, sheet/frame equality, unused transparent cells, and fetch-ball colors: passed.
- Cross alpha equals plain; both cross reds present: passed.
- Knight plain-alpha subset, tabard/cross clipping, steel-only helm extension, required colors, and lowered sniff/eat visor: passed.
- Runtime staging hashes match repository copies; five accepted supporting sheets are unchanged.
- Package gate: 735 files, secret/source exclusion and ZIP CRC/listing checks passed.

## Repository commands

- `npm install`: passed; npm reported five high-severity dependency-audit findings, not modified automatically.
- `npm run typecheck`: passed.
- `npm test`: 16 files / 107 tests passed.
- `npm run build`: passed.
- `npm run smoke`: all story sub-levels passed after fixing the procedural-cast synchronous loader path.
- `npm run playtest`: 42/42 sub-levels finished, KNIGHT ending, zero flagged levels and zero page errors.
- Targeted Playwright screenshots: sprite viewers, story Cross/Knight, ART NEW/OLD, gameplay scale/occlusion/actions, and exhausted stationary/walking/recovered states passed.

## Generation and retries

- Hosted Retro Diffusion spend: `$0.00`.
- Local Wan, SDXL/IP-Adapter/Canny, and FLUX Kontext attempts are recorded with prompts, seeds, hashes, task ids, results, and rejection reasons in metadata.
- Rejected attempts include identity/direction drift, static action pairs, missing fetch ball, and unusable S-facing Wan run/fetch motion.
- Final static actions are a new procedural local fallback derived only from the new model-generated canonicals; rejected Update 2 frames were never read or reused.
- Final dynamic motion uses selected local Wan frames, except S run/fetch, which use a validated new procedural bobbing fallback.

## Known visual limitations

- NE reads more like a side view than a true rear three-quarter view.
- The S static canonical is seated.
- S run/fetch is a readable bobbing cycle rather than a natural gallop.
- The intentionally oversized Knight helm is very blocky and may obscure more of the face than ideal outside sniff/eat.

