# SUPERVILLAINED VG1 sprite update

This package contains the final runtime sheets for Zampanò v2 and the five other source-styled
characters, plus optional unwired tired/icon assets and the files needed to maintain them.

## Quick install

From the game repository root:

1. Copy everything under `runtime/public/sprites/` into `public/sprites/`.
2. Apply `integration/manifest.patch`:

   ```powershell
   git apply integration/manifest.patch
   ```

   If this ZIP was extracted outside the repository, pass the extracted patch's full path.
3. Run:

   ```powershell
   npm test
   npm run build
   npm run dev
   ```

4. Check these local URLs:

   ```text
   ?debug=sprites&char=zampano
   ?debug=sprites&char=bagnaskiz
   ?debug=sprites&char=sbrimbrulon
   ?debug=sprites&char=jack
   ?debug=sprites&char=watson
   ?debug=sprites&char=confusione
   ```

The patch changes only `src/assets/manifest.ts`. The existing loader already slices the sheets in
manifest animation order and direction order `N, NE, E, SE, S, SW, W, NW`.

## Runtime files

| File | Dimensions | Purpose |
|---|---:|---|
| `zampano.png` | 160×3200 | Complete current Zampanò sheet: placeholder-equivalent non-run rows plus normalized v2 run rows |
| `bagnaskiz.png` | 160×1600 | idle/walk/run/bark/hurt |
| `sbrimbrulon.png` | 160×1600 | idle/walk/run/bark/hurt |
| `jack.png` | 160×1600 | idle/walk/run/bark/hurt |
| `watson.png` | 160×1600 | idle/walk/run/bark/hurt |
| `confusione.png` | 160×1600 | idle/walk/run/hiss/hurt |

The Zampanò file was built by clearing rows 16–23 (`y=640..959`) and copying v2 `run.png`
byte-for-byte. Transparent pixels do not reveal old placeholder run art. If the app later gains a
fully painted Zampanò sheet, merge only those eight run rows rather than replacing the whole file.

## Optional assets that are not wired yet

`runtime/optional-unwired/zampano-tired.png` is an 80×320 sheet containing 2 frames × 8 directions
at 4 fps. It cannot be assigned directly as a character `sheet`, because the current loader expects
one 160-pixel-wide sheet in manifest animation order. Wire it by either:

- appending eight four-column-padded tired rows to a 160×3520 Zampanò sheet and adding
  `tired: { frames: 2, fps: 4, loop: true }`; or
- adding a separate tired-sheet loader.

Play tired only while exhausted and stationary; exhausted movement should remain `walk`.

`runtime/optional-unwired/runIcon.png` is 13×11. The current RUN control draws `>>` with Pixi
`Graphics` in `src/ui/touchControls.ts`. To use the PNG, register a `SPRITES.runIcon`, make sure it
is included in the explicit global sprite build list, and replace the Graphics child with a texture
`Sprite`.

## Source-art decisions

The Desktop reference images define appearance where prose conflicts:

- Sbrimbrulon is the tricolour source dog, without a red topknot.
- Confusione is the orange tabby source cat rather than grey.

## Verification and maintenance

- `metadata/SHA256SUMS.txt` hashes every packaged file except itself.
- `metadata/app-assets.json` records runtime dimensions and status.
- `metadata/cast-validation.json` contains no frame/sheet validation errors.
- `maintenance/` contains final frames, palettes, reports, previews, and deterministic reproduction
  scripts. Raw model intermediates and rejected passes are intentionally excluded.

The package does not commit or push anything.

## Package QA performed

The included manifest patch was applied to branch
`claude/gallant-pascal-wjy5l2` at `d9ffce1f8addc4a4f760c3674608b5952d9e57de`, then:

- `npm test`: 12 test files, 92 tests passed.
- `npm run build`: TypeScript check and Vite production build passed.

The patch was then reversed and the repository was verified clean of tracked changes.
