"""Hash, validate, and zip the curated app-update payload."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image


REPO = Path(__file__).resolve().parents[2]
PACKAGE = REPO / "sprites-out" / "app-update-package" / "Supervillained-vg1-sprite-update"
ZIP_PATH = Path.home() / "Desktop" / "Supervillained-vg1-sprite-update.zip"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate() -> None:
    runtime = PACKAGE / "runtime" / "public" / "sprites"
    expected = {
        "zampano.png": (160, 3200),
        "bagnaskiz.png": (160, 1600),
        "sbrimbrulon.png": (160, 1600),
        "jack.png": (160, 1600),
        "watson.png": (160, 1600),
        "confusione.png": (160, 1600),
    }
    for name, size in expected.items():
        actual = Image.open(runtime / name).size
        if actual != size:
            raise ValueError(f"{name}: expected {size}, got {actual}")

    full = np.asarray(Image.open(runtime / "zampano.png").convert("RGBA"))
    run = np.asarray(Image.open(PACKAGE / "maintenance" / "zampano-v2" / "run.png").convert("RGBA"))
    if not np.array_equal(full[640:960], run):
        raise ValueError("zampano.png run rows are not an exact v2 replacement")

    optional = PACKAGE / "runtime" / "optional-unwired"
    if Image.open(optional / "zampano-tired.png").size != (80, 320):
        raise ValueError("wrong tired sheet size")
    if Image.open(optional / "runIcon.png").size != (13, 11):
        raise ValueError("wrong RUN icon size")

    cast_validation = json.loads(
        (PACKAGE / "metadata" / "cast-validation.json").read_text(encoding="utf-8")
    )
    if any(cast_validation.values()):
        raise ValueError(f"cast validation errors: {cast_validation}")


def main() -> None:
    validate()
    if ZIP_PATH.exists():
        raise FileExistsError(f"Refusing to overwrite {ZIP_PATH}")

    checksum_path = PACKAGE / "metadata" / "SHA256SUMS.txt"
    files = sorted(
        path
        for path in PACKAGE.rglob("*")
        if path.is_file() and path != checksum_path
    )
    checksum_path.write_text(
        "".join(f"{sha256(path)}  {path.relative_to(PACKAGE).as_posix()}\n" for path in files),
        encoding="utf-8",
    )

    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in PACKAGE.rglob("*") if p.is_file()):
            archive.write(path, Path(PACKAGE.name) / path.relative_to(PACKAGE))

    with zipfile.ZipFile(ZIP_PATH) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise ValueError(f"corrupt ZIP member: {bad}")
        member_count = len(archive.infolist())

    print(
        json.dumps(
            {
                "zip": str(ZIP_PATH),
                "size": ZIP_PATH.stat().st_size,
                "sha256": sha256(ZIP_PATH),
                "members": member_count,
                "runtime_assets": 8,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
