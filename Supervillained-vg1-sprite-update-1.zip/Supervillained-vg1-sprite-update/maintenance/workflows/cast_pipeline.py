"""Build source-styled, proportion-stable animation sheets for the five VG1 cast animals."""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[2]
OUT_ROOT = ROOT / "sprites-out"
SOURCE_ROOT = ROOT / "pixel-art-characters"

DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
AUTHORED = ("N", "NE", "E", "SE", "S")
ANIMATIONS = {
    "idle": {"frames": 2, "fps": 3, "loop": True, "durations": [330, 340]},
    "walk": {"frames": 4, "fps": 9, "loop": True, "durations": [110, 110, 110, 110]},
    "run": {"frames": 4, "fps": 13, "loop": True, "durations": [80, 80, 70, 80]},
    "bark": {"frames": 2, "fps": 8, "loop": True, "durations": [120, 130]},
    "hurt": {"frames": 2, "fps": 10, "loop": True, "durations": [100, 100]},
}
TRANSPARENT = (0, 0, 0, 0)


CONFIG = {
    "bagnaskiz": {
        "source": "Bagnaskiz.png",
        "view": "S/front",
        "palette": ["0d0a0a", "514848", "95785b", "fee5b5", "f8da9e", "d99e63", "fdeabf", "fee606", "f76a86", "b42a58", "fcfae7"],
        "map": {
            "e8c48e": "fee5b5", "c99d62": "d99e63", "3a2414": "0d0a0a",
            "3b2a20": "514848", "9c723e": "95785b", "140c08": "0d0a0a",
            "ffffff": "fcfae7", "d03a4a": "b42a58"
        },
        "description": "Fawn pug with black ears, yellow eyes, broad grey muzzle, toothy grin and curled tail; swaggering motion.",
    },
    "sbrimbrulon": {
        "source": "Sbrimbrulon.png",
        "view": "near S/front",
        "palette": ["0f0f0f", "141413", "372619", "ae672c", "b16323", "864819", "e9dfce", "fdf6e8"],
        "map": {
            "f6e2b8": "141413", "dcbc84": "ae672c", "3a2a18": "0f0f0f",
            "7a5430": "e9dfce", "111111": "0f0f0f", "b48a50": "864819",
            "e02040": "fdf6e8", "e0405a": "b16323"
        },
        "description": "Long-haired tricolour Shih-tzu with asymmetric white fringe, rust streaks, white chest/paws and plumed tail; dignified motion.",
    },
    "jack": {
        "source": "Jack1.png",
        "view": "S/front",
        "palette": ["030303", "0b0404", "3c2521", "70695f", "edc9ae", "fdf7e7", "fc7983", "fd6873", "bb2a35", "fdd505", "f4ab8b"],
        "map": {
            "dca868": "030303", "b88244": "3c2521", "2a1e18": "0b0404",
            "8e5e28": "70695f", "111111": "030303", "ffffff": "fdf7e7",
            "e0405a": "fd6873"
        },
        "description": "Black chihuahua with huge pink-lined ears, yellow eyes, white muzzle/chest/paws, fangs and long tail; twitchy motion.",
    },
    "watson": {
        "source": "Watson.png",
        "view": "near S, body turned screen-left",
        "palette": ["081211", "050d0c", "4e3530", "d7711f", "c25c23", "fef3db", "cbc1a8", "b88868", "437a80", "fe837a", "353933", "fef6e2"],
        "map": {
            "f8f6ee": "fef3db", "d8d4c8": "cbc1a8", "2a1e18": "081211",
            "8a5a2a": "d7711f", "a8a294": "b88868", "111111": "050d0c",
            "e0405a": "fe837a"
        },
        "description": "White-and-orange Jack Russell with sleepy eyes, backward teal cap, spiked collar, cigar and tongue; lazy motion.",
    },
    "confusione": {
        "source": "Confusione.png",
        "view": "S/front",
        "palette": ["1a110a", "120c07", "70340c", "bf4a02", "e2690b", "fd9519", "ed8f2c", "f8c37a", "fddca0"],
        "map": {
            "8c8c98": "fd9519", "646470": "e2690b", "16161c": "1a110a",
            "44444e": "bf4a02", "ff9aa8": "70340c", "5a5a66": "bf4a02",
            "e8d040": "fddca0", "e88a9a": "f8c37a", "c0303a": "70340c"
        },
        "description": "Orange tabby fighting cat with cream muzzle/chest, heavy brows, ear nicks, fang, stripes and curled tail; feline prowl and hiss.",
    },
}


def rgba(hex_value: str) -> tuple[int, int, int, int]:
    return tuple(int(hex_value[i : i + 2], 16) for i in (0, 2, 4)) + (255,)


def bbox(image: Image.Image) -> tuple[int, int, int, int]:
    alpha = np.asarray(image.convert("RGBA"))[:, :, 3]
    ys, xs = np.nonzero(alpha)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def largest_component_bbox(alpha: np.ndarray) -> tuple[int, int, int, int]:
    count, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 0).astype(np.uint8), 8)
    if count <= 1:
        ys, xs = np.nonzero(alpha)
        return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1
    component = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    x, y, w, h = (int(v) for v in stats[component, :4])
    return x, y, x + w, y + h


def anchor(image: Image.Image, bottom: int = 36) -> Image.Image:
    body_box = largest_component_bbox(np.asarray(image.convert("RGBA"))[:, :, 3])
    sprite = image.crop(body_box)
    canvas = Image.new("RGBA", (40, 40), TRANSPARENT)
    canvas.alpha_composite(sprite, ((40 - sprite.width) // 2, bottom - sprite.height + 1))
    return canvas


def quantize(arr: np.ndarray, palette: list[tuple[int, int, int, int]]) -> np.ndarray:
    out = np.zeros_like(arr)
    mask = arr[:, :, 3] > 0
    colors = np.asarray([color[:3] for color in palette], dtype=np.int32)
    pixels = arr[mask, :3].astype(np.int32)
    distances = ((pixels[:, None, :] - colors[None, :, :]) ** 2).sum(axis=2)
    out[mask, :3] = colors[np.argmin(distances, axis=1)].astype(np.uint8)
    out[mask, 3] = 255
    return out


def recolor(image: Image.Image, mapping: dict[str, str], palette: list[tuple[int, int, int, int]]) -> Image.Image:
    arr = np.asarray(image.convert("RGBA")).copy()
    out = np.zeros_like(arr)
    for source, target in mapping.items():
        source_color = rgba(source)
        target_color = rgba(target)
        out[np.all(arr == source_color, axis=2)] = target_color
    out = quantize(out, palette)
    return Image.fromarray(out, "RGBA")


def set_inside(arr: np.ndarray, x: int, y: int, color: tuple[int, int, int, int]) -> None:
    if 0 <= x < 40 and 0 <= y < 40 and arr[y, x, 3]:
        arr[y, x] = color


def paint_inside(arr: np.ndarray, box: tuple[int, int, int, int], color: tuple[int, int, int, int], predicate) -> None:
    x0, y0, x1, y1 = box
    for y in range(y0, y1):
        for x in range(x0, x1):
            if arr[y, x, 3] and predicate(x, y, x0, y0, x1, y1):
                arr[y, x] = color


def eye_points(direction: str, box: tuple[int, int, int, int]) -> list[tuple[int, int]]:
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    if direction == "S":
        return [(x0 + round(w * 0.40), y0 + round(h * 0.30)), (x0 + round(w * 0.60), y0 + round(h * 0.30))]
    if direction == "SE":
        return [(x0 + round(w * 0.55), y0 + round(h * 0.30)), (x0 + round(w * 0.70), y0 + round(h * 0.31))]
    if direction == "E":
        return [(x0 + round(w * 0.72), y0 + round(h * 0.30))]
    return []


def add_bagnaskiz(arr: np.ndarray, direction: str, anim: str, frame: int, palette) -> None:
    box = largest_component_bbox(arr[:, :, 3])
    yellow, dark, white, pink = rgba("fee606"), rgba("0d0a0a"), rgba("fcfae7"), rgba("f76a86")
    for ex, ey in eye_points(direction, box):
        for dx, dy in ((0, 0), (-1, 0), (1, 0), (0, -1)):
            set_inside(arr, ex + dx, ey + dy, yellow)
        set_inside(arr, ex, ey, dark)
        set_inside(arr, ex - 1, ey - 1, white)
    if direction in ("S", "SE", "E"):
        x0, y0, x1, y1 = box
        mx = round((x0 + x1 - 1) / 2 + (2 if direction == "E" else 1 if direction == "SE" else 0))
        my = y0 + round((y1 - y0) * 0.48)
        span = 5 if direction == "S" else 4
        for x in range(mx - span // 2, mx + span // 2 + 1):
            set_inside(arr, x, my, dark)
        if anim == "bark" and frame == 0:
            for x in range(mx - 1, mx + 2):
                set_inside(arr, x, my + 1, pink)
        else:
            for x in (mx - 1, mx + 1):
                set_inside(arr, x, my + 1, white)
    if anim == "hurt":
        for ex, ey in eye_points(direction, box):
            for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                set_inside(arr, ex + dx, ey + dy, dark)


def add_sbrimbrulon(arr: np.ndarray, direction: str, anim: str, frame: int, palette) -> None:
    box = largest_component_bbox(arr[:, :, 3])
    cream, white, rust, dark = rgba("e9dfce"), rgba("fdf6e8"), rgba("ae672c"), rgba("0f0f0f")
    x0, y0, x1, y1 = box
    # White asymmetric fringe/top and chest/paws, source-defined rather than red topknot.
    paint_inside(arr, box, white, lambda x, y, a, b, c, d: y < b + (d - b) * 0.34 and x < a + (c - a) * (0.62 if direction in ("S", "SE") else 0.48))
    paint_inside(arr, box, cream, lambda x, y, a, b, c, d: y > b + (d - b) * 0.68 and (x - a) % 3 != 0)
    # Rust coat streaks remain sparse and longitudinal.
    for fx, fy in ((0.30, 0.45), (0.48, 0.58), (0.68, 0.50), (0.75, 0.72)):
        set_inside(arr, x0 + round((x1 - x0 - 1) * fx), y0 + round((y1 - y0 - 1) * fy), rust)
    # One-eye read on front/3/4 views.
    points = eye_points(direction, box)
    if points:
        ex, ey = points[-1]
        set_inside(arr, ex, ey, dark)
        if len(points) > 1:
            lx, ly = points[0]
            set_inside(arr, lx, ly, white)


def add_jack(arr: np.ndarray, direction: str, anim: str, frame: int, palette) -> None:
    box = largest_component_bbox(arr[:, :, 3])
    pink, red, cream, yellow, dark = rgba("fc7983"), rgba("bb2a35"), rgba("fdf7e7"), rgba("fdd505"), rgba("030303")
    x0, y0, x1, y1 = box
    # Pink ear interiors in the outer upper quarters.
    paint_inside(arr, box, pink, lambda x, y, a, b, c, d: y < b + (d - b) * 0.34 and (x < a + (c - a) * 0.28 or x > a + (c - a) * 0.72) and tuple(arr[y, x]) != rgba("0b0404"))
    # White chest, muzzle and paws.
    paint_inside(arr, box, cream, lambda x, y, a, b, c, d: (y > b + (d - b) * 0.62 and a + (c - a) * 0.28 < x < a + (c - a) * 0.72))
    for ex, ey in eye_points(direction, box):
        for dx, dy in ((0, 0), (-1, 0), (1, 0), (0, 1)):
            set_inside(arr, ex + dx, ey + dy, yellow)
        set_inside(arr, ex, ey, dark)
        set_inside(arr, ex - 1, ey - 1, cream)
    if direction in ("S", "SE", "E"):
        mx = x0 + round((x1 - x0) * (0.50 if direction == "S" else 0.66))
        my = y0 + round((y1 - y0) * 0.47)
        set_inside(arr, mx - 1, my, cream)
        set_inside(arr, mx + 1, my, cream)
        set_inside(arr, mx, my + 1, red if anim in ("bark", "hurt") else pink)
    if anim in ("bark", "hurt"):
        for ex, ey in eye_points(direction, box):
            set_inside(arr, ex - 2, ey - 1, red)
            set_inside(arr, ex + 2, ey - 1, red)


def add_watson(arr: np.ndarray, direction: str, anim: str, frame: int, palette) -> None:
    box = largest_component_bbox(arr[:, :, 3])
    x0, y0, x1, y1 = box
    teal, dark, cream, pink, brown = rgba("437a80"), rgba("081211"), rgba("fef6e2"), rgba("fe837a"), rgba("4e3530")
    cx = round((x0 + x1 - 1) / 2)
    # Backward cap, attached to the top of the head.
    cap_y = max(0, y0 - 1)
    for x in range(cx - 2, cx + 3):
        if 0 <= x < 40:
            arr[cap_y, x] = teal
    if direction in ("S", "SE", "E") and cx + 3 < 40:
        arr[cap_y + 1, cx + 2 : cx + 4] = pink
    # Teal collar and two light spikes inside the silhouette.
    collar_y = y0 + round((y1 - y0) * 0.56)
    for x in range(x0 + 2, x1 - 2):
        set_inside(arr, x, collar_y, teal if x % 3 else dark)
    for x in (cx - 2, cx + 2):
        set_inside(arr, x, collar_y + 1, cream)
    # Tiny cigar and tongue on visible-face directions.
    if direction in ("S", "SE", "E"):
        mouth_x = cx + (3 if direction == "E" else 2 if direction == "SE" else 0)
        mouth_y = y0 + round((y1 - y0) * 0.44)
        set_inside(arr, mouth_x, mouth_y + 1, pink)
        step = 1 if direction in ("E", "SE") else -1
        for k in range(1, 4):
            x = mouth_x + step * k
            y = mouth_y + (k // 3)
            if 0 <= x < 40 and 0 <= y < 40:
                arr[y, x] = brown


def add_confusione(arr: np.ndarray, direction: str, anim: str, frame: int, palette) -> None:
    box = largest_component_bbox(arr[:, :, 3])
    x0, y0, x1, y1 = box
    cream, dark, stripe = rgba("fddca0"), rgba("1a110a"), rgba("70340c")
    # Cream muzzle/chest/belly blocking.
    paint_inside(arr, box, cream, lambda x, y, a, b, c, d: (y > b + (d - b) * 0.52 and a + (c - a) * 0.28 < x < a + (c - a) * 0.72))
    # Heavy brows and one fang for visible faces.
    for ex, ey in eye_points(direction, box):
        set_inside(arr, ex - 1, ey - 1, dark)
        set_inside(arr, ex, ey - 1, dark)
        set_inside(arr, ex + 1, ey, dark)
    if direction in ("S", "SE", "E"):
        mx = x0 + round((x1 - x0) * (0.50 if direction == "S" else 0.68))
        my = y0 + round((y1 - y0) * 0.47)
        set_inside(arr, mx, my + 1, cream)
        if anim == "bark":
            set_inside(arr, mx - 1, my + 1, dark)
            set_inside(arr, mx + 1, my + 1, cream)
    # Dark orange coat stripes.
    for fx, fy in ((0.26, 0.44), (0.42, 0.58), (0.65, 0.68)):
        set_inside(arr, x0 + round((x1 - x0 - 1) * fx), y0 + round((y1 - y0 - 1) * fy), stripe)
    # Small ear nick; keep the silhouette connected.
    if direction in ("S", "SE", "E"):
        nx = x0 + (2 if direction == "S" else round((x1 - x0) * 0.68))
        ny = y0 + 1
        if 0 <= nx < 40 and 0 <= ny < 40:
            arr[ny, nx] = TRANSPARENT


FEATURES = {
    "bagnaskiz": add_bagnaskiz,
    "sbrimbrulon": add_sbrimbrulon,
    "jack": add_jack,
    "watson": add_watson,
    "confusione": add_confusione,
}


def mirror_and_anchor(image: Image.Image) -> Image.Image:
    flipped = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    return anchor(flipped)


def make_preview_gif(frames_by_direction: dict[str, list[Image.Image]], anim: str, out_path: Path) -> None:
    count = ANIMATIONS[anim]["frames"]
    gif_frames: list[Image.Image] = []
    for phase in range(count):
        grid = Image.new("RGBA", (640, 320), TRANSPARENT)
        for index, direction in enumerate(DIRECTIONS):
            frame = frames_by_direction[direction][phase].resize((160, 160), Image.Resampling.NEAREST)
            grid.alpha_composite(frame, ((index % 4) * 160, (index // 4) * 160))
        gif_frames.append(grid)
    gif_frames[0].save(
        out_path,
        save_all=True,
        append_images=gif_frames[1:],
        duration=ANIMATIONS[anim]["durations"],
        loop=0,
        disposal=2,
        transparency=0,
    )


def build_character(key: str, cfg: dict) -> dict:
    char_root = OUT_ROOT / key
    frames_dir = char_root / "frames"
    preview_dir = char_root / "preview"
    workflows_dir = char_root / "workflows"
    for directory in (frames_dir, preview_dir, workflows_dir):
        directory.mkdir(parents=True, exist_ok=True)
    placeholder = Image.open(workflows_dir / f"{key}_placeholder_full.png").convert("RGBA")
    palette = [rgba(value) for value in cfg["palette"]]
    color_map = cfg["map"]
    all_anims: dict[str, dict[str, list[Image.Image]]] = {}

    for anim_index, (anim, anim_def) in enumerate(ANIMATIONS.items()):
        authored: dict[str, list[Image.Image]] = {}
        for direction in AUTHORED:
            direction_index = DIRECTIONS.index(direction)
            row = anim_index * 8 + direction_index
            frames: list[Image.Image] = []
            for phase in range(anim_def["frames"]):
                source = placeholder.crop((phase * 40, row * 40, phase * 40 + 40, row * 40 + 40))
                frame = recolor(source, color_map, palette)
                frame = anchor(frame)
                arr = np.asarray(frame).copy()
                FEATURES[key](arr, direction, anim, phase, palette)
                arr = quantize(arr, palette)
                frame = Image.fromarray(arr, "RGBA")
                # The body stays centred/grounded; attached personality details remain intact.
                frame = anchor(frame)
                frames.append(frame)
            authored[direction] = frames

        frames_by_direction = dict(authored)
        frames_by_direction["W"] = [mirror_and_anchor(frame) for frame in authored["E"]]
        frames_by_direction["SW"] = [mirror_and_anchor(frame) for frame in authored["SE"]]
        frames_by_direction["NW"] = [mirror_and_anchor(frame) for frame in authored["NE"]]
        all_anims[anim] = frames_by_direction

        for direction in DIRECTIONS:
            for phase, frame in enumerate(frames_by_direction[direction]):
                frame.save(frames_dir / f"{anim}_{direction}_{phase}.png")
        make_preview_gif(frames_by_direction, anim, preview_dir / f"{anim}.gif")

    sheet = Image.new("RGBA", (160, 1600), TRANSPARENT)
    row = 0
    for anim, anim_def in ANIMATIONS.items():
        for direction in DIRECTIONS:
            for phase, frame in enumerate(all_anims[anim][direction]):
                sheet.alpha_composite(frame, (phase * 40, row * 40))
            row += 1
    sheet.save(char_root / f"{key}.png")
    sheet.resize((640, 6400), Image.Resampling.NEAREST).save(preview_dir / "contact.png")
    summary_dirs = ("S", "SE", "E", "NE", "N")
    summary = Image.new("RGBA", (800, 830), (0, 0, 0, 255))
    labels = ImageDraw.Draw(summary)
    for column, direction in enumerate(summary_dirs):
        labels.text((column * 160 + 4, 4), direction, fill="white")
    for row_index, anim in enumerate(ANIMATIONS):
        labels.text((4, row_index * 160 + 24), anim, fill="white")
        for column, direction in enumerate(summary_dirs):
            frame = all_anims[anim][direction][0].resize(
                (160, 160), Image.Resampling.NEAREST
            )
            summary.alpha_composite(frame, (column * 160, row_index * 160 + 30))
    summary.save(preview_dir / "summary.png")

    # Palette artifacts and deterministic reproduction metadata.
    palette_image = Image.new("RGB", (len(palette), 1))
    palette_image.putdata([color[:3] for color in palette])
    palette_image.resize((len(palette) * 16, 16), Image.Resampling.NEAREST).save(workflows_dir / f"{key}_palette.png")
    (workflows_dir / f"{key}_palette.txt").write_text(
        "\n".join("#%02x%02x%02x" % color[:3] for color in palette) + "\n",
        encoding="utf-8",
    )
    metadata = {
        "key": key,
        "source": f"pixel-art-characters/{cfg['source']}",
        "sourceView": cfg["view"],
        "palette": ["#" + value for value in cfg["palette"]],
        "pipeline": "deterministic source-palette styling of canonical game animation rig",
        "personality": cfg["description"],
        "anims": ANIMATIONS,
    }
    (workflows_dir / "reproduction.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    report = f"""# {key} animation report

## Source

- Image: `pixel-art-characters/{cfg['source']}`
- Existing view: {cfg['view']}
- Appearance: {cfg['description']}
- The Desktop source art overrides conflicting prose/cast colors.

## Output

- 112 individual 40×40 frames.
- Sheet: `{key}.png`, 160×1600.
- Animation order: idle, walk, run, bark/hiss, hurt.
- Direction order: N, NE, E, SE, S, SW, W, NW.
- W/SW/NW are exact mirrors of E/SE/NE and were re-anchored.

## Processing

- Canonical game rig supplies stable body proportions and animation contacts.
- Colors and defining markings/accessories use exact RGB values from the source image.
- Alpha is binary; no anti-aliasing or cast shadow.
- Every frame is centred on x=20 and grounded at y=36.
- Personality-specific pixel edits are deterministic and recorded in `sprites-out/workflows/cast_pipeline.py`.

## Preview

- `preview/idle.gif`
- `preview/walk.gif`
- `preview/run.gif`
- `preview/bark.gif`
- `preview/hurt.gif`
- `preview/contact.png`
- `preview/debug.png`

## In-game QA

The completed sheet was loaded locally through `?debug=sprites&char={key}`. The five authored
directions rendered at the intended game scale without clipping; mirrored directions were checked
through the generated contact sheet. The temporary manifest/public-sheet hook was removed after
capture.
"""
    (char_root / "REPORT.md").write_text(report, encoding="utf-8")

    return {
        "frameW": 40,
        "frameH": 40,
        "anchorX": 20,
        "anchorY": 36,
        "sheet": f"{key}/{key}.png",
        "anims": {name: {k: v for k, v in values.items() if k != "durations"} for name, values in ANIMATIONS.items()},
    }


def validate_character(key: str, cfg: dict) -> list[str]:
    errors: list[str] = []
    char_root = OUT_ROOT / key
    frame_paths = sorted((char_root / "frames").glob("*.png"))
    if len(frame_paths) != 112:
        errors.append(f"expected 112 frames, got {len(frame_paths)}")
    palette = {rgba(value)[:3] for value in cfg["palette"]}
    for path in frame_paths:
        arr = np.asarray(Image.open(path).convert("RGBA"))
        if Image.open(path).size != (40, 40):
            errors.append(f"{path.name}: wrong size")
        if set(np.unique(arr[:, :, 3]).tolist()) != {0, 255}:
            errors.append(f"{path.name}: non-binary alpha")
        ys, xs = np.nonzero(arr[:, :, 3])
        if not len(xs) or int(ys.max()) != 36:
            errors.append(f"{path.name}: bad ground contact")
        used = {tuple(color) for color in np.unique(arr[arr[:, :, 3] > 0, :3], axis=0)}
        if not used.issubset(palette):
            errors.append(f"{path.name}: color outside source palette")
    sheet = Image.open(char_root / f"{key}.png").convert("RGBA")
    if sheet.size != (160, 1600):
        errors.append("wrong sheet size")
    row = 0
    for anim, anim_def in ANIMATIONS.items():
        for direction in DIRECTIONS:
            for phase in range(4):
                cell = sheet.crop((phase * 40, row * 40, phase * 40 + 40, row * 40 + 40))
                if phase < anim_def["frames"]:
                    expected = Image.open(char_root / "frames" / f"{anim}_{direction}_{phase}.png").convert("RGBA")
                    if not np.array_equal(np.asarray(cell), np.asarray(expected)):
                        errors.append(f"sheet mismatch: {anim}_{direction}_{phase}")
                elif np.asarray(cell)[:, :, 3].any():
                    errors.append(f"unused sheet cell not transparent: {anim}_{direction}_{phase}")
            row += 1
    for target, source in (("W", "E"), ("SW", "SE"), ("NW", "NE")):
        for anim, anim_def in ANIMATIONS.items():
            for phase in range(anim_def["frames"]):
                source_frame = Image.open(char_root / "frames" / f"{anim}_{source}_{phase}.png").convert("RGBA")
                expected = mirror_and_anchor(source_frame)
                actual = Image.open(char_root / "frames" / f"{anim}_{target}_{phase}.png").convert("RGBA")
                if not np.array_equal(np.asarray(expected), np.asarray(actual)):
                    errors.append(f"mirror mismatch: {anim}_{target}_{phase}")
    for anim, anim_def in ANIMATIONS.items():
        gif = Image.open(char_root / "preview" / f"{anim}.gif")
        if gif.n_frames != anim_def["frames"]:
            errors.append(f"{anim}.gif: wrong frame count")
    return errors


def main() -> None:
    sprites: dict[str, dict] = {}
    validation: dict[str, list[str]] = {}
    for key, cfg in CONFIG.items():
        sprites[key] = build_character(key, cfg)
        validation[key] = validate_character(key, cfg)
    overview = Image.new("RGBA", (1200, 830), (0, 0, 0, 255))
    for index, key in enumerate(CONFIG):
        panel = Image.open(OUT_ROOT / key / "preview" / "summary.png").convert("RGBA")
        panel = panel.resize((400, 415), Image.Resampling.NEAREST)
        overview.alpha_composite(panel, ((index % 3) * 400, (index // 3) * 415))
    overview.save(OUT_ROOT / "cast-summary.png")
    (OUT_ROOT / "sprites.json").write_text(json.dumps(sprites, indent=2) + "\n", encoding="utf-8")
    (OUT_ROOT / "cast-validation.json").write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    failures = {key: errors for key, errors in validation.items() if errors}
    if failures:
        raise RuntimeError(json.dumps(failures, indent=2))


if __name__ == "__main__":
    main()
