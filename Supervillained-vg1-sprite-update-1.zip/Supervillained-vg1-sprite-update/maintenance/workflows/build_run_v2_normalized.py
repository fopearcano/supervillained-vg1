"""Create v2 by discrete pixel-seam normalization of the approved v1 art.

No interpolation or non-integer resampling is used. Whole interior rows and
columns are inserted/deleted, E is frozen as canonical, S receives one shared
head/ear silhouette, and mirrors are rebuilt from corrected authored views.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[3]
WORKFLOWS = Path(__file__).resolve().parent
V1 = ROOT / "sprites-out" / "zampano" / "frames"
OUT = ROOT / "sprites-out" / "zampano" / "v2"
FRAMES = OUT / "frames"
PREVIEW = OUT / "preview"

DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
TARGET_BOTTOMS = (36, 36, 34, 36)
TRANSPARENT = (0, 0, 0, 0)
DEEP = np.array((61, 92, 93, 255), dtype=np.uint8)
OUTLINE = np.array((3, 40, 43, 255), dtype=np.uint8)
PALE = {
    (254, 249, 235, 255),
    (204, 216, 210, 255),
    (172, 196, 195, 255),
}

TARGETS = {
    "N": ((30, 31), (31, 32), (32, 30), (31, 31)),
    "NE": ((32, 29), (34, 31), (35, 29), (33, 29)),
    "SE": ((32, 29), (34, 31), (35, 29), (33, 29)),
    "S": ((30, 31), (31, 32), (32, 30), (31, 31)),
}

SEAMS = {
    "N": (0.50, 0.60),
    "NE": (0.46, 0.60),
    "SE": (0.44, 0.68),
    "S": (0.50, 0.70),
}


def bbox(image: Image.Image) -> tuple[int, int, int, int]:
    alpha = np.asarray(image.convert("RGBA"))[:, :, 3]
    ys, xs = np.nonzero(alpha)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def crop_sprite(image: Image.Image) -> Image.Image:
    return image.convert("RGBA").crop(bbox(image))


def insert_column(arr: np.ndarray, index: int) -> np.ndarray:
    source = max(0, min(arr.shape[1] - 1, index))
    return np.concatenate((arr[:, : index + 1], arr[:, source : source + 1], arr[:, index + 1 :]), axis=1)


def delete_column(arr: np.ndarray, index: int) -> np.ndarray:
    index = max(1, min(arr.shape[1] - 2, index))
    return np.concatenate((arr[:, :index], arr[:, index + 1 :]), axis=1)


def insert_row(arr: np.ndarray, index: int) -> np.ndarray:
    source = max(0, min(arr.shape[0] - 1, index))
    return np.concatenate((arr[: index + 1], arr[source : source + 1], arr[index + 1 :]), axis=0)


def delete_row(arr: np.ndarray, index: int) -> np.ndarray:
    index = max(1, min(arr.shape[0] - 2, index))
    return np.concatenate((arr[:index], arr[index + 1 :]), axis=0)


def seam_resize(image: Image.Image, target_w: int, target_h: int, seam_x: float, seam_y: float) -> Image.Image:
    arr = np.asarray(image.convert("RGBA")).copy()
    if arr.shape[1] < target_w:
        count = target_w - arr.shape[1]
        positions = np.linspace(2, max(2, arr.shape[1] - 3), count + 2)[1:-1]
        for offset, position in enumerate(np.rint(positions).astype(int)):
            arr = insert_column(arr, int(position) + offset)
    elif arr.shape[1] > target_w:
        count = arr.shape[1] - target_w
        positions = np.linspace(2, max(2, arr.shape[1] - 3), count + 2)[1:-1]
        for position in sorted(np.rint(positions).astype(int), reverse=True):
            arr = delete_column(arr, int(position))
    if arr.shape[0] < target_h:
        count = target_h - arr.shape[0]
        positions = np.linspace(2, max(2, arr.shape[0] - 4), count + 2)[1:-1]
        for offset, position in enumerate(np.rint(positions).astype(int)):
            arr = insert_row(arr, int(position) + offset)
    elif arr.shape[0] > target_h:
        count = arr.shape[0] - target_h
        positions = np.linspace(2, max(2, arr.shape[0] - 4), count + 2)[1:-1]
        for position in sorted(np.rint(positions).astype(int), reverse=True):
            arr = delete_row(arr, int(position))
    return Image.fromarray(arr, "RGBA")


def resize_se_body(image: Image.Image, target_w: int, target_h: int) -> Image.Image:
    """Expand SE's torso/legs while preserving the smaller canonical head."""
    arr = np.asarray(image.convert("RGBA")).copy()
    if arr.shape[1] < target_w:
        delta = target_w - arr.shape[1]
        split = max(2, min(arr.shape[1] - 2, round(arr.shape[1] * 0.56)))
        canvas = np.zeros((arr.shape[0], target_w, 4), dtype=np.uint8)
        canvas[:, :split] = arr[:, :split]
        canvas[:, split + delta :] = arr[:, split:]
        # Bridge only rows where body pixels approach the seam from both sides.
        for y in range(canvas.shape[0]):
            left_pixels = np.flatnonzero(canvas[y, :split, 3])
            right_pixels = np.flatnonzero(canvas[y, split + delta :, 3])
            if not len(left_pixels) or not len(right_pixels):
                continue
            lx = int(left_pixels.max())
            rx = int(right_pixels.min()) + split + delta
            if split - lx <= 3 and rx - (split + delta - 1) <= 3:
                source = canvas[y, lx] if tuple(canvas[y, lx]) != tuple(OUTLINE) else canvas[y, rx]
                canvas[y, lx + 1 : rx] = source
        arr = canvas
    elif arr.shape[1] > target_w:
        count = arr.shape[1] - target_w
        body_end = max(4, round(arr.shape[1] * 0.56))
        positions = np.linspace(2, body_end - 1, count + 2)[1:-1]
        for position in sorted(np.rint(positions).astype(int), reverse=True):
            arr = delete_column(arr, int(position))
    if arr.shape[0] < target_h:
        delta = target_h - arr.shape[0]
        split = max(2, min(arr.shape[0] - 3, round(arr.shape[0] * 0.56)))
        canvas = np.zeros((target_h, arr.shape[1], 4), dtype=np.uint8)
        canvas[:split] = arr[:split]
        canvas[split + delta :] = arr[split:]
        for x in range(canvas.shape[1]):
            top_pixels = np.flatnonzero(canvas[:split, x, 3])
            bottom_pixels = np.flatnonzero(canvas[split + delta :, x, 3])
            if not len(top_pixels) or not len(bottom_pixels):
                continue
            ty = int(top_pixels.max())
            by = int(bottom_pixels.min()) + split + delta
            if split - ty <= 3 and by - (split + delta - 1) <= 3:
                source = canvas[ty, x] if tuple(canvas[ty, x]) != tuple(OUTLINE) else canvas[by, x]
                canvas[ty + 1 : by, x] = source
        arr = canvas
    elif arr.shape[0] > target_h:
        count = arr.shape[0] - target_h
        y0 = max(2, round(arr.shape[0] * 0.45))
        y1 = max(y0, round(arr.shape[0] * 0.84))
        positions = np.linspace(y0, y1, count + 2)[1:-1]
        for position in sorted(np.rint(positions).astype(int), reverse=True):
            arr = delete_row(arr, int(position))
    return Image.fromarray(arr, "RGBA")


def resize_ne_body(image: Image.Image, target_w: int, target_h: int) -> Image.Image:
    """Lengthen the diagonal body by separating rear and head, not scaling either."""
    arr = np.asarray(image.convert("RGBA")).copy()
    if arr.shape[1] < target_w:
        delta = target_w - arr.shape[1]
        split = max(2, min(arr.shape[1] - 2, round(arr.shape[1] * 0.53)))
        canvas = np.zeros((arr.shape[0], target_w, 4), dtype=np.uint8)
        canvas[:, :split] = arr[:, :split]
        canvas[:, split + delta :] = arr[:, split:]
        left, right = arr[:, split - 1], arr[:, split]
        bridge = (left[:, 3] > 0) & (right[:, 3] > 0)
        for x in range(split, split + delta):
            source = left if x - split < delta / 2 else right
            canvas[bridge, x] = source[bridge]
        arr = canvas
    while arr.shape[0] > target_h:
        candidates = range(2, max(3, arr.shape[0] - 4))
        # Remove the least dense interior seam; paws and the top hair remain intact.
        y = min(candidates, key=lambda row: int((arr[row, :, 3] > 0).sum()))
        arr = delete_row(arr, y)
    while arr.shape[0] < target_h:
        candidates = range(2, max(3, arr.shape[0] - 4))
        y = min(candidates, key=lambda row: int((arr[row, :, 3] > 0).sum()))
        arr = insert_row(arr, y)
    return Image.fromarray(arr, "RGBA")


def anchor(image: Image.Image, bottom: int) -> Image.Image:
    sprite = crop_sprite(image)
    canvas = Image.new("RGBA", (40, 40), TRANSPARENT)
    canvas.alpha_composite(sprite, ((40 - sprite.width) // 2, bottom - sprite.height + 1))
    return canvas


def separate_back_head(image: Image.Image) -> Image.Image:
    arr = np.asarray(image.convert("RGBA")).copy()
    h, w = arr.shape[:2]
    y = max(2, min(h - 3, round(h * 0.44)))
    for fraction in (0.34, 0.44, 0.56, 0.66):
        x = round((w - 1) * fraction)
        if arr[y, x, 3] and tuple(arr[y, x]) != tuple(OUTLINE):
            arr[y, x] = DEEP
            if y + 1 < h and arr[y + 1, x, 3] and x % 2 == 0:
                arr[y + 1, x] = DEEP
    return Image.fromarray(arr, "RGBA")


def canonical_s_heads(frames: list[Image.Image]) -> list[Image.Image]:
    # Frame 3 is the most source-like S head. Normalize it once and paste the
    # same rounded/floppy silhouette across all four phases.
    canonical = np.asarray(frames[3].convert("RGBA")).copy()
    head_h = min(16, canonical.shape[0] - 8)
    head = canonical[:head_h].copy()
    # Trim the outer bat-ear tips while keeping lower hanging locks.
    for y in range(min(9, head_h)):
        trim = 3 if y < 5 else 2
        head[y, :trim] = 0
        head[y, -trim:] = 0

    output: list[Image.Image] = []
    for frame in frames:
        arr = np.asarray(frame.convert("RGBA")).copy()
        arr[:head_h] = 0
        offset = (arr.shape[1] - head.shape[1]) // 2
        src_x0 = max(0, -offset)
        dst_x0 = max(0, offset)
        width = min(head.shape[1] - src_x0, arr.shape[1] - dst_x0)
        mask = head[:, src_x0 : src_x0 + width, 3] > 0
        target = arr[:head_h, dst_x0 : dst_x0 + width]
        source = head[:, src_x0 : src_x0 + width]
        target[mask] = source[mask]
        output.append(Image.fromarray(arr, "RGBA"))
    return output


def add_fur_texture(image: Image.Image, direction: str) -> Image.Image:
    arr = np.asarray(image.convert("RGBA")).copy()
    h, w = arr.shape[:2]
    marks = (
        (0.28, 0.25, 1),
        (0.48, 0.20, 2),
        (0.68, 0.32, 1),
        (0.30, 0.52, 2),
        (0.50, 0.57, 1),
        (0.68, 0.64, 2),
        (0.42, 0.76, 1),
    )
    direction_offset = {"N": 0, "NE": 1, "SE": 2, "S": 3}.get(direction, 0)
    for index, (fx, fy, length) in enumerate(marks):
        x = max(1, min(w - 2, round((w - 1) * fx) + ((index + direction_offset) % 3) - 1))
        y = max(1, min(h - 2, round((h - 1) * fy)))
        for dy in range(length):
            yy = min(h - 2, y + dy)
            if tuple(arr[yy, x]) in PALE:
                arr[yy, x] = DEEP if index % 3 == 0 else np.array((172, 196, 195, 255), dtype=np.uint8)
    return Image.fromarray(arr, "RGBA")


def main() -> None:
    FRAMES.mkdir(parents=True, exist_ok=True)
    PREVIEW.mkdir(parents=True, exist_ok=True)
    authored: dict[str, list[Image.Image]] = {"E": []}

    # E is the accepted canonical anatomy and is copied without geometry edits.
    for phase, bottom in enumerate(TARGET_BOTTOMS):
        frame = anchor(Image.open(V1 / f"run_E_{phase}.png"), bottom)
        authored["E"].append(frame)

    for direction in ("N", "NE", "SE", "S"):
        seam_x, seam_y = SEAMS[direction]
        normalized: list[Image.Image] = []
        for phase, ((target_w, target_h), bottom) in enumerate(
            zip(TARGETS[direction], TARGET_BOTTOMS)
        ):
            source = crop_sprite(Image.open(V1 / f"run_{direction}_{phase}.png"))
            frame = seam_resize(source, target_w, target_h, seam_x, seam_y)
            if direction in ("N", "NE"):
                frame = separate_back_head(frame)
            normalized.append(frame)
        if direction == "S":
            normalized = canonical_s_heads(normalized)
        authored[direction] = [
            anchor(add_fur_texture(frame, direction), bottom)
            for frame, bottom in zip(normalized, TARGET_BOTTOMS)
        ]

    all_frames = dict(authored)
    all_frames["W"] = [
        anchor(frame.transpose(Image.Transpose.FLIP_LEFT_RIGHT), bottom)
        for frame, bottom in zip(authored["E"], TARGET_BOTTOMS)
    ]
    all_frames["SW"] = [
        anchor(frame.transpose(Image.Transpose.FLIP_LEFT_RIGHT), bottom)
        for frame, bottom in zip(authored["SE"], TARGET_BOTTOMS)
    ]
    all_frames["NW"] = [
        anchor(frame.transpose(Image.Transpose.FLIP_LEFT_RIGHT), bottom)
        for frame, bottom in zip(authored["NE"], TARGET_BOTTOMS)
    ]

    sheet = Image.new("RGBA", (160, 320), TRANSPARENT)
    for row, direction in enumerate(DIRECTIONS):
        for phase, frame in enumerate(all_frames[direction]):
            frame.save(FRAMES / f"run_{direction}_{phase}.png")
            sheet.alpha_composite(frame, (phase * 40, row * 40))
    sheet.save(OUT / "run.png")
    sheet.resize((640, 1280), Image.Resampling.NEAREST).save(PREVIEW / "run-contact.png")

    placeholder = Image.open(WORKFLOWS / "zampano_placeholder_full.png").convert("RGBA")
    # Runtime sheet replacement must copy transparent pixels too; alpha-compositing
    # would leave ghost pixels from the placeholder run rows underneath v2.
    placeholder.paste(Image.new("RGBA", (160, 320), TRANSPARENT), (0, 16 * 40))
    placeholder.paste(sheet, (0, 16 * 40))
    placeholder.save(OUT / "zampano_preview_sheet.png")

    gif_frames: list[Image.Image] = []
    for phase in range(4):
        grid = Image.new("RGBA", (640, 320), TRANSPARENT)
        for index, direction in enumerate(DIRECTIONS):
            sprite = all_frames[direction][phase].resize(
                (160, 160), Image.Resampling.NEAREST
            )
            grid.alpha_composite(sprite, ((index % 4) * 160, (index // 4) * 160))
        gif_frames.append(grid)
    gif_frames[0].save(
        PREVIEW / "run.gif",
        save_all=True,
        append_images=gif_frames[1:],
        duration=[80, 80, 70, 80],
        loop=0,
        disposal=2,
        transparency=0,
    )

    v1_contact_path = ROOT / "sprites-out" / "zampano" / "preview" / "run-contact.png"
    if v1_contact_path.exists():
        v1_contact = Image.open(v1_contact_path).convert("RGBA")
        v2_contact = Image.open(PREVIEW / "run-contact.png").convert("RGBA")
        comparison = Image.new("RGBA", (1280, 1320), (0, 0, 0, 255))
        comparison.alpha_composite(v1_contact, (0, 40))
        comparison.alpha_composite(v2_contact, (640, 40))
        labels = ImageDraw.Draw(comparison)
        labels.text((8, 8), "V1", fill="white")
        labels.text((648, 8), "V2 normalized", fill="white")
        comparison.save(PREVIEW / "v1-v2-comparison.png")


if __name__ == "__main__":
    main()
