"""Build tired v2 from normalized run anatomy plus v1 tired facial cues."""

from __future__ import annotations

import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[3]
V1 = ROOT / "sprites-out" / "zampano"
V2 = V1 / "v2"
V1_FRAMES = V1 / "frames"
V2_FRAMES = V2 / "frames"
PREVIEW = V2 / "preview"
ICONS = V2 / "icons"

DIRECTIONS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")
AUTHORED = ("N", "NE", "E", "SE", "S")
TRANSPARENT = (0, 0, 0, 0)
DEEP = np.array((61, 92, 93, 255), dtype=np.uint8)
DARK_COLORS = {
    (3, 40, 43, 255),
    (2, 33, 35, 255),
    (3, 25, 27, 255),
    (61, 92, 93, 255),
}


def bbox(image: Image.Image) -> tuple[int, int, int, int]:
    alpha = np.asarray(image.convert("RGBA"))[:, :, 3]
    ys, xs = np.nonzero(alpha)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def anchored(image: Image.Image, bottom: int = 36) -> Image.Image:
    x0, y0, x1, y1 = bbox(image)
    sprite = image.crop((x0, y0, x1, y1))
    canvas = Image.new("RGBA", (40, 40), TRANSPARENT)
    canvas.alpha_composite(sprite, ((40 - sprite.width) // 2, bottom - sprite.height + 1))
    return canvas


def transfer_tired_face(base: Image.Image, tired: Image.Image, direction: str) -> Image.Image:
    if direction == "E":
        # E v1 already matches the v2 E gather envelope exactly and has the
        # clearest lowered head/panting silhouette.
        return anchored(tired)

    out = np.asarray(base.convert("RGBA")).copy()
    src = np.asarray(tired.convert("RGBA"))
    tx0, ty0, tx1, ty1 = bbox(base)
    sx0, sy0, sx1, sy1 = bbox(tired)
    dx = round(((tx0 + tx1 - 1) - (sx0 + sx1 - 1)) / 2)
    dy = ty0 - sy0 + 1

    if direction == "S":
        region = (slice(sy0, min(sy1, sy0 + 17)), slice(sx0, sx1))
    elif direction == "SE":
        head_start = sx0 + round((sx1 - sx0) * 0.43)
        region = (slice(sy0, min(sy1, sy0 + round((sy1 - sy0) * 0.78))), slice(head_start, sx1))
    else:
        return base

    ys, xs = np.nonzero(src[region][..., 3])
    y_offset = region[0].start or 0
    x_offset = region[1].start or 0
    for ry, rx in zip(ys, xs):
        sy, sx = int(ry + y_offset), int(rx + x_offset)
        color = tuple(int(v) for v in src[sy, sx])
        if color not in DARK_COLORS:
            continue
        tx, ty = sx + dx, sy + dy
        if 0 <= tx < 40 and 0 <= ty < 40 and out[ty, tx, 3]:
            out[ty, tx] = src[sy, sx]
    return Image.fromarray(out, "RGBA")


def tired_back_cue(base: Image.Image, direction: str) -> Image.Image:
    arr = np.asarray(base.convert("RGBA")).copy()
    x0, y0, x1, y1 = bbox(base)
    y = y0 + round((y1 - y0) * (0.43 if direction == "N" else 0.50))
    center = round((x0 + x1 - 1) / 2)
    offsets = (-3, -1, 1, 3) if direction == "N" else (-2, 0, 2)
    for offset in offsets:
        x = center + offset
        if 0 <= x < 40 and 0 <= y < 40 and arr[y, x, 3]:
            arr[y, x] = DEEP
    return Image.fromarray(arr, "RGBA")


def breathe(frame0: Image.Image) -> Image.Image:
    source = np.asarray(frame0.convert("RGBA"))
    shifted = np.zeros_like(source)
    shifted[:-1] = source[1:]
    # Restore the lower eight rows byte-for-byte so paws and anchor cannot move.
    shifted[32:] = source[32:]
    return Image.fromarray(shifted, "RGBA")


def mirrored(frames: list[Image.Image]) -> list[Image.Image]:
    return [anchored(frame.transpose(Image.Transpose.FLIP_LEFT_RIGHT)) for frame in frames]


def main() -> None:
    V2_FRAMES.mkdir(parents=True, exist_ok=True)
    PREVIEW.mkdir(parents=True, exist_ok=True)
    ICONS.mkdir(parents=True, exist_ok=True)
    authored: dict[str, list[Image.Image]] = {}

    for direction in AUTHORED:
        base = Image.open(V2_FRAMES / f"run_{direction}_0.png").convert("RGBA")
        tired_v1 = Image.open(V1_FRAMES / f"tired_{direction}_0.png").convert("RGBA")
        frame0 = transfer_tired_face(base, tired_v1, direction)
        if direction in ("N", "NE"):
            frame0 = tired_back_cue(frame0, direction)
        frame0 = anchored(frame0)
        frame1 = breathe(frame0)
        authored[direction] = [frame0, frame1]

    all_frames = dict(authored)
    all_frames["W"] = mirrored(authored["E"])
    all_frames["SW"] = mirrored(authored["SE"])
    all_frames["NW"] = mirrored(authored["NE"])

    sheet = Image.new("RGBA", (80, 320), TRANSPARENT)
    for row, direction in enumerate(DIRECTIONS):
        for phase, frame in enumerate(all_frames[direction]):
            frame.save(V2_FRAMES / f"tired_{direction}_{phase}.png")
            sheet.alpha_composite(frame, (phase * 40, row * 40))
    sheet.save(V2 / "tired.png")
    sheet.resize((320, 1280), Image.Resampling.NEAREST).save(PREVIEW / "tired-contact.png")

    gif_frames: list[Image.Image] = []
    for phase in range(2):
        grid = Image.new("RGBA", (640, 320), TRANSPARENT)
        for index, direction in enumerate(DIRECTIONS):
            sprite = all_frames[direction][phase].resize(
                (160, 160), Image.Resampling.NEAREST
            )
            grid.alpha_composite(sprite, ((index % 4) * 160, (index // 4) * 160))
        gif_frames.append(grid)
    gif_frames[0].save(
        PREVIEW / "tired.gif",
        save_all=True,
        append_images=gif_frames[1:],
        duration=250,
        loop=0,
        disposal=2,
        transparency=0,
    )

    v1_contact = Image.open(V1 / "preview" / "tired-contact.png").convert("RGBA")
    v2_contact = Image.open(PREVIEW / "tired-contact.png").convert("RGBA")
    comparison = Image.new("RGBA", (640, 1320), (0, 0, 0, 255))
    comparison.alpha_composite(v1_contact, (0, 40))
    comparison.alpha_composite(v2_contact, (320, 40))
    labels = ImageDraw.Draw(comparison)
    labels.text((8, 8), "V1 tired", fill="white")
    labels.text((328, 8), "V2 normalized anatomy", fill="white")
    comparison.save(PREVIEW / "tired-v1-v2-comparison.png")

    # The icon is anatomy-independent and intentionally carried over byte-for-byte.
    shutil.copyfile(V1 / "icons" / "runIcon.png", ICONS / "runIcon.png")
    icon = Image.open(ICONS / "runIcon.png").convert("RGBA")
    icon.resize((156, 132), Image.Resampling.NEAREST).save(PREVIEW / "runIcon-12x.png")


if __name__ == "__main__":
    main()
