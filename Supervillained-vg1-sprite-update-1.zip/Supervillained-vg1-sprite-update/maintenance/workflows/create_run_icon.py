"""Create the optional RUN button icon as deterministic hard-pixel art."""

from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "sprites-out" / "zampano" / "icons" / "runIcon.png"
PREVIEW = ROOT / "sprites-out" / "zampano" / "preview" / "runIcon-12x.png"

LIGHT = (255, 255, 255, 255)
SHADE = (217, 226, 239, 255)
OUTLINE = (47, 56, 80, 255)


def main() -> None:
    image = Image.new("RGBA", (13, 11), (0, 0, 0, 0))
    pixels = image.load()

    # Two seven-pixel chevrons, matching the current code-drawn RUN symbol.
    chevrons = []
    for ox in (1, 7):
        chevrons.extend(
            (ox + dx, y)
            for dx, y in ((0, 2), (1, 3), (2, 4), (3, 5), (2, 6), (1, 7), (0, 8))
        )

    # A one-pixel eight-neighbour outline keeps the mark readable over any button fill.
    for x, y in chevrons:
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                px, py = x + dx, y + dy
                if 0 <= px < image.width and 0 <= py < image.height:
                    pixels[px, py] = OUTLINE

    for index, (x, y) in enumerate(chevrons):
        pixels[x, y] = LIGHT if index % 7 >= 3 else SHADE

    OUT.parent.mkdir(parents=True, exist_ok=True)
    PREVIEW.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUT)
    image.resize((13 * 12, 11 * 12), Image.Resampling.NEAREST).save(PREVIEW)


if __name__ == "__main__":
    main()
