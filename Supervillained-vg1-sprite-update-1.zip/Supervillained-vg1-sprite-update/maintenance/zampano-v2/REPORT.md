# Zampanò — proportion-normalized v2 package

## Scope

V1 remains unchanged. V2 contains:

- `run`: 32 frames, 4 phases × 8 directions.
- `tired`: 16 frames, 2 phases × 8 directions.
- `runIcon`: 13×11, intentionally carried over byte-for-byte.

## Run normalization

V1 changed apparent breed/anatomy sharply when turning: S had oversized sideways ears, SE was
undersized, and N/NE were tall or narrow compared with E.

V2 fixes this without another generative pass:

- E/W are frozen as the approved canonical anatomy.
- Authored N, NE, SE, and S use discrete interior pixel-row/column seam edits only.
- S shares one rounded/floppy head-and-ear silhouette across all four phases.
- N/NE use short source-palette fur-shadow marks to separate head and torso.
- SE is enlarged to the same diagonal envelope as NE.
- W, SW, and NW are rebuilt as exact mirrors, then re-anchored.

No anti-aliasing, blur, color interpolation, or non-integer image resampling was used.

Canonical apparent width progression:

- E profile: about 36 px.
- NE/SE diagonals: about 33 px.
- N/S front/rear: about 30 px.

Corresponding authored directions change by no more than 3 px per axis for each phase, replacing
V1 jumps of up to 12 px. Exact measurements are in `proportions.json`.

## Tired normalization

Tired v2 is built from each direction's corrected v2 run-gather anatomy, not by scaling the
independently generated tired dogs:

- E reuses the strong v1 lowered-head/panting silhouette because its 34×28 envelope already
  matches v2 E exactly.
- S and SE preserve v2 body/head geometry and transfer only dark mouth/muzzle cues from v1.
- N/NE preserve their corrected rear anatomy and receive small lowered-back breathing cues.
- Frame 1 is derived only from corrected frame 0: the upper body moves one pixel while rows 32–39
  are restored byte-for-byte. Paws and anchor therefore cannot move.
- Mirrors are regenerated from corrected E, SE, and NE.

The strict source palette contains no pink, so the panting tongue/mouth uses existing teal and
pale-blue values.

## Icon

`icons/runIcon.png` is copied unchanged because it is anatomy-independent and already matches the
live RUN button motif.

- Size: 13×11.
- Alpha: `{0,255}`.
- Colors: 3.
- SHA-256: `7e61c0c7719b34c5413463150ae7a076f4128ac9f61950d4fd3e25b2b2c54f91`.

## Mechanical validation

| Asset | Count | Size | Timing |
|---|---:|---:|---:|
| Run frames | 32 | 40×40 | 13 fps |
| Tired frames | 16 | 40×40 | 4 fps |
| RUN icon | 1 | 13×11 | static |
| `run.png` | 1 | 160×320 | — |
| `tired.png` | 1 | 80×320 | — |

All character frames:

- use only alpha 0 or 255;
- use at most the eight exact source-derived colors;
- are centred on x=20;
- end at y=36, except run flight at y=34;
- contain no cast shadow.

Tired frame pairs additionally have identical lower eight rows.

## QA

The v2 run sheet was checked locally in:

- `?debug=sprites&char=zampano` — comparable mass across all five authored facings;
- `?skip=game` — N, NE, E, SE, and S remain readable against trees and 32×16 floor tiles.

Screenshots and previews:

- `preview/run-debug.png`
- `preview/run-gameplay-directions.png`
- `preview/v1-v2-comparison.png`
- `preview/tired-v1-v2-comparison.png`
- `preview/run.gif`
- `preview/tired.gif`

The temporary preview sheet and manifest hook were removed after QA. No tracked repository file is
modified.

## Current wiring limitation

The repository still has no `tired` animation entry or `runIcon` sprite entry. Those v2 assets are
ready, but cannot be exercised through the normal game loader until the planned manifest/UI wiring
is added.

Reproduction scripts:

- `../workflows/build_run_v2_normalized.py`
- `../workflows/build_tired_v2_normalized.py`
