# confusione animation report

## Source

- Image: `pixel-art-characters/Confusione.png`
- Existing view: S/front
- Appearance: Orange tabby fighting cat with cream muzzle/chest, heavy brows, ear nicks, fang, stripes and curled tail; feline prowl and hiss.
- The Desktop source art overrides conflicting prose/cast colors.

## Output

- 112 individual 40×40 frames.
- Sheet: `confusione.png`, 160×1600.
- Animation order: idle, walk, run, bark/hiss, hurt.
- Direction order: N, NE, E, SE, S, SW, W, NW.
- W/SW/NW are exact mirrors of E/SE/NE and were re-anchored.

## Processing

- Canonical game rig supplies stable body proportions and animation contacts.
- Colors and defining markings/accessories use exact RGB values from the source image.
- Alpha is binary; no anti-aliasing or cast shadow.
- Every frame is centred on x=20 and grounded at y=36.
- Personality-specific pixel edits are deterministic and recorded in `sprites-out/workflows/cast_pipeline.py`.

## Preview

- `preview/idle.gif`
- `preview/walk.gif`
- `preview/run.gif`
- `preview/bark.gif`
- `preview/hurt.gif`
- `preview/contact.png`
- `preview/debug.png`

## In-game QA

The completed sheet was loaded locally through `?debug=sprites&char=confusione`. The five authored
directions rendered at the intended game scale without clipping; mirrored directions were checked
through the generated contact sheet. The temporary manifest/public-sheet hook was removed after
capture.
